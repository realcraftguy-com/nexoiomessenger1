-- Phase 33: report notes, invite management metadata and safe avatar validator support.
CREATE TABLE IF NOT EXISTS "ReportNote" (
  "id" TEXT NOT NULL,
  "reportId" TEXT NOT NULL,
  "adminId" TEXT NOT NULL,
  "note" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ReportNote_pkey" PRIMARY KEY ("id")
);

CREATE INDEX IF NOT EXISTS "ReportNote_reportId_createdAt_idx" ON "ReportNote"("reportId", "createdAt");
CREATE INDEX IF NOT EXISTS "ReportNote_adminId_idx" ON "ReportNote"("adminId");

DO $$ BEGIN
  ALTER TABLE "ReportNote" ADD CONSTRAINT "ReportNote_reportId_fkey" FOREIGN KEY ("reportId") REFERENCES "Report"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  ALTER TABLE "ReportNote" ADD CONSTRAINT "ReportNote_adminId_fkey" FOREIGN KEY ("adminId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

ALTER TABLE "Invite" ADD COLUMN IF NOT EXISTS "channelId" TEXT;
ALTER TABLE "Invite" ADD COLUMN IF NOT EXISTS "disabledAt" TIMESTAMP(3);
ALTER TABLE "Invite" ALTER COLUMN "createdBy" DROP NOT NULL;
CREATE INDEX IF NOT EXISTS "Invite_serverId_disabledAt_idx" ON "Invite"("serverId", "disabledAt");
CREATE INDEX IF NOT EXISTS "Invite_createdBy_idx" ON "Invite"("createdBy");
CREATE INDEX IF NOT EXISTS "Invite_channelId_idx" ON "Invite"("channelId");

DO $$ BEGIN
  ALTER TABLE "Invite" ADD CONSTRAINT "Invite_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$ BEGIN
  ALTER TABLE "Invite" ADD CONSTRAINT "Invite_channelId_fkey" FOREIGN KEY ("channelId") REFERENCES "Channel"("id") ON DELETE SET NULL ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;
