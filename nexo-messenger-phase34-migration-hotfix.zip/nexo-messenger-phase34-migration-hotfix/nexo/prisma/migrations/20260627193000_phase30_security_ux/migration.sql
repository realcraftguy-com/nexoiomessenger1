-- Phase 30: duplicate-message protection and safer client retries
ALTER TABLE "Message" ADD COLUMN IF NOT EXISTS "clientMessageId" TEXT;
ALTER TABLE "DirectMessage" ADD COLUMN IF NOT EXISTS "clientMessageId" TEXT;

CREATE UNIQUE INDEX IF NOT EXISTS "Message_channelId_authorId_clientMessageId_key"
  ON "Message"("channelId", "authorId", "clientMessageId")
  WHERE "clientMessageId" IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS "DirectMessage_threadId_authorId_clientMessageId_key"
  ON "DirectMessage"("threadId", "authorId", "clientMessageId")
  WHERE "clientMessageId" IS NOT NULL;
