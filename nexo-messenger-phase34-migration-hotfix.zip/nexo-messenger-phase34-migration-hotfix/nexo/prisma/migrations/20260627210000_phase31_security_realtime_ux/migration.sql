DO $$ BEGIN
  ALTER TYPE "AuditAction" ADD VALUE IF NOT EXISTS 'REPORT_UPDATED';
EXCEPTION WHEN undefined_object THEN NULL; END $$;

-- Phase 31: realtime/privacy hardening and product tables.

-- Prevent duplicate pins. PostgreSQL allows multiple NULLs in unique columns,
-- so this still supports channel pins and DM pins independently.
DELETE FROM "PinnedMessage" a USING "PinnedMessage" b WHERE a."messageId" IS NOT NULL AND a."messageId" = b."messageId" AND a."createdAt" > b."createdAt";
DELETE FROM "PinnedMessage" a USING "PinnedMessage" b WHERE a."dmMessageId" IS NOT NULL AND a."dmMessageId" = b."dmMessageId" AND a."createdAt" > b."createdAt";
CREATE UNIQUE INDEX IF NOT EXISTS "PinnedMessage_messageId_key" ON "PinnedMessage"("messageId");
CREATE UNIQUE INDEX IF NOT EXISTS "PinnedMessage_dmMessageId_key" ON "PinnedMessage"("dmMessageId");

CREATE TABLE IF NOT EXISTS "Report" (
  "id" TEXT NOT NULL,
  "reporterId" TEXT NOT NULL,
  "targetUserId" TEXT,
  "messageId" TEXT,
  "dmMessageId" TEXT,
  "serverId" TEXT,
  "reason" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'open',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "Report_pkey" PRIMARY KEY ("id")
);
CREATE INDEX IF NOT EXISTS "Report_reporterId_createdAt_idx" ON "Report"("reporterId", "createdAt");
CREATE INDEX IF NOT EXISTS "Report_targetUserId_idx" ON "Report"("targetUserId");
CREATE INDEX IF NOT EXISTS "Report_messageId_idx" ON "Report"("messageId");
CREATE INDEX IF NOT EXISTS "Report_dmMessageId_idx" ON "Report"("dmMessageId");
CREATE INDEX IF NOT EXISTS "Report_serverId_status_idx" ON "Report"("serverId", "status");

CREATE TABLE IF NOT EXISTS "BlockedUser" (
  "id" TEXT NOT NULL,
  "blockerId" TEXT NOT NULL,
  "blockedId" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "BlockedUser_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX IF NOT EXISTS "BlockedUser_blockerId_blockedId_key" ON "BlockedUser"("blockerId", "blockedId");
CREATE INDEX IF NOT EXISTS "BlockedUser_blockedId_idx" ON "BlockedUser"("blockedId");

CREATE TABLE IF NOT EXISTS "FriendRequest" (
  "id" TEXT NOT NULL,
  "senderId" TEXT NOT NULL,
  "receiverId" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'pending',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "FriendRequest_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX IF NOT EXISTS "FriendRequest_senderId_receiverId_key" ON "FriendRequest"("senderId", "receiverId");
CREATE INDEX IF NOT EXISTS "FriendRequest_receiverId_status_idx" ON "FriendRequest"("receiverId", "status");

CREATE TABLE IF NOT EXISTS "Friendship" (
  "id" TEXT NOT NULL,
  "userAId" TEXT NOT NULL,
  "userBId" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Friendship_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX IF NOT EXISTS "Friendship_userAId_userBId_key" ON "Friendship"("userAId", "userBId");
CREATE INDEX IF NOT EXISTS "Friendship_userBId_idx" ON "Friendship"("userBId");

-- Optional self-reply relation for DM reply previews.
DO $$ BEGIN
  ALTER TABLE "DirectMessage" ADD CONSTRAINT "DirectMessage_replyToId_fkey" FOREIGN KEY ("replyToId") REFERENCES "DirectMessage"("id") ON DELETE SET NULL ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
