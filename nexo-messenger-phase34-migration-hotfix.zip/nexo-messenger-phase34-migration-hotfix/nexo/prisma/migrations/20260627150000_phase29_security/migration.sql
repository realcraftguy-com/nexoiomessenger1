-- Phase 29: security, private storage, permissions, notifications, pins
DO $$ BEGIN
  ALTER TYPE "AuditAction" ADD VALUE 'NOTIFICATION_CREATED';
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  ALTER TYPE "AuditAction" ADD VALUE 'MESSAGE_PINNED';
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  ALTER TYPE "AuditAction" ADD VALUE 'MESSAGE_UNPINNED';
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  ALTER TYPE "AuditAction" ADD VALUE 'PRIVATE_CHANNEL_UPDATED';
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  ALTER TYPE "AuditAction" ADD VALUE 'SYSTEM_SETTING_UPDATED';
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

ALTER TABLE "User" ADD COLUMN IF NOT EXISTS "aiDisabled" BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE "Channel" ADD COLUMN IF NOT EXISTS "slowmodeSeconds" INTEGER NOT NULL DEFAULT 0;
ALTER TABLE "TicketAttachment" ADD COLUMN IF NOT EXISTS "storagePath" TEXT NOT NULL DEFAULT '';
ALTER TABLE "TicketAttachment" ADD COLUMN IF NOT EXISTS "originalName" TEXT NOT NULL DEFAULT '';

CREATE TABLE IF NOT EXISTS "MessageAttachment" (
  "id" TEXT NOT NULL,
  "messageId" TEXT,
  "dmMessageId" TEXT,
  "uploaderId" TEXT NOT NULL,
  "storagePath" TEXT NOT NULL,
  "originalName" TEXT NOT NULL,
  "mimeType" TEXT NOT NULL,
  "size" INTEGER NOT NULL,
  "width" INTEGER,
  "height" INTEGER,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "MessageAttachment_pkey" PRIMARY KEY ("id")
);

DO $$ BEGIN
  ALTER TABLE "MessageAttachment" ADD CONSTRAINT "MessageAttachment_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES "Message"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  ALTER TABLE "MessageAttachment" ADD CONSTRAINT "MessageAttachment_dmMessageId_fkey" FOREIGN KEY ("dmMessageId") REFERENCES "DirectMessage"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  ALTER TABLE "MessageAttachment" ADD CONSTRAINT "MessageAttachment_uploaderId_fkey" FOREIGN KEY ("uploaderId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS "ChannelPermissionOverride" (
  "id" TEXT NOT NULL,
  "channelId" TEXT NOT NULL,
  "roleId" TEXT,
  "memberId" TEXT,
  "allow" TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  "deny" TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "ChannelPermissionOverride_pkey" PRIMARY KEY ("id")
);
DO $$ BEGIN
  ALTER TABLE "ChannelPermissionOverride" ADD CONSTRAINT "ChannelPermissionOverride_channelId_fkey" FOREIGN KEY ("channelId") REFERENCES "Channel"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  ALTER TABLE "ChannelPermissionOverride" ADD CONSTRAINT "ChannelPermissionOverride_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES "Role"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  ALTER TABLE "ChannelPermissionOverride" ADD CONSTRAINT "ChannelPermissionOverride_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES "ServerMember"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS "SystemSetting" (
  "key" TEXT NOT NULL,
  "value" JSONB NOT NULL,
  "updatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "SystemSetting_pkey" PRIMARY KEY ("key")
);

CREATE TABLE IF NOT EXISTS "Notification" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "type" TEXT NOT NULL,
  "title" TEXT NOT NULL,
  "body" TEXT,
  "href" TEXT,
  "readAt" TIMESTAMP(3),
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Notification_pkey" PRIMARY KEY ("id")
);
DO $$ BEGIN
  ALTER TABLE "Notification" ADD CONSTRAINT "Notification_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS "Mention" (
  "id" TEXT NOT NULL,
  "messageId" TEXT,
  "dmMessageId" TEXT,
  "userId" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "Mention_pkey" PRIMARY KEY ("id")
);
DO $$ BEGIN
  ALTER TABLE "Mention" ADD CONSTRAINT "Mention_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES "Message"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  ALTER TABLE "Mention" ADD CONSTRAINT "Mention_dmMessageId_fkey" FOREIGN KEY ("dmMessageId") REFERENCES "DirectMessage"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  ALTER TABLE "Mention" ADD CONSTRAINT "Mention_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS "PinnedMessage" (
  "id" TEXT NOT NULL,
  "channelId" TEXT,
  "dmThreadId" TEXT,
  "messageId" TEXT,
  "dmMessageId" TEXT,
  "pinnedById" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT "PinnedMessage_pkey" PRIMARY KEY ("id")
);
DO $$ BEGIN
  ALTER TABLE "PinnedMessage" ADD CONSTRAINT "PinnedMessage_channelId_fkey" FOREIGN KEY ("channelId") REFERENCES "Channel"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  ALTER TABLE "PinnedMessage" ADD CONSTRAINT "PinnedMessage_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES "Message"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  ALTER TABLE "PinnedMessage" ADD CONSTRAINT "PinnedMessage_dmMessageId_fkey" FOREIGN KEY ("dmMessageId") REFERENCES "DirectMessage"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN
  ALTER TABLE "PinnedMessage" ADD CONSTRAINT "PinnedMessage_pinnedById_fkey" FOREIGN KEY ("pinnedById") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE INDEX IF NOT EXISTS "MessageAttachment_messageId_idx" ON "MessageAttachment"("messageId");
CREATE INDEX IF NOT EXISTS "MessageAttachment_dmMessageId_idx" ON "MessageAttachment"("dmMessageId");
CREATE INDEX IF NOT EXISTS "MessageAttachment_uploaderId_idx" ON "MessageAttachment"("uploaderId");
CREATE INDEX IF NOT EXISTS "MessageAttachment_storagePath_idx" ON "MessageAttachment"("storagePath");
CREATE INDEX IF NOT EXISTS "ChannelPermissionOverride_channelId_idx" ON "ChannelPermissionOverride"("channelId");
CREATE INDEX IF NOT EXISTS "ChannelPermissionOverride_roleId_idx" ON "ChannelPermissionOverride"("roleId");
CREATE INDEX IF NOT EXISTS "ChannelPermissionOverride_memberId_idx" ON "ChannelPermissionOverride"("memberId");
CREATE INDEX IF NOT EXISTS "Notification_userId_readAt_createdAt_idx" ON "Notification"("userId", "readAt", "createdAt");
CREATE INDEX IF NOT EXISTS "Mention_messageId_idx" ON "Mention"("messageId");
CREATE INDEX IF NOT EXISTS "Mention_dmMessageId_idx" ON "Mention"("dmMessageId");
CREATE INDEX IF NOT EXISTS "Mention_userId_idx" ON "Mention"("userId");
CREATE INDEX IF NOT EXISTS "PinnedMessage_channelId_idx" ON "PinnedMessage"("channelId");
CREATE INDEX IF NOT EXISTS "PinnedMessage_dmThreadId_idx" ON "PinnedMessage"("dmThreadId");
CREATE INDEX IF NOT EXISTS "PinnedMessage_messageId_idx" ON "PinnedMessage"("messageId");
CREATE INDEX IF NOT EXISTS "PinnedMessage_dmMessageId_idx" ON "PinnedMessage"("dmMessageId");
CREATE INDEX IF NOT EXISTS "PinnedMessage_pinnedById_idx" ON "PinnedMessage"("pinnedById");

ALTER TABLE "AuditLog" ADD COLUMN IF NOT EXISTS "archivedAt" TIMESTAMP(3);
CREATE INDEX IF NOT EXISTS "AuditLog_archivedAt_createdAt_idx" ON "AuditLog"("archivedAt", "createdAt");
