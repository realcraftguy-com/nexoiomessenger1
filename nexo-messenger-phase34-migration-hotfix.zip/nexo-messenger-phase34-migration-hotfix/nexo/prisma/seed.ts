import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import { requireSeedPassword } from "../src/lib/env";

const prisma = new PrismaClient();

function firstAdminEmail() {
  return process.env.ADMIN_EMAILS?.split(",").map((mail) => mail.trim().toLowerCase()).filter(Boolean)[0];
}

function colorFromEmail(email: string) {
  const colors = ["#ffffff", "#d4d4d8", "#a1a1aa", "#f4f4f5", "#e5e7eb"];
  let sum = 0;
  for (const char of email) sum += char.charCodeAt(0);
  return colors[sum % colors.length];
}

async function main() {
  const email = firstAdminEmail();
  if (!email) {
    console.log("ADMIN_EMAILS ist leer. Kein Admin-Seed erstellt.");
    return;
  }

  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) {
    console.log(`Admin existiert bereits: ${email}`);
    return;
  }

  const password = requireSeedPassword();
  const user = await prisma.user.create({
    data: {
      email,
      username: "realcraftguy",
      displayName: "RealCraftGuy",
      avatarColor: colorFromEmail(email),
      passwordHash: await bcrypt.hash(password, 12),
      status: "OFFLINE"
    }
  });

  const server = await prisma.server.create({
    data: {
      name: "Nexo HQ",
      ownerId: user.id,
      members: { create: { userId: user.id, isOwner: true, isAdmin: true } },
      roles: {
        create: [
          { name: "Owner", color: "#ffffff", permissions: JSON.stringify(["*"]), position: 10000 },
          { name: "Admin", color: "#d4d4d8", permissions: JSON.stringify(["MANAGE_SERVER", "MANAGE_CHANNELS", "MANAGE_MESSAGES", "VIEW_AUDIT_LOG"]), position: 9000 }
        ]
      },
      channels: {
        create: [
          { name: "general", type: "TEXT", position: 0 },
          { name: "announcements", type: "TEXT", position: 1 },
          { name: "voice-lounge", type: "VOICE", position: 2 }
        ]
      }
    }
  });

  await prisma.systemSetting.upsert({ where: { key: "ai.enabled" }, create: { key: "ai.enabled", value: true }, update: {} }).catch(() => undefined);
  console.log(`Admin erstellt: ${email}`);
  console.log(`Start-Server erstellt: ${server.name}`);
}

main()
  .catch((error) => { console.error(error); process.exit(1); })
  .finally(async () => { await prisma.$disconnect(); });
