import net from "node:net";

function parseRedisUrl() {
  const raw = process.env.REDIS_URL || "redis://redis:6379";
  const url = new URL(raw);
  return { host: url.hostname, port: Number(url.port || 6379), password: url.password ? decodeURIComponent(url.password) : undefined };
}

function encodeCommand(parts: string[]) {
  return `*${parts.length}\r\n${parts.map((part) => `$${Buffer.byteLength(part)}\r\n${part}\r\n`).join("")}`;
}

export async function redisCommand(parts: string[], timeoutMs = 900): Promise<string> {
  const { host, port, password } = parseRedisUrl();
  const auth = password ? encodeCommand(["AUTH", password]) : "";
  const payload = auth + encodeCommand(parts);
  return new Promise((resolve, reject) => {
    const socket = net.createConnection({ host, port });
    let data = "";
    const timer = setTimeout(() => { socket.destroy(); reject(new Error("Redis timeout")); }, timeoutMs);
    socket.on("connect", () => socket.write(payload));
    socket.on("data", (chunk) => { data += chunk.toString("utf8"); if (data.includes("\r\n")) socket.end(); });
    socket.on("error", reject);
    socket.on("close", () => { clearTimeout(timer); resolve(data); });
  });
}

export async function redisPing() {
  const response = await redisCommand(["PING"], 1200);
  if (!response.includes("PONG")) throw new Error(`Unexpected Redis response: ${response.slice(0, 80)}`);
  return true;
}

export function parseRedisIntegerResponse(response: string) {
  const match = /:(-?\d+)/.exec(response);
  return match ? Number(match[1]) : NaN;
}
