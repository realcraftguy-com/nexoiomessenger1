import prisma from "./prisma";
import { emitToUser } from "./live";
import { canAccessChannel, hasPermission, requireServerPermission } from "./permissions";

export async function createNotification(input: { userId: string; type: string; title: string; body?: string; href?: string }) {
  const notification = await prisma.notification.create({ data: input }).catch(() => null);
  if (notification) emitToUser(input.userId, "notification:new", { notification });
  return notification;
}

function uniqueMentions(content: string) {
  return Array.from(new Set([...content.matchAll(/@([a-zA-Z0-9_.-]{3,24}|everyone)/g)].map((match) => match[1].toLowerCase())));
}

export async function createMentionNotifications({ content, messageId, dmMessageId, excludeUserId }: { content: string; messageId?: string; dmMessageId?: string; excludeUserId?: string }) {
  const names = uniqueMentions(content);
  if (!names.length) return [];

  const message = messageId ? await prisma.message.findUnique({ where: { id: messageId }, select: { id: true, channelId: true, authorId: true, channel: { select: { serverId: true } } } }) : null;
  const dmMessage = dmMessageId ? await prisma.directMessage.findUnique({ where: { id: dmMessageId }, select: { id: true, threadId: true, authorId: true } }) : null;
  if (!message && !dmMessage) return [];

  const targetUsers = new Map<string, { id: string; username: string }>();

  if (names.includes("everyone") && message) {
    const actorState = await requireServerPermission(message.channel.serverId, { id: message.authorId, isAdmin: false }, "MENTION_EVERYONE");
    if (hasPermission(actorState, "MENTION_EVERYONE")) {
      const members = await prisma.serverMember.findMany({ where: { serverId: message.channel.serverId, userId: { not: excludeUserId } }, select: { user: { select: { id: true, username: true } } } });
      for (const member of members) targetUsers.set(member.user.id, member.user);
    }
  }

  const explicitNames = names.filter((name) => name !== "everyone");
  if (explicitNames.length) {
    const users = await prisma.user.findMany({ where: { username: { in: explicitNames }, id: { not: excludeUserId } }, select: { id: true, username: true } });
    for (const user of users) targetUsers.set(user.id, user);
  }

  const mentions = [];
  for (const target of targetUsers.values()) {
    if (message) {
      const canView = await canAccessChannel(message.channelId, target.id, false, "VIEW_CHANNEL");
      if (!canView) continue;
    }
    if (dmMessage) {
      const member = await prisma.directMessageThreadMember.findFirst({ where: { threadId: dmMessage.threadId, userId: target.id, thread: { status: "ACCEPTED" } } });
      if (!member) continue;
    }

    const mention = await prisma.mention.create({ data: { userId: target.id, messageId: messageId || null, dmMessageId: dmMessageId || null } }).catch(() => null);
    if (mention) mentions.push(mention);
    await createNotification({ userId: target.id, type: "mention", title: "Du wurdest erwähnt", body: `@${target.username}`, href: messageId ? "/app" : "/app/@me" });
  }
  return mentions;
}
