export function initials(name: string) {
  return name
    .split(/\s+/)
    .map((part) => part[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

export function prettyStatus(status: string) {
  return status === "DO_NOT_DISTURB" ? "Nicht stören" : status === "BUSY" ? "Beschäftigt" : status === "ONLINE" ? "Online" : "Offline";
}

export function safeText(text: string) {
  return text.replace(/[<>]/g, "");
}
