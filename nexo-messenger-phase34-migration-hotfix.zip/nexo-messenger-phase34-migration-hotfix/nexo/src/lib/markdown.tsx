"use client";

import React, { useState } from "react";

function InlineMarkdown({ text }: { text: string }) {
  const escaped = text.replace(/[<>]/g, "");
  const parts = escaped.split(/(`[^`]+`|\*\*[^*]+\*\*|\*[^*]+\*)/g);
  return (
    <span className="whitespace-pre-wrap break-words">
      {parts.map((part, index) => {
        if (part.startsWith("`") && part.endsWith("`"))
          return (
            <code
              key={index}
              className="rounded-md border border-white/10 bg-white/10 px-1.5 py-0.5 text-[13px]"
            >
              {part.slice(1, -1)}
            </code>
          );
        if (part.startsWith("**") && part.endsWith("**"))
          return <strong key={index}>{part.slice(2, -2)}</strong>;
        if (part.startsWith("*") && part.endsWith("*"))
          return <em key={index}>{part.slice(1, -1)}</em>;
        return <React.Fragment key={index}>{part}</React.Fragment>;
      })}
    </span>
  );
}

function CodeBlock({ code, language }: { code: string; language?: string }) {
  const [copied, setCopied] = useState(false);
  async function copy() {
    await navigator.clipboard?.writeText(code).catch(() => undefined);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1400);
  }
  return (
    <div className="group/code my-3 overflow-hidden rounded-2xl border border-white/10 bg-[#09090b]">
      <div className="flex items-center justify-between border-b border-white/10 bg-white/[.035] px-3 py-2 text-[11px] text-zinc-500">
        <span className="font-mono uppercase tracking-[.16em]">
          {language || "code"}
        </span>
        <button
          type="button"
          onClick={copy}
          className="rounded-xl border border-white/10 bg-white/[.04] px-2 py-1 text-xs text-zinc-300 transition hover:bg-white/[.08] hover:text-white"
        >
          {copied ? "Kopiert" : "Copy"}
        </button>
      </div>
      <pre className="nexo-scrollbar max-h-[420px] overflow-auto p-4 text-[13px] leading-6 text-zinc-200">
        <code>{code}</code>
      </pre>
    </div>
  );
}

export function SimpleMarkdown({ text }: { text: string }) {
  const blocks = text.split(/```([\w-]*)\n?([\s\S]*?)```/g);
  if (blocks.length === 1) return <InlineMarkdown text={text} />;
  const nodes: React.ReactNode[] = [];
  for (let index = 0; index < blocks.length; index += 3) {
    const normal = blocks[index] || "";
    if (normal)
      nodes.push(<InlineMarkdown key={`text-${index}`} text={normal} />);
    const language = blocks[index + 1];
    const code = blocks[index + 2];
    if (typeof code === "string")
      nodes.push(
        <CodeBlock
          key={`code-${index}`}
          code={code.replace(/\n$/, "")}
          language={language?.trim()}
        />,
      );
  }
  return <div className="space-y-1 break-words">{nodes}</div>;
}
