import { z } from "zod";
import { SERVER_PERMISSIONS } from "./permissions";

const permissionEnum = SERVER_PERMISSIONS as unknown as [typeof SERVER_PERMISSIONS[number], ...typeof SERVER_PERMISSIONS[number][]];

const avatarInput = z
  .string()
  .max(1_500_000, "Avatar ist zu groß")
  .optional()
  .or(z.literal(""))
  .refine((value) => {
    if (!value) return true;
    if (value.startsWith("/api/files/avatars/")) return true;
    // Legacy compatibility only: existing profiles may still contain safe-ish data URLs or external URLs.
    return value.startsWith("data:image/") || /^https?:\/\//i.test(value);
  }, "Ungültiges Avatar-Bild");

export const registerSchema = z.object({
  email: z.string().email().max(180),
  username: z.string().min(3).max(24).regex(/^[a-zA-Z0-9_.-]+$/),
  displayName: z.string().min(2).max(40),
  password: z.string().min(8).max(120)
});

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1).max(120),
  twoFactorCode: z.string().min(4).max(12).optional().or(z.literal(""))
});

export const profileSchema = z.object({
  displayName: z.string().min(2).max(40),
  username: z.string().min(3).max(24).regex(/^[a-zA-Z0-9_.-]+$/),
  avatarUrl: avatarInput,
  avatarColor: z.string().regex(/^#[0-9a-fA-F]{6}$/),
  accentColor: z.string().regex(/^#[0-9a-fA-F]{6}$/).optional(),
  bio: z.string().max(220).optional().default(""),
  pronouns: z.string().max(40).optional().default(""),
  location: z.string().max(60).optional().default(""),
  customStatus: z.string().max(80).optional().default(""),
  compactMode: z.boolean().optional().default(false),
  reduceMotion: z.boolean().optional().default(false),
  showOnline: z.boolean().optional().default(true),
  allowDmRequests: z.boolean().optional().default(true),
  status: z.enum(["ONLINE", "OFFLINE", "BUSY", "DO_NOT_DISTURB"]),
  onboarded: z.boolean().optional()
});

export const serverSchema = z.object({
  name: z.string().min(2).max(60),
  iconUrl: z.string().url().optional().or(z.literal("")),
  isPrivate: z.boolean().default(true)
});

export const channelSchema = z.object({
  name: z.string().min(2).max(32).regex(/^[a-z0-9-]+$/),
  type: z.enum(["TEXT", "VOICE"]).default("TEXT"),
  categoryId: z.string().uuid().optional().nullable(),
  topic: z.string().max(160).optional().default(""),
  isPrivate: z.boolean().optional().default(false),
  slowmodeSeconds: z.number().int().min(0).max(21600).optional().default(0)
});

export const serverSettingsSchema = z.object({
  name: z.string().min(2).max(60),
  iconUrl: z.string().max(1_500_000).optional().or(z.literal("")),
  isPrivate: z.boolean().default(true)
});

export const categorySchema = z.object({
  name: z.string().min(2).max(40),
  collapsed: z.boolean().optional().default(false)
});

export const roleSchema = z.object({
  name: z.string().min(2).max(40),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/).default("#ffffff"),
  permissions: z.array(z.enum(permissionEnum)).max(30).optional().default([])
});

export const twoFactorSchema = z.object({
  enabled: z.boolean(),
  code: z.string().regex(/^\d{6}$/, "Der Code muss aus 6 Zahlen bestehen.").optional().or(z.literal(""))
});

export const reactionSchema = z.object({
  emoji: z.string().min(1).max(16)
});

export const messageSchema = z.object({
  content: z.string().max(4000).default(""),
  replyToId: z.string().uuid().optional().nullable(),
  clientMessageId: z.string().min(8).max(80).regex(/^[a-zA-Z0-9_.:-]+$/).optional(),
  attachmentIds: z.array(z.string().min(1).max(160).regex(/^[a-zA-Z0-9_-]+$/)).max(5).optional().default([]),
  // Legacy client compatibility: we only extract IDs from this field. New messages never store arbitrary attachment URLs anymore.
  attachments: z.array(z.object({
    id: z.string().min(1).max(160).regex(/^[a-zA-Z0-9_-]+$/).optional(),
    url: z.string().max(600).optional()
  }).passthrough()).max(5).optional().default([])
}).refine((value) => value.content.trim().length > 0 || value.attachmentIds.length > 0 || value.attachments.some((item) => item.id), {
  message: "Schreibe eine Nachricht oder hänge eine Datei an."
});

export const ticketSchema = z.object({
  title: z.string().min(3).max(90),
  category: z.string().min(2).max(40),
  description: z.string().min(10).max(4000),
  priority: z.enum(["LOW", "NORMAL", "HIGH", "URGENT"]).default("NORMAL")
});

export const ticketMessageSchema = z.object({
  content: z.string().min(1).max(3000)
});

export const ticketCloseSchema = z.object({
  reason: z.string().min(3, "Bitte gib einen Grund an.").max(500)
});

export const aiSchema = z.object({
  chatId: z.string().uuid().optional(),
  content: z.string().min(1).max(8000)
});
