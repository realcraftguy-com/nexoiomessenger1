import { NextResponse } from "next/server";
import { ZodError } from "zod";

export function json(data: unknown, status = 200) {
  return NextResponse.json(data, { status });
}

export function error(message: string, status = 400) {
  return NextResponse.json({ error: message }, { status });
}

export function handleError(err: unknown) {
  if (err instanceof ZodError) {
    return error(err.issues[0]?.message || "Ungültige Eingabe", 422);
  }
  if (err instanceof Error && err.message) {
    console.error(err);
    return error(err.message, 400);
  }
  console.error(err);
  return error("Etwas ist schiefgelaufen", 500);
}
