const unsafeMethods = new Set(["POST", "PUT", "PATCH", "DELETE"]);

function normalizeOrigin(value: string) {
  try {
    const url = new URL(value);
    return `${url.protocol}//${url.host}`.toLowerCase();
  } catch {
    return "";
  }
}

function localhostOrigins() {
  return new Set(["http://localhost:3000", "http://127.0.0.1:3000", "http://0.0.0.0:3000"]);
}

export function allowedRequestOrigins() {
  const appUrl = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";
  const configured = (process.env.ALLOWED_ORIGINS || appUrl)
    .split(",")
    .map((item) => normalizeOrigin(item.trim()))
    .filter(Boolean);
  const set = new Set(configured);
  if (process.env.NODE_ENV !== "production") for (const item of localhostOrigins()) set.add(item);
  return set;
}

export function isUnsafeMethod(method: string) {
  return unsafeMethods.has(method.toUpperCase());
}

export function verifyOrigin(input: { method: string; origin?: string | null; referer?: string | null; host?: string | null }) {
  if (!isUnsafeMethod(input.method)) return { ok: true as const };
  const allowed = allowedRequestOrigins();
  const requestOrigin = normalizeOrigin(input.origin || "") || normalizeOrigin(input.referer || "");
  if (!requestOrigin) {
    if (process.env.NODE_ENV !== "production") return { ok: true as const, warning: "missing_origin_dev" };
    return { ok: false as const, reason: "Origin fehlt" };
  }
  if (allowed.has(requestOrigin)) return { ok: true as const };
  return { ok: false as const, reason: "Origin ist nicht erlaubt" };
}

export function assertRequestOrigin(request: Request) {
  const result = verifyOrigin({
    method: request.method,
    origin: request.headers.get("origin"),
    referer: request.headers.get("referer"),
    host: request.headers.get("host")
  });
  if (!result.ok) throw new Error(result.reason);
  return result;
}
