import { randomUUID } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import prisma from "./prisma";
import { assertSafeUpload, filesFromFormData as baseFilesFromFormData, MAX_FILE_BYTES, MAX_FILE_MB, storagePath } from "./upload-security";

export const filesFromFormData = baseFilesFromFormData;

export async function saveTicketAttachments({ files, ticketId, messageId, uploaderId }: { files: File[]; ticketId: string; messageId: string; uploaderId: string }) {
  const saved = [];
  for (const file of files) {
    if (file.size > MAX_FILE_BYTES) throw new Error(`Datei ist zu groß. Maximal ${MAX_FILE_MB} MB pro Datei.`);
    const buffer = Buffer.from(await file.arrayBuffer());
    const validated = assertSafeUpload(file, buffer);
    const relativePath = path.posix.join("tickets", ticketId, validated.storageName);
    const absolutePath = storagePath(relativePath);

    await mkdir(path.dirname(absolutePath), { recursive: true });
    await writeFile(absolutePath, buffer);

    const id = randomUUID();
    const attachment = await prisma.ticketAttachment.create({
      data: {
        id,
        ticketId,
        ticketMessageId: messageId,
        uploaderId,
        name: validated.originalName,
        originalName: validated.originalName,
        storagePath: relativePath,
        url: `/api/files/tickets/${id}`,
        mimeType: validated.mimeType,
        size: validated.size
      }
    });
    saved.push(attachment);
  }
  return saved;
}

export function formatBytes(size: number) {
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}
