import path from "node:path";
import { randomUUID } from "node:crypto";
import { storageRoot } from "./env";

export const MAX_FILE_MB = Number(process.env.MAX_UPLOAD_MB || 10);
export const MAX_FILE_BYTES = Math.max(1, Math.min(MAX_FILE_MB, 50)) * 1024 * 1024;
export const MAX_FILES = 5;

export const ALLOWED_MIME_TYPES = [
  "image/png",
  "image/jpeg",
  "image/webp",
  "image/gif",
  "application/pdf",
  "text/plain",
  "audio/mpeg",
  "audio/wav",
  "audio/ogg",
  "audio/webm",
  "video/mp4"
] as const;

const allowedMimeSet = new Set<string>(ALLOWED_MIME_TYPES);
const dangerousExt = new Set([".svg", ".html", ".htm", ".xml", ".xhtml", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx", ".php", ".exe", ".msi", ".bat", ".cmd", ".ps1", ".vbs", ".jar", ".scr", ".com", ".dll", ".sh"]);

export const mimeByExtension: Record<string, string> = {
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".gif": "image/gif",
  ".webp": "image/webp",
  ".pdf": "application/pdf",
  ".txt": "text/plain",
  ".mp3": "audio/mpeg",
  ".wav": "audio/wav",
  ".ogg": "audio/ogg",
  ".oga": "audio/ogg",
  ".opus": "audio/ogg",
  ".weba": "audio/webm",
  ".mp4": "video/mp4",
  ".m4a": "audio/mpeg"
};

const inlineMime = new Set(["image/png", "image/jpeg", "image/webp", "image/gif", "audio/mpeg", "audio/wav", "audio/ogg", "audio/webm", "video/mp4"]);

export type ValidatedUpload = {
  originalName: string;
  safeOriginalName: string;
  ext: string;
  mimeType: string;
  size: number;
  buffer: Buffer;
  storageName: string;
};

export function safeFileName(input: string) {
  const clean = input
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z0-9._ -]/g, "-")
    .replace(/\s+/g, " ")
    .replace(/-+/g, "-")
    .replace(/^\.+/, "")
    .trim()
    .slice(0, 140);
  return clean || "datei";
}

export function extension(name: string) {
  return path.extname(name).toLowerCase();
}

export function mimeFromName(name: string) {
  return mimeByExtension[extension(name)] || "application/octet-stream";
}

function detectByMagic(buffer: Buffer, ext: string) {
  if (buffer.length >= 12) {
    if (buffer.subarray(0, 3).equals(Buffer.from([0xff, 0xd8, 0xff]))) return "image/jpeg";
    if (buffer.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return "image/png";
    if (["GIF87a", "GIF89a"].includes(buffer.subarray(0, 6).toString("ascii"))) return "image/gif";
    if (buffer.subarray(0, 4).toString("ascii") === "RIFF" && buffer.subarray(8, 12).toString("ascii") === "WEBP") return "image/webp";
    if (buffer.subarray(0, 4).toString("ascii") === "%PDF") return "application/pdf";
    if (buffer.subarray(0, 4).toString("ascii") === "OggS") return ext === ".weba" ? "audio/webm" : "audio/ogg";
    if (buffer.subarray(0, 4).toString("ascii") === "RIFF" && buffer.subarray(8, 12).toString("ascii") === "WAVE") return "audio/wav";
    if (buffer.subarray(0, 3).toString("ascii") === "ID3" || (buffer[0] === 0xff && (buffer[1] & 0xe0) === 0xe0)) return "audio/mpeg";
    if (buffer.subarray(4, 8).toString("ascii") === "ftyp") return "video/mp4";
  }
  if (ext === ".txt") {
    const sample = buffer.subarray(0, Math.min(buffer.length, 512));
    if (!sample.includes(0)) return "text/plain";
  }
  return "application/octet-stream";
}

export function assertSafeUpload(file: File, buffer: Buffer): ValidatedUpload {
  if (!file || file.size <= 0) throw new Error("Datei ist leer.");
  if (file.size > MAX_FILE_BYTES) throw new Error(`Datei ist zu groß. Maximal ${MAX_FILE_MB} MB pro Datei.`);

  const originalName = file.name || "datei";
  const safeOriginalName = safeFileName(originalName);
  const ext = extension(safeOriginalName);
  if (!ext || dangerousExt.has(ext)) throw new Error("Dieser Dateityp ist aus Sicherheitsgründen nicht erlaubt.");

  const extMime = mimeFromName(safeOriginalName);
  const magicMime = detectByMagic(buffer, ext);
  const browserMime = file.type || "application/octet-stream";
  const mimeType = magicMime !== "application/octet-stream" ? magicMime : extMime;

  if (!allowedMimeSet.has(mimeType)) throw new Error("Dieser Dateityp ist nicht erlaubt.");
  if (extMime !== "application/octet-stream" && extMime !== mimeType) throw new Error("Dateiendung und Dateityp passen nicht zusammen.");
  if (browserMime !== "application/octet-stream" && browserMime && !browserMime.startsWith("text/") && browserMime !== mimeType && !(browserMime === "audio/mp4" && mimeType === "video/mp4")) {
    throw new Error("Dateityp konnte nicht sicher bestätigt werden.");
  }

  return { originalName, safeOriginalName, ext, mimeType, size: file.size, buffer, storageName: `${Date.now()}-${randomUUID()}${ext}` };
}

export function canInlinePreview(name: string, mimeType: string) {
  if (dangerousExt.has(extension(name))) return false;
  return inlineMime.has(mimeType);
}

export function safeResponseMime(name: string, mimeType: string) {
  if (!allowedMimeSet.has(mimeType) || dangerousExt.has(extension(name))) return "application/octet-stream";
  return mimeType;
}

export function contentDisposition(name: string, mimeType: string) {
  const type = canInlinePreview(name, mimeType) ? "inline" : "attachment";
  const safe = safeFileName(name).replace(/[\r\n"]/g, "-");
  return `${type}; filename="${safe}"; filename*=UTF-8''${encodeURIComponent(safe)}`;
}

export function filesFromFormData(formData: FormData, field = "files") {
  const values = formData.getAll(field);
  return values.filter((value): value is File => typeof value === "object" && value instanceof File && value.size > 0).slice(0, MAX_FILES);
}

export function storagePath(...parts: string[]) {
  const root = path.resolve(storageRoot);
  const resolved = path.resolve(root, ...parts);
  if (!(resolved === root || resolved.startsWith(`${root}${path.sep}`))) throw new Error("Ungültiger Speicherpfad.");
  return resolved;
}
