import prisma from "./prisma";

export const SERVER_PERMISSIONS = [
  "MANAGE_SERVER",
  "MANAGE_CHANNELS",
  "MANAGE_ROLES",
  "MANAGE_MESSAGES",
  "KICK_MEMBERS",
  "BAN_MEMBERS",
  "CREATE_INVITES",
  "VIEW_AUDIT_LOG",
  "VIEW_CHANNEL",
  "SEND_MESSAGES",
  "UPLOAD_FILES",
  "MENTION_EVERYONE",
  "MANAGE_TICKETS"
] as const;

export type ServerPermission = typeof SERVER_PERMISSIONS[number] | "*";
const allowed = new Set<string>([...SERVER_PERMISSIONS, "*"]);
const legacyMap: Record<string, ServerPermission> = {
  manage_server: "MANAGE_SERVER",
  manage_channels: "MANAGE_CHANNELS",
  manage_roles: "MANAGE_ROLES",
  manage_members: "KICK_MEMBERS",
  kick_members: "KICK_MEMBERS",
  ban_members: "BAN_MEMBERS",
  create_invites: "CREATE_INVITES",
  send_messages: "SEND_MESSAGES",
  manage_messages: "MANAGE_MESSAGES",
  upload_files: "UPLOAD_FILES",
  view_channel: "VIEW_CHANNEL",
  view_audit_log: "VIEW_AUDIT_LOG",
  mention_everyone: "MENTION_EVERYONE",
  manage_tickets: "MANAGE_TICKETS"
};

type LoadedRoleAssignment = { roleId: string; role: { permissions: string; position: number; name?: string } };

type PermissionOverride = {
  memberId: string | null;
  roleId: string | null;
  allow: string[];
  deny: string[];
};

export function normalizePermission(input: string): ServerPermission | null {
  const clean = String(input || "").trim();
  if (!clean) return null;
  const mapped = legacyMap[clean] || clean.toUpperCase();
  return allowed.has(mapped) ? (mapped as ServerPermission) : null;
}

export function sanitizePermissions(input: unknown): ServerPermission[] {
  const list = Array.isArray(input) ? input : [];
  return Array.from(new Set(list.map((item) => normalizePermission(String(item))).filter(Boolean))) as ServerPermission[];
}

export function parseRolePermissions(raw: string | null | undefined): ServerPermission[] {
  try { return sanitizePermissions(JSON.parse(raw || "[]")); } catch { return []; }
}

export async function getServerMemberPermissions(serverId: string, userId: string, isGlobalAdmin = false) {
  const server = await prisma.server.findUnique({ where: { id: serverId }, select: { ownerId: true } });
  const member = await prisma.serverMember.findUnique({
    where: { serverId_userId: { serverId, userId } },
    include: { roleAssignments: { include: { role: true } } }
  });
  if (!server || !member) return null;

  const permissions = new Set<ServerPermission>();
  if (isGlobalAdmin || server.ownerId === userId || member.isOwner || member.isAdmin) permissions.add("*");
  permissions.add("VIEW_CHANNEL");
  permissions.add("SEND_MESSAGES");
  permissions.add("UPLOAD_FILES");

  const assignments = member.roleAssignments as LoadedRoleAssignment[];
  for (const assignment of assignments) {
    for (const permission of parseRolePermissions(assignment.role.permissions)) permissions.add(permission);
  }

  let maxRolePosition = member.isOwner || server.ownerId === userId ? Number.MAX_SAFE_INTEGER : member.isAdmin ? 9999 : 0;
  for (const assignment of assignments) maxRolePosition = Math.max(maxRolePosition, assignment.role.position);

  return { member, permissions, maxRolePosition, isOwner: server.ownerId === userId || member.isOwner };
}

export function hasPermission(state: Awaited<ReturnType<typeof getServerMemberPermissions>>, permission: ServerPermission) {
  if (!state) return false;
  return state.permissions.has("*") || state.permissions.has(permission);
}

export async function requireServerPermission(serverId: string, user: { id: string; isAdmin: boolean }, permission: ServerPermission) {
  const state = await getServerMemberPermissions(serverId, user.id, user.isAdmin);
  return hasPermission(state, permission) ? state : null;
}

function applyOverrides(base: boolean, overrides: PermissionOverride[], roleIds: Set<string>, memberId: string, permission: ServerPermission) {
  // Phase 33 permission semantics: role allows build the baseline, role denies remove it,
  // then explicit user overrides win; within the same override Deny always beats Allow.
  let current = base;
  for (const override of overrides.filter((item) => item.roleId && roleIds.has(item.roleId))) {
    const allow = sanitizePermissions(override.allow).includes(permission);
    const deny = sanitizePermissions(override.deny).includes(permission);
    if (allow) current = true;
    if (deny) current = false;
  }
  const userOverride = overrides.find((override) => override.memberId === memberId);
  if (userOverride) {
    const allow = sanitizePermissions(userOverride.allow).includes(permission);
    const deny = sanitizePermissions(userOverride.deny).includes(permission);
    if (allow) current = true;
    if (deny) current = false;
  }
  return current;
}

export async function canAccessChannel(channelId: string, userId: string, isGlobalAdmin = false, required: ServerPermission = "VIEW_CHANNEL") {
  const channel = await prisma.channel.findUnique({
    where: { id: channelId },
    include: {
      permissionOverrides: true,
      server: { select: { id: true, ownerId: true } }
    }
  });
  if (!channel) return null;

  const state = await getServerMemberPermissions(channel.serverId, userId, isGlobalAdmin);
  if (!state) return null;
  if (state.permissions.has("*")) return channel;

  const roleIds = new Set((state.member.roleAssignments as Array<{ roleId: string }>).map((assignment) => assignment.roleId));
  const overrides = channel.permissionOverrides as PermissionOverride[];

  let canView = hasPermission(state, "VIEW_CHANNEL");
  if (channel.isPrivate) canView = false;
  canView = applyOverrides(canView, overrides, roleIds, state.member.id, "VIEW_CHANNEL");
  if (!canView) return null;

  if (required === "VIEW_CHANNEL") return channel;

  const allowedForAction = applyOverrides(hasPermission(state, required), overrides, roleIds, state.member.id, required);
  return allowedForAction ? channel : null;
}

export async function getAuthorizedChannelUserIds(channelId: string, permission: ServerPermission = "VIEW_CHANNEL") {
  const channel = await prisma.channel.findUnique({ where: { id: channelId }, select: { serverId: true } });
  if (!channel) return [] as string[];
  const members = await prisma.serverMember.findMany({ where: { serverId: channel.serverId }, select: { userId: true } });
  const ids: string[] = [];
  for (const member of members) {
    if (await canAccessChannel(channelId, member.userId, false, permission)) ids.push(member.userId);
  }
  return ids;
}

export async function filterVisibleChannelsForUser<T extends { id: string }>(channels: T[], user: { id: string; isAdmin: boolean }) {
  const visible: T[] = [];
  for (const channel of channels) {
    if (await canAccessChannel(channel.id, user.id, user.isAdmin, "VIEW_CHANNEL")) visible.push(channel);
  }
  return visible;
}

export async function canManageRole(serverId: string, actor: { id: string; isAdmin: boolean }, targetRoleId?: string) {
  const state = await requireServerPermission(serverId, actor, "MANAGE_ROLES");
  if (!state) return null;
  if (state.isOwner || state.permissions.has("*")) return state;
  if (!targetRoleId) return state;
  const role = await prisma.role.findFirst({ where: { id: targetRoleId, serverId }, select: { name: true, position: true } });
  if (!role || role.name.toLowerCase() === "owner") return null;
  return role.position < state.maxRolePosition ? state : null;
}

export async function canManageMember(serverId: string, actor: { id: string; isAdmin: boolean }, targetMemberId: string, required: ServerPermission) {
  const state = await requireServerPermission(serverId, actor, required);
  if (!state) return null;
  const target = await prisma.serverMember.findFirst({
    where: { id: targetMemberId, serverId },
    include: { roleAssignments: { include: { role: true } } }
  });
  if (!target) return null;
  if (target.isOwner) return null;
  if (state.isOwner || state.permissions.has("*")) return { state, target };
  if (target.userId === actor.id) return null;
  const highestTargetRole = Math.max(0, target.isAdmin ? 9999 : 0, ...target.roleAssignments.map((assignment: { role: { position: number } }) => assignment.role.position));
  if (highestTargetRole >= state.maxRolePosition) return null;
  return { state, target };
}

export async function canAssignRoles(serverId: string, actor: { id: string; isAdmin: boolean }, roleIds: string[]) {
  const state = await requireServerPermission(serverId, actor, "MANAGE_ROLES");
  if (!state) return null;
  const roles = await prisma.role.findMany({ where: { serverId, id: { in: roleIds } }, select: { id: true, name: true, position: true } });
  if (roles.length !== new Set(roleIds).size) return null;
  if (state.isOwner || state.permissions.has("*")) return { state, roles };
  if (roles.some((role: { name: string; position: number }) => role.name.toLowerCase() === "owner" || role.position >= state.maxRolePosition)) return null;
  return { state, roles };
}
