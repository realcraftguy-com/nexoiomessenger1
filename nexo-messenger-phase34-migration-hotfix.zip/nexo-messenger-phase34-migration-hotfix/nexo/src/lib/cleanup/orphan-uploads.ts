import { unlink } from "node:fs/promises";
import prisma from "../prisma";
import { storagePath } from "../upload-security";

export async function cleanupOrphanMessageUploads(maxAgeMs = 60 * 60 * 1000) {
  const cutoff = new Date(Date.now() - maxAgeMs);
  const rows = await prisma.messageAttachment.findMany({
    where: { messageId: null, dmMessageId: null, createdAt: { lt: cutoff } },
    select: { id: true, storagePath: true }
  });

  let deletedFiles = 0;
  for (const row of rows) {
    if (row.storagePath) {
      await unlink(storagePath(row.storagePath)).then(() => { deletedFiles += 1; }).catch(() => undefined);
    }
  }
  if (rows.length) await prisma.messageAttachment.deleteMany({ where: { id: { in: rows.map((row: { id: string }) => row.id) } } });
  return { deletedRows: rows.length, deletedFiles };
}
