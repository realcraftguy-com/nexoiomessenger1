import prisma from "./prisma";

export async function areUsersBlocked(userAId: string, userBId: string) {
  const block = await prisma.blockedUser.findFirst({
    where: {
      OR: [
        { blockerId: userAId, blockedId: userBId },
        { blockerId: userBId, blockedId: userAId }
      ]
    },
    select: { id: true }
  }).catch(() => null);
  return Boolean(block);
}

export async function dmThreadOtherUserId(threadId: string, userId: string) {
  const other = await prisma.directMessageThreadMember.findFirst({ where: { threadId, userId: { not: userId } }, select: { userId: true } });
  return other?.userId || null;
}
