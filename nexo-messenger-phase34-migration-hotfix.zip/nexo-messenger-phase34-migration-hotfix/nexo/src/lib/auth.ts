import { cookies } from "next/headers";
import { SignJWT, jwtVerify } from "jose";
import { redirect } from "next/navigation";
import prisma from "./prisma";
import { getJwtSecret, isAdminEmail } from "./env";

const cookieName = "nexo_token";

type SessionPayload = {
  userId: string;
  email: string;
  username: string;
  isAdmin: boolean;
  sessionVersion: number;
};

function secret() {
  const value = getJwtSecret();
  return new TextEncoder().encode(value);
}

export async function createSessionCookie(user: { id: string; email: string; username: string; sessionVersion?: number }) {
  const days = Number(process.env.SESSION_DAYS || 14);
  const payload: SessionPayload = {
    userId: user.id,
    email: user.email,
    username: user.username,
    isAdmin: isAdminEmail(user.email),
    sessionVersion: Number(user.sessionVersion ?? 0)
  };

  const token = await new SignJWT(payload)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(`${days}d`)
    .sign(secret());

  cookies().set(cookieName, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: days * 24 * 60 * 60
  });
}

export function clearSessionCookie() {
  cookies().delete(cookieName);
}

export async function verifyToken(token?: string): Promise<SessionPayload | null> {
  if (!token) return null;
  try {
    const result = await jwtVerify(token, secret());
    const payload = result.payload as unknown as SessionPayload;
    if (!payload.userId || !payload.email) return null;
    return { ...payload, sessionVersion: Number(payload.sessionVersion ?? 0), isAdmin: isAdminEmail(payload.email) };
  } catch {
    return null;
  }
}

export async function getSession() {
  return verifyToken(cookies().get(cookieName)?.value);
}

export async function getCurrentUser() {
  const session = await getSession();
  if (!session) return null;

  const user = await prisma.user.findUnique({
    where: { id: session.userId },
    select: {
      id: true,
      email: true,
      username: true,
      displayName: true,
      avatarUrl: true,
      avatarColor: true,
      bio: true,
      pronouns: true,
      location: true,
      customStatus: true,
      accentColor: true,
      compactMode: true,
      reduceMotion: true,
      showOnline: true,
      allowDmRequests: true,
      twoFactorEnabled: true,
      aiDisabled: true,
      status: true,
      onboarded: true,
      isBanned: true,
      banReason: true,
      bannedAt: true,
      sessionVersion: true,
      createdAt: true
    }
  });

  if (!user || user.isBanned) return null;
  if (Number(user.sessionVersion ?? 0) !== Number(session.sessionVersion ?? 0)) return null;
  return { ...user, isAdmin: isAdminEmail(user.email) };
}

export async function requireUser() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  return user;
}

export async function requireAdmin() {
  const user = await requireUser();
  if (!user.isAdmin) redirect("/app");
  return user;
}

export { cookieName };
