import type { Server as SocketServer } from "socket.io";
import prisma from "./prisma";
import { getAuthorizedChannelUserIds, type ServerPermission } from "./permissions";

let ioRef: SocketServer | null = null;

export function registerLiveServer(io: SocketServer) {
  ioRef = io;
}

export function hasLiveServer() {
  return Boolean(ioRef);
}

export function emitToAdmins(event: string, payload: unknown) {
  ioRef?.to("admins").emit(event, payload);
}

export function emitToUser(userId: string, event: string, payload: unknown) {
  ioRef?.to(`user:${userId}`).emit(event, payload);
}

export function emitToTicket(ticketId: string, event: string, payload: unknown) {
  ioRef?.to(`ticket:${ticketId}`).to("admins").emit(event, payload);
}

export async function emitToDmMembers(threadId: string, event: string, payload: unknown, excludeUserId?: string) {
  if (!ioRef) return;
  const members = await prisma.directMessageThreadMember.findMany({ where: { threadId }, select: { userId: true } }).catch(() => []);
  for (const member of members) {
    if (member.userId !== excludeUserId) ioRef.to(`user:${member.userId}`).emit(event, payload);
  }
}

function safeServerChangedPayload(serverId: string, event: string, payload: unknown) {
  const object = payload && typeof payload === "object" && !Array.isArray(payload) ? payload as Record<string, unknown> : {};
  return {
    serverId,
    sourceEvent: event,
    action: typeof object.action === "string" ? object.action : "changed",
    target: typeof object.target === "string" ? object.target : undefined,
    at: new Date().toISOString()
  };
}

function minimalChannelPayload(serverId: string, event: string, payload: unknown) {
  const object = payload && typeof payload === "object" && !Array.isArray(payload) ? payload as Record<string, unknown> : {};
  return {
    serverId,
    sourceEvent: event,
    action: typeof object.action === "string" ? object.action : "changed",
    target: "channel",
    at: new Date().toISOString()
  };
}

async function channelPrivacyFromPayload(serverId: string, payload: Record<string, unknown>) {
  const channel = payload.channel && typeof payload.channel === "object" ? payload.channel as { id?: unknown; isPrivate?: unknown } : null;
  const channelId = typeof payload.channelId === "string" ? payload.channelId : typeof channel?.id === "string" ? channel.id : null;
  if (!channelId) return null;
  const currentChannel = await prisma.channel.findFirst({ where: { id: channelId, serverId }, select: { id: true, isPrivate: true } }).catch(() => null);
  if (!currentChannel && payload.action === "deleted") return { channelId, isPrivate: Boolean(channel?.isPrivate), deleted: true };
  if (!currentChannel) return null;
  return { channelId: currentChannel.id, isPrivate: currentChannel.isPrivate, deleted: false };
}

async function emitPrivateChannelPayload(channelId: string, event: string, payload: unknown, permission: ServerPermission = "VIEW_CHANNEL", excludeUserId?: string) {
  if (!ioRef) return;
  const ids = await getAuthorizedChannelUserIds(channelId, permission).catch(() => []);
  for (const id of ids) {
    if (id !== excludeUserId) ioRef.to(`user:${id}`).emit(event, payload);
  }
}

export async function emitToServerMembers(serverId: string, event: string, payload: unknown) {
  if (!ioRef) return;
  const object = payload && typeof payload === "object" && !Array.isArray(payload) ? payload as Record<string, unknown> : {};
  const channelInfo = event.startsWith("server:channel:") ? await channelPrivacyFromPayload(serverId, object) : null;

  if (channelInfo?.isPrivate && !channelInfo.deleted) {
    await emitPrivateChannelPayload(channelInfo.channelId, event, payload, "VIEW_CHANNEL");
  } else if (!channelInfo?.isPrivate) {
    // Public server changes may go to the server room. The payload can contain a public channel object.
    ioRef.to(`server:${serverId}`).emit(event, payload);
  }

  if (event.startsWith("server:") && event !== "server:changed") {
    const changePayload = channelInfo?.isPrivate ? minimalChannelPayload(serverId, event, payload) : safeServerChangedPayload(serverId, event, payload);
    ioRef.to(`server:${serverId}`).emit("server:changed", changePayload);
    ioRef.to("admins").emit("admin:server:changed", changePayload);
  }
}

export async function emitServerChanged(serverId: string, sourceEvent = "server:changed", action = "changed") {
  await emitToServerMembers(serverId, "server:changed", { serverId, sourceEvent, action });
}

export async function emitChannelEvent(channelId: string, event: string, payload: unknown, permission: ServerPermission = "VIEW_CHANNEL", excludeUserId?: string) {
  if (!ioRef) return;
  const channel = await prisma.channel.findUnique({ where: { id: channelId }, select: { isPrivate: true } }).catch(() => null);
  if (!channel) return;
  if (channel.isPrivate) {
    await emitPrivateChannelPayload(channelId, event, payload, permission, excludeUserId);
    return;
  }
  ioRef.to(`channel:${channelId}`).emit(event, payload);
}

export async function emitChannelTyping(channelId: string, payload: unknown, excludeUserId: string) {
  if (!ioRef) return;
  const ids = await getAuthorizedChannelUserIds(channelId, "VIEW_CHANNEL").catch(() => []);
  for (const id of ids) {
    if (id !== excludeUserId) ioRef.to(`user:${id}`).emit("channel:typing", payload);
  }
}

export async function emitChannelRoomRecheck(channelId: string) {
  if (!ioRef) return;
  const sockets = await ioRef.in(`channel:${channelId}`).fetchSockets().catch(() => []);
  const allowed = new Set(await getAuthorizedChannelUserIds(channelId, "VIEW_CHANNEL").catch(() => []));
  for (const socket of sockets) {
    const userId = String(socket.data?.user?.id || "");
    if (!allowed.has(userId)) await socket.leave(`channel:${channelId}`);
  }
}

export async function emitServerPrivateChannelsRecheck(serverId: string) {
  const channels = await prisma.channel.findMany({ where: { serverId, isPrivate: true }, select: { id: true } }).catch(() => []);
  for (const channel of channels) await emitChannelRoomRecheck(channel.id);
}

export function emitAdminRefresh(reason: string, payload: Record<string, unknown> = {}) {
  emitToAdmins("admin:overview:refresh", { reason, ...payload, at: new Date().toISOString() });
}
