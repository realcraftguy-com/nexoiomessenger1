import { isProductionMode } from "./env";
import { parseRedisIntegerResponse, redisCommand } from "./redis";

type Bucket = { count: number; resetAt: number };
const buckets = new Map<string, Bucket>();
let warnedMemory = false;

function memoryRateLimit(key: string, limit: number, windowMs: number) {
  if (!warnedMemory && !isProductionMode()) {
    console.warn("[Nexo rate-limit] Redis nicht verfügbar. Development-Memory-Fallback aktiv.");
    warnedMemory = true;
  }
  const now = Date.now();
  const bucket = buckets.get(key);
  if (!bucket || bucket.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return { ok: true, remaining: limit - 1, resetAt: now + windowMs };
  }
  bucket.count += 1;
  return { ok: bucket.count <= limit, remaining: Math.max(0, limit - bucket.count), resetAt: bucket.resetAt };
}

export async function rateLimit(key: string, limit = 30, windowMs = 60_000) {
  const safeKey = `nexo:rl:${key.replace(/[^a-zA-Z0-9:_@.-]/g, "_")}`;
  try {
    const incr = await redisCommand(["INCR", safeKey]);
    const count = parseRedisIntegerResponse(incr);
    if (!Number.isFinite(count)) throw new Error("Invalid Redis response");
    if (count === 1) await redisCommand(["PEXPIRE", safeKey, String(windowMs)]).catch(() => undefined);
    return { ok: count <= limit, remaining: Math.max(0, limit - count), resetAt: Date.now() + windowMs };
  } catch (error) {
    if (isProductionMode()) {
      console.error("[Nexo rate-limit] Redis nicht erreichbar, Memory-Fallback wird nur als Schutznetz benutzt.", error);
    }
    return memoryRateLimit(safeKey, limit, windowMs);
  }
}

export const rateLimits = {
  login: (ip: string, email: string) => rateLimit(`login:${ip}:${email.toLowerCase()}`, 5, 10 * 60_000),
  register: (ip: string) => rateLimit(`register:${ip}`, 3, 60 * 60_000),
  message: (userId: string, scope: string) => rateLimit(`message:${userId}:${scope}`, 10, 10_000),
  upload: (userId: string) => rateLimit(`upload:${userId}`, 20, 60 * 60_000),
  ticket: (userId: string) => rateLimit(`ticket:${userId}`, 5, 60 * 60_000),
  aiUser: (userId: string) => rateLimit(`ai:${userId}`, 30, 60 * 60_000),
  aiGlobal: () => rateLimit("ai:global", 300, 60 * 60_000),
  passwordReset: (key: string) => rateLimit(`password-reset:${key}`, 3, 60 * 60_000)
};
