import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import prisma from "./prisma";
import { assertSafeUpload, filesFromFormData as baseFilesFromFormData, MAX_FILE_BYTES, MAX_FILE_MB, storagePath } from "./upload-security";

export type MessageAttachment = {
  id: string;
  name: string;
  url: string;
  mimeType: string;
  size: number;
};

type PayloadWithAttachments = {
  attachmentIds?: string[];
  attachments?: Array<{ id?: string; url?: string }>;
};

export const filesFromFormData = baseFilesFromFormData;

export function clientMessageAttachment(file: { id: string; originalName: string; mimeType: string; size: number }): MessageAttachment {
  return { id: file.id, name: file.originalName, url: `/api/files/messages/${file.id}`, mimeType: file.mimeType, size: file.size };
}

export function attachmentIdsFromPayload(input: PayloadWithAttachments | unknown): string[] {
  if (!input || typeof input !== "object") return [];
  const payload = input as PayloadWithAttachments;
  const raw = [
    ...(Array.isArray(payload.attachmentIds) ? payload.attachmentIds : []),
    ...(Array.isArray(payload.attachments) ? payload.attachments.map((item) => item.id || "") : [])
  ];
  return Array.from(new Set(raw.map((id) => String(id || "").trim()).filter((id) => /^[a-zA-Z0-9_-]{8,160}$/.test(id)))).slice(0, 5);
}

export async function saveMessageAttachments({ files, uploaderId }: { files: File[]; uploaderId: string }): Promise<MessageAttachment[]> {
  const saved: MessageAttachment[] = [];

  for (const file of files) {
    if (file.size > MAX_FILE_BYTES) throw new Error(`Datei ist zu groß. Maximal ${MAX_FILE_MB} MB pro Datei.`);
    const buffer = Buffer.from(await file.arrayBuffer());
    const validated = assertSafeUpload(file, buffer);
    const relativePath = path.posix.join("messages", uploaderId, validated.storageName);
    const absolutePath = storagePath(relativePath);

    await mkdir(path.dirname(absolutePath), { recursive: true });
    await writeFile(absolutePath, buffer);

    const row = await prisma.messageAttachment.create({
      data: {
        uploaderId,
        storagePath: relativePath,
        originalName: validated.originalName,
        mimeType: validated.mimeType,
        size: validated.size
      }
    });
    saved.push(clientMessageAttachment(row));
  }

  return saved;
}

export async function attachMessageFilesByIds({ uploaderId, attachmentIds, messageId, dmMessageId }: { uploaderId: string; attachmentIds: string[]; messageId?: string; dmMessageId?: string }) {
  const ids = Array.from(new Set(attachmentIds)).slice(0, 5);
  if (!ids.length) return [];

  const rows = await prisma.messageAttachment.findMany({
    where: { id: { in: ids }, uploaderId, messageId: null, dmMessageId: null },
    orderBy: { createdAt: "asc" }
  });
  if (rows.length !== ids.length) throw new Error("Eine Datei ist ungültig, gehört dir nicht oder wurde bereits verwendet.");

  await prisma.messageAttachment.updateMany({
    where: { id: { in: ids }, uploaderId, messageId: null, dmMessageId: null },
    data: { messageId: messageId || null, dmMessageId: dmMessageId || null }
  });
  return prisma.messageAttachment.findMany({ where: { id: { in: ids }, uploaderId }, orderBy: { createdAt: "asc" } });
}

export async function attachMessageFiles({ uploaderId, attachments, messageId, dmMessageId }: { uploaderId: string; attachments: unknown; messageId?: string; dmMessageId?: string }) {
  return attachMessageFilesByIds({ uploaderId, attachmentIds: attachmentIdsFromPayload({ attachments: attachments as PayloadWithAttachments["attachments"] }), messageId, dmMessageId });
}

type DbFileAttachment = { id: string; originalName: string; mimeType: string; size: number };

export function normalizeMessageForClient<T extends { attachments?: string | null; fileAttachments?: DbFileAttachment[] }>(message: T) {
  const files = Array.isArray(message.fileAttachments) && message.fileAttachments.length
    ? message.fileAttachments.map(clientMessageAttachment)
    : undefined;
  return { ...message, attachments: files ?? message.attachments ?? "[]" };
}

export function formatBytes(size: number) {
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}
