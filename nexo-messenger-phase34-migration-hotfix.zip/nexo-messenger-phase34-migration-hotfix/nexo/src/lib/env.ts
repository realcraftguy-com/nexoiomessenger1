const isProduction = process.env.NODE_ENV === "production";

function warn(message: string) {
  if (!isProduction) console.warn(`[Nexo config] ${message}`);
}

function required(name: string, fallback?: string) {
  const value = process.env[name]?.trim();
  if (value) return value;
  if (isProduction) throw new Error(`${name} muss in Production gesetzt sein.`);
  if (fallback !== undefined) {
    warn(`${name} fehlt. Development-Fallback wird benutzt.`);
    return fallback;
  }
  warn(`${name} fehlt.`);
  return "";
}

export function getJwtSecret() {
  const value = required("JWT_SECRET", "dev-secret-change-me-use-only-locally");
  if (value.length < 32) throw new Error("JWT_SECRET muss mindestens 32 Zeichen lang sein.");
  if (isProduction && /dev-secret|change-me|changeme/i.test(value)) throw new Error("JWT_SECRET darf in Production kein Dev-Fallback sein.");
  return value;
}

export function adminEmails() {
  return (process.env.ADMIN_EMAILS || "")
    .split(",")
    .map((mail) => mail.trim().toLowerCase())
    .filter(Boolean);
}

export function isAdminEmail(email?: string | null) {
  if (!email) return false;
  return adminEmails().includes(email.toLowerCase());
}

export const appUrl = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";
export const allowedOrigins = (process.env.ALLOWED_ORIGINS || appUrl)
  .split(",")
  .map((origin) => origin.trim())
  .filter(Boolean);
export const maxMessageLength = Number(process.env.MAX_MESSAGE_LENGTH || 4000);
export const storageRoot = process.env.STORAGE_DIR || "storage";

export function requireSeedPassword() {
  const value = process.env.SEED_ADMIN_PASSWORD?.trim();
  if (value) return value;
  if (isProduction) throw new Error("SEED_ADMIN_PASSWORD muss in Production gesetzt sein.");
  warn("SEED_ADMIN_PASSWORD fehlt. Development-Passwort wird nur lokal benutzt.");
  return "NexoDevAdmin123!";
}

export function isProductionMode() {
  return isProduction;
}
