import { jwtVerify } from "jose";
import { getJwtSecret, isAdminEmail } from "./env";

const cookieName = "nexo_token";

function secret() {
  return new TextEncoder().encode(getJwtSecret());
}

export async function verifySocketCookie(cookieHeader?: string) {
  const token = cookieHeader
    ?.split(";")
    .map((part) => part.trim().split("="))
    .find(([key]) => key === cookieName)?.[1];
  if (!token) return null;

  try {
    const result = await jwtVerify(token, secret());
    const payload = result.payload as { userId?: string; email?: string; username?: string; sessionVersion?: number };
    if (!payload.userId || !payload.email) return null;
    return {
      userId: payload.userId,
      email: payload.email,
      username: payload.username || "user",
      sessionVersion: Number(payload.sessionVersion ?? 0),
      isAdmin: isAdminEmail(payload.email)
    };
  } catch {
    return null;
  }
}
