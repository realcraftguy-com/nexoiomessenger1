import type { Metadata, Viewport } from "next";
import { ToastProvider } from "@/components/providers/toast-provider";
import "@/styles/globals.css";

export const metadata: Metadata = {
  title: "Nexo Messenger",
  description: "Ein moderner Messenger für Schule, Freunde und Teams.",
  manifest: "/manifest.json",
  appleWebApp: { capable: true, title: "Nexo", statusBarStyle: "black-translucent" },
  applicationName: "Nexo"
};

export const viewport: Viewport = {
  themeColor: "#050505",
  colorScheme: "dark",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="de">
      <body><ToastProvider>{children}</ToastProvider></body>
    </html>
  );
}
