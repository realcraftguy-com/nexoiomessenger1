import { redirect } from "next/navigation";
import { MainShell } from "@/components/app/MainShell";
import { AdminTicketClient } from "@/components/admin/AdminTicketClient";
import { getCurrentUser } from "@/lib/auth";

export default async function AdminTicketPage({ params }: { params: { ticketId: string } }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (!user.isAdmin) redirect("/app");

  return (
    <MainShell title="Ticket Detail">
      <AdminTicketClient ticketId={params.ticketId} />
    </MainShell>
  );
}
