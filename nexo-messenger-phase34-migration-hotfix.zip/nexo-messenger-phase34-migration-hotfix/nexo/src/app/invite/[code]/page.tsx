import { InviteClient } from "@/components/invite/InviteClient";

export default function InvitePage({ params }: { params: { code: string } }) {
  return <InviteClient code={params.code} />;
}
