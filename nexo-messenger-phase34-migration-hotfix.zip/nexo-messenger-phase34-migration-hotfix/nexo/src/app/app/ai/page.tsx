import { MainShell } from "@/components/app/MainShell";
import { AIChatClient } from "@/components/ai/AIChatClient";

export default function AIPage() {
  return (
    <MainShell title="Nexo AI">
      <AIChatClient />
    </MainShell>
  );
}
