import { requireAdmin } from "@/lib/auth";
import { MainShell } from "@/components/app/MainShell";
import { AdminPanelClient } from "@/components/admin/AdminPanelClient";

export default async function AdminPage() {
  await requireAdmin();
  return (
    <MainShell title="Admin Dashboard">
      <AdminPanelClient />
    </MainShell>
  );
}
