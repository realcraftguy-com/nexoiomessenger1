import { MainShell } from "@/components/app/MainShell";
import { SettingsClient } from "@/components/settings/SettingsClient";

export default function SettingsPage() {
  return (
    <MainShell title="Einstellungen">
      <SettingsClient />
    </MainShell>
  );
}
