import { MainShell } from "@/components/app/MainShell";
import { FriendsClient } from "@/components/social/FriendsClient";

export default function FriendsPage({ params }: { params: { view: string } }) {
  const view = decodeURIComponent(params.view);
  const isDmView = view === "@me" || view === "me" || view === "%40me";
  return (
    <MainShell title="Freunde">
      {isDmView ? <FriendsClient /> : <div className="grid h-full place-items-center text-zinc-500">Diese Freunde-Seite gehört zu @me.</div>}
    </MainShell>
  );
}
