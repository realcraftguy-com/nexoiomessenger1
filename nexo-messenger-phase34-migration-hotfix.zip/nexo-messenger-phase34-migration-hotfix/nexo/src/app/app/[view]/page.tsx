import { MainShell } from "@/components/app/MainShell";
import { DirectMessagesClient } from "@/components/dm/DirectMessagesClient";

export default function DynamicAppPage({ params }: { params: { view: string } }) {
  const view = decodeURIComponent(params.view);
  const isDmView = view === "@me" || view === "me" || view === "%40me";

  if (!isDmView) {
    return (
      <MainShell title="Nexo">
        <div className="grid h-full place-items-center p-8 text-center text-zinc-500">Diese Seite existiert nicht.</div>
      </MainShell>
    );
  }

  return (
    <MainShell title="Direktnachrichten">
      <DirectMessagesClient />
    </MainShell>
  );
}
