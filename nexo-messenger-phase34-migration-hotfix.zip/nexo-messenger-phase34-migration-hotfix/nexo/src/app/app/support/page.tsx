import { MainShell } from "@/components/app/MainShell";
import { SupportClient } from "@/components/support/SupportClient";

export default function SupportPage() {
  return (
    <MainShell title="Support Tickets">
      <SupportClient />
    </MainShell>
  );
}
