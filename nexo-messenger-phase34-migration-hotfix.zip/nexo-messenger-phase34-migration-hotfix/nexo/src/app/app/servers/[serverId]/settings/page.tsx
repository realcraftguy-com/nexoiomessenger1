import { ChannelSidebar } from "@/components/app/ChannelSidebar";
import { MainShell } from "@/components/app/MainShell";
import { ServerSettingsClient } from "@/components/app/ServerSettingsClient";

export default function ServerSettingsPage({ params }: { params: { serverId: string } }) {
  return (
    <MainShell title="Server Settings" side={<ChannelSidebar serverId={params.serverId} />}>
      <ServerSettingsClient serverId={params.serverId} />
    </MainShell>
  );
}
