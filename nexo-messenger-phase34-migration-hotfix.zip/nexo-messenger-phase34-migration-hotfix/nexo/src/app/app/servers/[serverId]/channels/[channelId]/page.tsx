import { ChannelSidebar } from "@/components/app/ChannelSidebar";
import { MainShell } from "@/components/app/MainShell";
import { ServerChatClient } from "@/components/app/ServerChatClient";

export default function ChannelPage({ params }: { params: { serverId: string; channelId: string } }) {
  return (
    <MainShell title="Server" side={<ChannelSidebar serverId={params.serverId} />}>
      <ServerChatClient serverId={params.serverId} channelId={params.channelId} />
    </MainShell>
  );
}
