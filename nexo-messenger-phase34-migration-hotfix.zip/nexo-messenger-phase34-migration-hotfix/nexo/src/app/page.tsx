import Link from "next/link";
import { ArrowRight, Bot, Lock, MessageSquare, Server } from "lucide-react";

const features = [
  { icon: MessageSquare, title: "Realtime Chat", text: "Server-Channels, DMs, Typing-Indikator und flüssige Message-History." },
  { icon: Server, title: "Eigene Server", text: "Erstelle private Räume, lade Freunde ein und organisiere Chats in Channels." },
  { icon: Bot, title: "Nexo AI", text: "Ein smarter Assistent für Lernen, Schreiben, Planen und Coden." },
  { icon: Lock, title: "Privat & kontrollierbar", text: "Dein Space bleibt unter deiner Kontrolle und ist für dein Team vorbereitet." }
];

export default function LandingPage() {
  return (
    <main className="min-h-screen overflow-hidden bg-surface-950 text-white">
      <div className="absolute inset-0 bg-grid bg-[size:48px_48px] opacity-[.12]" />
      <div className="absolute left-1/2 top-0 h-[520px] w-[720px] -translate-x-1/2 rounded-full bg-white/10 blur-[140px]" />
      <section className="relative mx-auto flex min-h-screen max-w-7xl flex-col px-6 py-8">
        <nav className="flex items-center justify-between rounded-3xl border border-white/10 bg-black/30 px-5 py-4 backdrop-blur-xl">
          <Link href="/" className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-2xl border border-white/15 bg-white text-black shadow-line">
              <span className="text-sm font-black">NX</span>
            </div>
            <div>
              <p className="text-sm font-semibold leading-none">Nexo</p>
              <p className="text-xs text-zinc-500">Modern Messenger</p>
            </div>
          </Link>
          <div className="flex items-center gap-2">
            <Link href="/login" className="soft-button hidden sm:inline-flex">Login</Link>
            <Link href="/register" className="primary-button inline-flex items-center gap-2">Starten <ArrowRight size={16} /></Link>
          </div>
        </nav>

        <div className="grid flex-1 items-center gap-10 py-20 lg:grid-cols-[1.05fr_.95fr]">
          <div className="animate-fadeUp">
            <div className="mb-5 inline-flex rounded-full border border-white/10 bg-white/[.04] px-4 py-2 text-xs font-medium uppercase tracking-[.18em] text-zinc-400">
              kostenlos · modern · clean
            </div>
            <h1 className="max-w-4xl text-5xl font-semibold tracking-[-.06em] text-white sm:text-7xl lg:text-8xl">
              Chatten wie Discord, fühlen wie ein Premium Dashboard.
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-8 text-zinc-400">
              Nexo ist ein moderner Messenger mit Servern, DMs, Tickets, Admin-Panel und AI-Chat. Cleanes Design, schnelle Chats und ein Workflow, der sich hochwertig anfühlt.
            </p>
            <div className="mt-9 flex flex-wrap gap-3">
              <Link href="/register" className="primary-button inline-flex items-center gap-2 px-5 py-3">Account erstellen <ArrowRight size={16} /></Link>
              <Link href="/login" className="soft-button px-5 py-3">Einloggen</Link>
            </div>
          </div>

          <div className="panel animate-float p-3">
            <div className="rounded-[1.35rem] border border-white/10 bg-surface-900 p-4">
              <div className="mb-4 flex items-center justify-between border-b border-white/10 pb-4">
                <div>
                  <p className="text-sm font-medium"># general</p>
                  <p className="text-xs text-zinc-500">Nexo HQ</p>
                </div>
                <div className="rounded-full border border-white/10 px-3 py-1 text-xs text-zinc-400">online</div>
              </div>
              <div className="space-y-4">
                {["Willkommen in Nexo.", "Tickets, DMs und Server fühlen sich schnell und clean an.", "Nexo AI hilft direkt im Chat."].map((msg, i) => (
                  <div key={msg} className="flex gap-3">
                    <div className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl bg-white text-xs font-black text-black">{i === 0 ? "NX" : i === 1 ? "FM" : "AI"}</div>
                    <div className="min-w-0 rounded-2xl border border-white/10 bg-white/[.04] px-4 py-3">
                      <p className="text-sm text-white">{msg}</p>
                      <p className="mt-1 text-xs text-zinc-500">gerade eben</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-5 rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-zinc-500">Nachricht an #general schreiben...</div>
            </div>
          </div>
        </div>

        <div className="relative grid gap-3 pb-10 md:grid-cols-4">
          {features.map((feature) => (
            <div key={feature.title} className="rounded-3xl border border-white/10 bg-white/[.035] p-5">
              <feature.icon size={20} className="mb-4 text-white" />
              <h3 className="font-medium">{feature.title}</h3>
              <p className="mt-2 text-sm leading-6 text-zinc-500">{feature.text}</p>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
