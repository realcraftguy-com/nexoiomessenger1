import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, json } from "@/lib/http";
import { z } from "zod";
import { emitToUser } from "@/lib/live";
import { areUsersBlocked } from "@/lib/social-safety";

const userSelect = { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true, status: true } as const;
const threadInclude = { members: { include: { user: { select: userSelect } } }, requestedBy: { select: userSelect }, messages: { orderBy: { createdAt: "desc" as const }, take: 1 } };

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);
  const threads = await prisma.directMessageThread.findMany({ where: { members: { some: { userId: user.id } } }, orderBy: { updatedAt: "desc" }, include: threadInclude });
  return json({ threads });
}

export async function POST(request: Request) {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);
  const body = z.object({ userId: z.string().uuid() }).parse(await request.json());
  if (body.userId === user.id) return error("Du kannst dir nicht selbst schreiben.", 400);
  const target = await prisma.user.findUnique({ where: { id: body.userId }, select: { id: true, isBanned: true, allowDmRequests: true } });
  if (!target || target.isBanned) return error("User nicht gefunden", 404);
  if (await areUsersBlocked(user.id, body.userId)) return error("DM nicht möglich, weil einer von euch den anderen blockiert hat.", 403);
  if (target.allowDmRequests === false) return error("Dieser User nimmt aktuell keine Nachrichtenanfragen an.", 403);
  const existing = await prisma.directMessageThread.findFirst({ where: { AND: [{ members: { some: { userId: user.id } } }, { members: { some: { userId: body.userId } } }] }, include: threadInclude });
  if (existing && existing.members.length === 2) {
    if (existing.status === "ACCEPTED") return json({ thread: existing, state: "accepted" });
    const outgoing = existing.requestedById === user.id;
    return json({ thread: existing, state: outgoing ? "pending_outgoing" : "pending_incoming" });
  }
  const thread = await prisma.directMessageThread.create({ data: { status: "PENDING", requestedById: user.id, members: { create: [{ userId: user.id }, { userId: body.userId }] } }, include: threadInclude });
  emitToUser(body.userId, "dm:request:created", { thread, direction: "incoming" });
  emitToUser(user.id, "dm:request:created", { thread, direction: "outgoing" });
  return json({ thread, state: "pending_outgoing" }, 201);
}
