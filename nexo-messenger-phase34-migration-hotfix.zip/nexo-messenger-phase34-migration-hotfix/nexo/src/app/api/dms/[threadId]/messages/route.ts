import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { messageSchema } from "@/lib/validators";
import { error, handleError, json } from "@/lib/http";
import { emitToDmMembers } from "@/lib/live";
import { attachMessageFilesByIds, attachmentIdsFromPayload, normalizeMessageForClient } from "@/lib/message-uploads";
import { rateLimits } from "@/lib/rate-limit";
import { createMentionNotifications } from "@/lib/notifications";
import { areUsersBlocked, dmThreadOtherUserId } from "@/lib/social-safety";

async function canAccess(threadId: string, userId: string) {
  return prisma.directMessageThreadMember.findFirst({ where: { threadId, userId, thread: { status: "ACCEPTED" } } });
}

export async function GET(request: Request, { params }: { params: { threadId: string } }) {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);
  const member = await canAccess(params.threadId, user.id);
  if (!member) return error("Dieser Chat ist noch nicht freigegeben.", 403);
  await prisma.directMessageThreadMember.update({ where: { threadId_userId: { threadId: params.threadId, userId: user.id } }, data: { unread: 0 } });
  const search = new URL(request.url).searchParams;
  const limit = Math.min(Math.max(Number(search.get("limit") || 80), 1), 100);
  const before = search.get("before");
  const around = search.get("around");
  const include = { author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } }, fileAttachments: { orderBy: { createdAt: "asc" as const } }, replyTo: { select: { id: true, content: true, deletedAt: true, author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } } } } };

  if (around) {
    const target = await prisma.directMessage.findFirst({ where: { id: around, threadId: params.threadId, deletedAt: null }, select: { id: true, createdAt: true } });
    if (!target) return error("Nachricht nicht gefunden oder nicht sichtbar.", 404);
    const windowLimit = Math.min(Math.max(Number(search.get("limit") || 40), 10), 80);
    const [olderDesc, targetMessage, newer] = await Promise.all([
      prisma.directMessage.findMany({ where: { threadId: params.threadId, deletedAt: null, createdAt: { lt: target.createdAt } }, orderBy: { createdAt: "desc" }, take: Math.floor(windowLimit / 2), include }),
      prisma.directMessage.findUnique({ where: { id: target.id }, include }),
      prisma.directMessage.findMany({ where: { threadId: params.threadId, deletedAt: null, createdAt: { gt: target.createdAt } }, orderBy: { createdAt: "asc" }, take: Math.ceil(windowLimit / 2), include })
    ]);
    const messages = [...olderDesc.reverse(), ...(targetMessage ? [targetMessage] : []), ...newer];
    return json({ messages: messages.map(normalizeMessageForClient), hasMoreBefore: olderDesc.length >= Math.floor(windowLimit / 2), hasMoreAfter: newer.length >= Math.ceil(windowLimit / 2), around: target.id });
  }

  const beforeMessage = before ? await prisma.directMessage.findFirst({ where: { id: before, threadId: params.threadId }, select: { createdAt: true } }) : null;
  const messages = await prisma.directMessage.findMany({
    where: { threadId: params.threadId, deletedAt: null, ...(beforeMessage ? { createdAt: { lt: beforeMessage.createdAt } } : {}) },
    orderBy: { createdAt: "desc" },
    take: limit,
    include
  });
  return json({ messages: messages.reverse().map(normalizeMessageForClient), hasMore: messages.length === limit });
}

export async function POST(request: Request, { params }: { params: { threadId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    const member = await canAccess(params.threadId, user.id);
    if (!member) return error("Die andere Person muss den Chat erst annehmen.", 403);

    const otherUserId = await dmThreadOtherUserId(params.threadId, user.id);
    if (otherUserId && await areUsersBlocked(user.id, otherUserId)) return error("DM ist blockiert.", 403);

    const body = messageSchema.parse(await request.json());
    const attachmentIds = attachmentIdsFromPayload(body);
    if (body.clientMessageId) {
      const existing = await prisma.directMessage.findFirst({
        where: { threadId: params.threadId, authorId: user.id, clientMessageId: body.clientMessageId },
        include: { author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } }, fileAttachments: { orderBy: { createdAt: "asc" } }, replyTo: { select: { id: true, content: true, deletedAt: true, author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } } } } }
      });
      if (existing) return json({ message: normalizeMessageForClient(existing) }, 200);
    }

    const limited = await rateLimits.message(user.id, params.threadId);
    if (!limited.ok) return error("Du sendest gerade zu schnell.", 429);
    const message = await prisma.directMessage.create({
      data: { threadId: params.threadId, authorId: user.id, content: body.content.trim(), replyToId: body.replyToId || null, clientMessageId: body.clientMessageId || null, attachments: "[]" },
      include: { author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } }, fileAttachments: true }
    });
    await attachMessageFilesByIds({ uploaderId: user.id, attachmentIds, dmMessageId: message.id });
    await createMentionNotifications({ content: body.content, dmMessageId: message.id, excludeUserId: user.id }).catch(() => undefined);
    const fullMessage = await prisma.directMessage.findUnique({ where: { id: message.id }, include: { author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } }, fileAttachments: { orderBy: { createdAt: "asc" } }, replyTo: { select: { id: true, content: true, deletedAt: true, author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } } } } } });
    await prisma.directMessageThread.update({ where: { id: params.threadId }, data: { updatedAt: new Date() } });
    await prisma.directMessageThreadMember.updateMany({ where: { threadId: params.threadId, userId: { not: user.id } }, data: { unread: { increment: 1 } } });
    await emitToDmMembers(params.threadId, "dm:message", normalizeMessageForClient(fullMessage || message));
    return json({ message: normalizeMessageForClient(fullMessage || message) }, 201);
  } catch (err) { return handleError(err); }
}
