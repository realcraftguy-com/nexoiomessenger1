import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, json } from "@/lib/http";

export async function GET(_: Request, { params }: { params: { threadId: string } }) {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);
  const member = await prisma.directMessageThreadMember.findFirst({ where: { threadId: params.threadId, userId: user.id, thread: { status: "ACCEPTED" } } });
  if (!member) return error("Kein Zugriff", 403);
  const pins = await prisma.pinnedMessage.findMany({
    where: { dmThreadId: params.threadId },
    orderBy: { createdAt: "desc" },
    include: {
      dmMessage: { include: { author: { select: { id: true, username: true, displayName: true, avatarColor: true, avatarUrl: true } }, fileAttachments: { orderBy: { createdAt: "asc" } } } },
      pinnedBy: { select: { id: true, username: true, displayName: true } }
    }
  });
  return json({ pins, canPin: true });
}
