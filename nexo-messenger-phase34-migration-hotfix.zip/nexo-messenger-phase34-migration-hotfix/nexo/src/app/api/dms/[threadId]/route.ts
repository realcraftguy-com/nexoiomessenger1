import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { z } from "zod";
import { emitToDmMembers, emitToUser } from "@/lib/live";

async function requireMember(threadId: string, userId: string) {
  return prisma.directMessageThreadMember.findUnique({ where: { threadId_userId: { threadId, userId } }, include: { thread: { include: { members: true } } } });
}

export async function PATCH(request: Request, { params }: { params: { threadId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    const member = await requireMember(params.threadId, user.id);
    if (!member) return error("Chat nicht gefunden", 404);
    if (member.thread.status !== "ACCEPTED") return error("Dieser Chat ist noch nicht freigegeben.", 403);
    const body = z.object({ nickname: z.string().max(32, "Nickname darf maximal 32 Zeichen haben.").nullable().optional() }).parse(await request.json());
    const cleanNickname = body.nickname?.trim() || null;
    const updatedMember = await prisma.directMessageThreadMember.update({ where: { threadId_userId: { threadId: params.threadId, userId: user.id } }, data: { nickname: cleanNickname } });
    emitToUser(user.id, "dm:member:updated", { threadId: params.threadId, member: updatedMember, nickname: cleanNickname });
    return json({ member: updatedMember, nickname: cleanNickname });
  } catch (err) { return handleError(err); }
}

export async function DELETE(request: Request, { params }: { params: { threadId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    const member = await requireMember(params.threadId, user.id);
    if (!member) return error("Chat nicht gefunden", 404);
    const body = z.object({ action: z.enum(["clear_messages", "delete_thread"]) }).parse(await request.json().catch(() => ({})));
    const targetIds = member.thread.members.map((m: { userId: string }) => m.userId);
    if (body.action === "clear_messages") {
      await prisma.directMessage.deleteMany({ where: { threadId: params.threadId } });
      await prisma.directMessageThreadMember.updateMany({ where: { threadId: params.threadId }, data: { unread: 0 } });
      await prisma.directMessageThread.update({ where: { id: params.threadId }, data: { updatedAt: new Date() } });
      await emitToDmMembers(params.threadId, "dm:messages:cleared", { threadId: params.threadId, by: user.id });
      return json({ ok: true, action: "clear_messages" });
    }
    await prisma.directMessageThread.delete({ where: { id: params.threadId } });
    for (const id of targetIds) emitToUser(id, "dm:thread:deleted", { threadId: params.threadId, by: user.id });
    return json({ ok: true, action: "delete_thread" });
  } catch (err) { return handleError(err); }
}
