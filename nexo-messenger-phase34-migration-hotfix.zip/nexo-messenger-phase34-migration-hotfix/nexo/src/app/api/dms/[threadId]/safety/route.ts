import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, json } from "@/lib/http";
import { areUsersBlocked, dmThreadOtherUserId } from "@/lib/social-safety";

export async function GET(_: Request, { params }: { params: { threadId: string } }) {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);
  const member = await prisma.directMessageThreadMember.findFirst({ where: { threadId: params.threadId, userId: user.id, thread: { status: "ACCEPTED" } } });
  if (!member) return error("Kein Zugriff", 403);
  const otherUserId = await dmThreadOtherUserId(params.threadId, user.id);
  const blocked = otherUserId ? await areUsersBlocked(user.id, otherUserId) : false;
  return json({ blocked, reason: blocked ? "Einer von euch hat den anderen blockiert. Senden ist in diesem DM deaktiviert." : null });
}
