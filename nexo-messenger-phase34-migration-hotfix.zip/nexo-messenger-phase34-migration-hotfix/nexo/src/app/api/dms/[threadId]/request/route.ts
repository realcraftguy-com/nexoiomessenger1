import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { z } from "zod";
import { emitToUser } from "@/lib/live";

const userSelect = { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true, status: true } as const;
const includeThread = { members: { include: { user: { select: userSelect } } }, requestedBy: { select: userSelect }, messages: { orderBy: { createdAt: "desc" as const }, take: 1 } };

export async function PATCH(request: Request, { params }: { params: { threadId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    const body = z.object({ action: z.enum(["accept", "decline", "cancel"]) }).parse(await request.json());
    const thread = await prisma.directMessageThread.findUnique({ where: { id: params.threadId }, include: { members: true } });
    if (!thread || !thread.members.some((member: { userId: string }) => member.userId === user.id)) return error("Anfrage nicht gefunden", 404);
    if (thread.status !== "PENDING") return error("Diese Anfrage ist nicht mehr offen.", 400);
    const isRequester = thread.requestedById === user.id;
    const targetIds = thread.members.map((member: { userId: string }) => member.userId);

    if (body.action === "accept") {
      if (isRequester) return error("Die andere Person muss diese Anfrage annehmen.", 403);
      const updated = await prisma.directMessageThread.update({ where: { id: thread.id }, data: { status: "ACCEPTED", updatedAt: new Date() }, include: includeThread });
      for (const id of targetIds) emitToUser(id, "dm:request:accepted", { thread: updated });
      return json({ thread: updated });
    }
    if (body.action === "cancel" && !isRequester) return error("Nur der Absender kann diese Anfrage zurückziehen.", 403);
    if (body.action === "decline" && isRequester) return error("Du kannst deine eigene Anfrage nur zurückziehen.", 403);
    await prisma.directMessageThread.delete({ where: { id: thread.id } });
    for (const id of targetIds) emitToUser(id, "dm:request:removed", { threadId: thread.id, action: body.action });
    return json({ ok: true });
  } catch (err) { return handleError(err); }
}
