import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { emitToUser } from "@/lib/live";

export async function DELETE(_: Request, { params }: { params: { friendshipId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    const friendship = await prisma.friendship.findUnique({ where: { id: params.friendshipId } });
    if (!friendship || (friendship.userAId !== user.id && friendship.userBId !== user.id)) return error("Freundschaft nicht gefunden", 404);
    await prisma.friendship.delete({ where: { id: friendship.id } });
    emitToUser(friendship.userAId, "friend:removed", { friendshipId: friendship.id, userId: friendship.userBId });
    emitToUser(friendship.userBId, "friend:removed", { friendshipId: friendship.id, userId: friendship.userAId });
    return json({ ok: true });
  } catch (err) { return handleError(err); }
}
