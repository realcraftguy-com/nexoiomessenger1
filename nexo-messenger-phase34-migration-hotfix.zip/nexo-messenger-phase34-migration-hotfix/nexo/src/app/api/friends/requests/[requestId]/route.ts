import { z } from "zod";
import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { emitToUser } from "@/lib/live";

const actionSchema = z.object({ action: z.enum(["accept", "reject"]) });

function orderedPair(a: string, b: string) { return a < b ? { userAId: a, userBId: b } : { userAId: b, userBId: a }; }

export async function PATCH(request: Request, { params }: { params: { requestId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    const body = actionSchema.parse(await request.json());
    const friendRequest = await prisma.friendRequest.findUnique({ where: { id: params.requestId } });
    if (!friendRequest || friendRequest.receiverId !== user.id || friendRequest.status !== "pending") return error("Anfrage nicht gefunden", 404);
    const status = body.action === "accept" ? "accepted" : "rejected";
    const updated = await prisma.friendRequest.update({ where: { id: params.requestId }, data: { status } });
    if (body.action === "accept") {
      const pair = orderedPair(friendRequest.senderId, friendRequest.receiverId);
      const friendship = await prisma.friendship.upsert({ where: { userAId_userBId: pair }, create: pair, update: {} });
      emitToUser(friendRequest.senderId, "friend:added", { friendshipId: friendship.id, userId: friendRequest.receiverId });
      emitToUser(friendRequest.receiverId, "friend:added", { friendshipId: friendship.id, userId: friendRequest.senderId });
      return json({ request: updated, friendship });
    }
    emitToUser(friendRequest.senderId, "friend:request:updated", { requestId: updated.id, status: updated.status });
    emitToUser(friendRequest.receiverId, "friend:request:updated", { requestId: updated.id, status: updated.status });
    return json({ request: updated });
  } catch (err) { return handleError(err); }
}

export async function DELETE(_: Request, { params }: { params: { requestId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    const friendRequest = await prisma.friendRequest.findUnique({ where: { id: params.requestId } });
    if (!friendRequest || friendRequest.senderId !== user.id || friendRequest.status !== "pending") return error("Anfrage nicht gefunden", 404);
    const updated = await prisma.friendRequest.update({ where: { id: params.requestId }, data: { status: "cancelled" } });
    emitToUser(friendRequest.senderId, "friend:request:updated", { requestId: updated.id, status: updated.status });
    emitToUser(friendRequest.receiverId, "friend:request:updated", { requestId: updated.id, status: updated.status });
    return json({ ok: true });
  } catch (err) { return handleError(err); }
}
