import { z } from "zod";
import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { areUsersBlocked } from "@/lib/social-safety";
import { emitToUser } from "@/lib/live";

const createSchema = z.object({ userId: z.string().uuid() });
const userSelect = { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true, status: true } as const;

type FriendPublicUser = {
  id: string;
  username: string;
  displayName: string;
  avatarUrl: string | null;
  avatarColor: string;
  status: string;
};

type FriendRequestRow = {
  id: string;
  senderId: string;
  receiverId: string;
  status: string;
  createdAt: Date;
  updatedAt: Date;
};

type FriendshipRow = {
  id: string;
  userAId: string;
  userBId: string;
  createdAt: Date;
};

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);
  const [incoming, outgoing, friendships] = await Promise.all([
    prisma.friendRequest.findMany({ where: { receiverId: user.id, status: "pending" }, orderBy: { createdAt: "desc" } }) as Promise<FriendRequestRow[]>,
    prisma.friendRequest.findMany({ where: { senderId: user.id, status: "pending" }, orderBy: { createdAt: "desc" } }) as Promise<FriendRequestRow[]>,
    prisma.friendship.findMany({ where: { OR: [{ userAId: user.id }, { userBId: user.id }] }, orderBy: { createdAt: "desc" } }) as Promise<FriendshipRow[]>
  ]);
  const ids = Array.from(new Set([
    ...incoming.map((item) => item.senderId),
    ...outgoing.map((item) => item.receiverId),
    ...friendships.flatMap((item) => [item.userAId, item.userBId]).filter((id) => id !== user.id)
  ]));
  const users: FriendPublicUser[] = ids.length ? await prisma.user.findMany({ where: { id: { in: ids } }, select: userSelect }) : [];
  const userMap = new Map(users.map((item) => [item.id, item]));
  return json({
    incoming: incoming.map((item) => ({ ...item, user: userMap.get(item.senderId) || null })),
    outgoing: outgoing.map((item) => ({ ...item, user: userMap.get(item.receiverId) || null })),
    friendships: friendships.map((item) => ({ ...item, user: userMap.get(item.userAId === user.id ? item.userBId : item.userAId) || null }))
  });
}

export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    const body = createSchema.parse(await request.json());
    if (body.userId === user.id) return error("Du kannst dir nicht selbst eine Freundschaftsanfrage senden.", 400);
    const target = await prisma.user.findUnique({ where: { id: body.userId }, select: { id: true } });
    if (!target) return error("User nicht gefunden", 404);
    if (await areUsersBlocked(user.id, body.userId)) return error("Freundschaftsanfrage nicht möglich.", 403);
    const existingFriendship = await prisma.friendship.findFirst({ where: { OR: [{ userAId: user.id, userBId: body.userId }, { userAId: body.userId, userBId: user.id }] } });
    if (existingFriendship) return json({ friendship: existingFriendship, alreadyFriends: true });
    const incoming = await prisma.friendRequest.findUnique({ where: { senderId_receiverId: { senderId: body.userId, receiverId: user.id } } });
    if (incoming?.status === "pending") return json({ request: incoming, incomingPending: true });
    const requestRow = await prisma.friendRequest.upsert({
      where: { senderId_receiverId: { senderId: user.id, receiverId: body.userId } },
      create: { senderId: user.id, receiverId: body.userId },
      update: { status: "pending" }
    });
    emitToUser(body.userId, "friend:request:new", { requestId: requestRow.id, fromUserId: user.id });
    emitToUser(user.id, "friend:request:updated", { requestId: requestRow.id, status: requestRow.status });
    return json({ request: requestRow }, 201);
  } catch (err) { return handleError(err); }
}
