import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);
  const notifications = await prisma.notification.findMany({ where: { userId: user.id }, orderBy: { createdAt: "desc" }, take: 50 });
  const unread = await prisma.notification.count({ where: { userId: user.id, readAt: null } });
  const dmUnreadRows = await prisma.directMessageThreadMember.findMany({ where: { userId: user.id, unread: { gt: 0 } }, select: { unread: true } });
  const dmUnread = dmUnreadRows.reduce((sum: number, row: { unread: number }) => sum + row.unread, 0);
  const [mentionUnread, friendRequestUnread, reportUnread] = await Promise.all([
    prisma.notification.count({ where: { userId: user.id, readAt: null, type: "mention" } }),
    prisma.friendRequest.count({ where: { receiverId: user.id, status: "pending" } }).catch(() => 0),
    user.isAdmin ? prisma.report.count({ where: { status: "open" } }).catch(() => 0) : Promise.resolve(0)
  ]);
  return json({ notifications, unread, dmUnread, mentionUnread, friendRequestUnread, reportUnread, totalBadge: unread + dmUnread + friendRequestUnread + reportUnread });
}

export async function PATCH() {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    await prisma.notification.updateMany({ where: { userId: user.id, readAt: null }, data: { readAt: new Date() } });
    return json({ ok: true });
  } catch (err) { return handleError(err); }
}
