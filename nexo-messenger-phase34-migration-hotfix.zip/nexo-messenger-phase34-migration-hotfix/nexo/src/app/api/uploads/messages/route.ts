import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { filesFromFormData, saveMessageAttachments } from "@/lib/message-uploads";
import { rateLimits } from "@/lib/rate-limit";

export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);

    const limited = await rateLimits.upload(user.id);
    if (!limited.ok) return error("Upload-Limit erreicht. Versuche es später erneut.", 429);

    const formData = await request.formData();
    const files = filesFromFormData(formData);
    if (!files.length) return error("Keine Datei ausgewählt.", 400);

    const attachments = await saveMessageAttachments({ files, uploaderId: user.id });
    return json({ attachments }, 201);
  } catch (err) {
    return handleError(err);
  }
}
