import { mkdir, unlink, writeFile } from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";
import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { safeFileName, storagePath } from "@/lib/upload-security";

const MAX_AVATAR_BYTES = 2 * 1024 * 1024;
const allowed = new Map<string, string>([["image/png", ".png"], ["image/jpeg", ".jpg"], ["image/webp", ".webp"]]);


async function removeStoredAvatar(avatarUrl?: string | null) {
  const prefix = "/api/files/avatars/";
  if (!avatarUrl?.startsWith(prefix)) return;
  const parts = avatarUrl.slice(prefix.length).split("/");
  if (parts.length !== 2) return;
  const [userId, fileName] = parts;
  if (!/^[a-f0-9-]{36}\.(png|jpg|webp)$/i.test(fileName)) return;
  await unlink(storagePath(path.posix.join("avatars", userId, fileName))).catch(() => undefined);
}

function detectAvatarMime(buffer: Buffer) {
  if (buffer.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return "image/png";
  if (buffer.subarray(0, 3).equals(Buffer.from([0xff, 0xd8, 0xff]))) return "image/jpeg";
  if (buffer.length >= 12 && buffer.subarray(0, 4).toString("ascii") === "RIFF" && buffer.subarray(8, 12).toString("ascii") === "WEBP") return "image/webp";
  return null;
}

export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    const existing = await prisma.user.findUnique({ where: { id: user.id }, select: { avatarUrl: true } });
    const form = await request.formData();
    const file = form.get("avatar");
    if (!(file instanceof File) || file.size <= 0) return error("Kein Avatar ausgewählt.", 400);
    if (file.size > MAX_AVATAR_BYTES) return error("Avatar ist zu groß. Maximal 2 MB.", 413);
    if (!allowed.has(file.type)) return error("Nur PNG, JPG/JPEG oder WebP sind erlaubt.", 415);
    const originalName = safeFileName(file.name || "avatar");
    const declaredExt = path.extname(originalName).toLowerCase();
    if ([".svg", ".html", ".htm", ".xml"].includes(declaredExt)) return error("Dieser Dateityp ist für Avatare nicht erlaubt.", 415);
    const buffer = Buffer.from(await file.arrayBuffer());
    const mimeType = detectAvatarMime(buffer);
    if (!mimeType || mimeType !== file.type) return error("Avatar-Typ konnte nicht sicher bestätigt werden.", 415);
    const ext = allowed.get(mimeType) || ".png";
    const storageName = `${randomUUID()}${ext}`;
    const relative = path.posix.join("avatars", user.id, storageName);
    const absolute = storagePath(relative);
    await mkdir(path.dirname(absolute), { recursive: true });
    await writeFile(absolute, buffer);
    const avatarUrl = `/api/files/avatars/${user.id}/${storageName}`;
    const updated = await prisma.user.update({ where: { id: user.id }, data: { avatarUrl }, select: { id: true, avatarUrl: true, avatarColor: true } });
    await removeStoredAvatar(existing?.avatarUrl);
    return json({ avatarUrl: updated.avatarUrl }, 201);
  } catch (err) { return handleError(err); }
}

export async function DELETE() {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    const existing = await prisma.user.findUnique({ where: { id: user.id }, select: { avatarUrl: true } });
    await prisma.user.update({ where: { id: user.id }, data: { avatarUrl: null } });
    await removeStoredAvatar(existing?.avatarUrl);
    return json({ ok: true, avatarUrl: null });
  } catch (err) { return handleError(err); }
}
