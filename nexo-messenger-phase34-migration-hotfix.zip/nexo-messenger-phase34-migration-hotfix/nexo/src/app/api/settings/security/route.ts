import bcrypt from "bcryptjs";
import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { twoFactorSchema } from "@/lib/validators";

export async function PATCH(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);

    const body = twoFactorSchema.parse(await request.json());
    if (body.enabled) {
      const code = String(body.code || "").trim();
      if (!/^\d{6}$/.test(code)) return error("Bitte gib einen 6-stelligen Code ein.", 400);
      const twoFactorCodeHash = await bcrypt.hash(code, 12);
      const updated = await prisma.user.update({
        where: { id: user.id },
        data: { twoFactorEnabled: true, twoFactorCodeHash },
        select: { id: true, twoFactorEnabled: true }
      });
      await prisma.auditLog.create({ data: { action: "TWO_FACTOR_UPDATED", actorId: user.id, targetId: user.id, meta: JSON.stringify({ enabled: true }) } }).catch(() => undefined);
      return json({ user: updated });
    }

    const updated = await prisma.user.update({
      where: { id: user.id },
      data: { twoFactorEnabled: false, twoFactorCodeHash: null },
      select: { id: true, twoFactorEnabled: true }
    });
    await prisma.auditLog.create({ data: { action: "TWO_FACTOR_UPDATED", actorId: user.id, targetId: user.id, meta: JSON.stringify({ enabled: false }) } }).catch(() => undefined);
    return json({ user: updated });
  } catch (err) {
    return handleError(err);
  }
}
