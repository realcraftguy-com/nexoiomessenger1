import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { profileSchema } from "@/lib/validators";

export async function PATCH(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);

    const body = profileSchema.parse(await request.json());
    const username = body.username.toLowerCase();
    const nextAvatarUrl = body.avatarUrl || null;
    if (nextAvatarUrl && !nextAvatarUrl.startsWith("/api/files/avatars/") && nextAvatarUrl !== user.avatarUrl) {
      return error("Neue Avatare müssen über den sicheren Upload hochgeladen werden.", 400);
    }
    const taken = await prisma.user.findFirst({ where: { username, NOT: { id: user.id } } });
    if (taken) return error("Username ist bereits vergeben", 409);

    const updated = await prisma.user.update({
      where: { id: user.id },
      data: {
        displayName: body.displayName,
        username,
        avatarUrl: nextAvatarUrl,
        avatarColor: body.avatarColor,
        accentColor: body.accentColor || body.avatarColor,
        bio: body.bio || "",
        pronouns: body.pronouns || "",
        location: body.location || "",
        customStatus: body.customStatus || "",
        compactMode: Boolean(body.compactMode),
        reduceMotion: Boolean(body.reduceMotion),
        showOnline: Boolean(body.showOnline),
        allowDmRequests: Boolean(body.allowDmRequests),
        status: body.status,
        ...(typeof body.onboarded === "boolean" ? { onboarded: body.onboarded } : {})
      },
      select: { id: true, email: true, username: true, displayName: true, avatarUrl: true, avatarColor: true, accentColor: true, bio: true, pronouns: true, location: true, customStatus: true, compactMode: true, reduceMotion: true, showOnline: true, allowDmRequests: true, twoFactorEnabled: true, status: true, onboarded: true }
    });

    return json({ user: updated });
  } catch (err) {
    return handleError(err);
  }
}
