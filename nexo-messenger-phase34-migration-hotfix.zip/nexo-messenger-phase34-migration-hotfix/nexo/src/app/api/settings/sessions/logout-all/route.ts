import prisma from "@/lib/prisma";
import { clearSessionCookie, getCurrentUser } from "@/lib/auth";
import { error, json } from "@/lib/http";
import { emitToUser } from "@/lib/live";

export async function POST() {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);
  await prisma.user.update({ where: { id: user.id }, data: { sessionVersion: { increment: 1 }, status: "OFFLINE", lastSeenAt: new Date() } });
  emitToUser(user.id, "session:revoked", { reason: "Du wurdest auf allen Geräten abgemeldet." });
  clearSessionCookie();
  return json({ ok: true });
}
