import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { channelSchema } from "@/lib/validators";
import { emitAdminRefresh, emitToServerMembers, emitChannelRoomRecheck } from "@/lib/live";
import { requireServerPermission } from "@/lib/permissions";

async function canManage(serverId: string, user: { id: string; isAdmin: boolean }) {
  return Boolean(await requireServerPermission(serverId, user, "MANAGE_CHANNELS"));
}

export async function PATCH(request: Request, { params }: { params: { serverId: string; channelId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    if (!(await canManage(params.serverId, user))) return error("Keine Berechtigung", 403);
    const body = channelSchema.parse(await request.json());
    const existing = await prisma.channel.findFirst({ where: { id: params.channelId, serverId: params.serverId } });
    if (!existing) return error("Channel nicht gefunden", 404);
    if (body.categoryId) {
      const category = await prisma.channelCategory.findFirst({ where: { id: body.categoryId, serverId: params.serverId } });
      if (!category) return error("Kategorie nicht gefunden", 404);
    }
    const channel = await prisma.channel.update({ where: { id: params.channelId }, data: { name: body.name, type: body.type, topic: body.topic || "", categoryId: body.categoryId || null, isPrivate: body.isPrivate, slowmodeSeconds: body.slowmodeSeconds } });
    await prisma.auditLog.create({ data: { action: "CHANNEL_UPDATED", actorId: user.id, serverId: params.serverId, targetId: channel.id, meta: JSON.stringify({ name: channel.name, type: channel.type }) } }).catch(() => undefined);
    await emitChannelRoomRecheck(channel.id);
    await emitToServerMembers(params.serverId, "server:channel:changed", { serverId: params.serverId, action: "updated", channel });
    emitAdminRefresh("channel_updated", { serverId: params.serverId, channelId: channel.id });
    return json({ channel });
  } catch (err) { return handleError(err); }
}

export async function DELETE(_: Request, { params }: { params: { serverId: string; channelId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    if (!(await canManage(params.serverId, user))) return error("Keine Berechtigung", 403);
    const channel = await prisma.channel.findFirst({ where: { id: params.channelId, serverId: params.serverId } });
    if (!channel) return error("Channel nicht gefunden", 404);
    await prisma.channel.delete({ where: { id: params.channelId } });
    await prisma.auditLog.create({ data: { action: "CHANNEL_UPDATED", actorId: user.id, serverId: params.serverId, targetId: params.channelId, meta: JSON.stringify({ deleted: true, name: channel.name }) } }).catch(() => undefined);
    await emitToServerMembers(params.serverId, "server:channel:changed", channel.isPrivate ? { serverId: params.serverId, action: "deleted", target: "channel" } : { serverId: params.serverId, action: "deleted", channelId: params.channelId });
    emitAdminRefresh("channel_deleted", { serverId: params.serverId, channelId: params.channelId });
    return json({ ok: true });
  } catch (err) { return handleError(err); }
}
