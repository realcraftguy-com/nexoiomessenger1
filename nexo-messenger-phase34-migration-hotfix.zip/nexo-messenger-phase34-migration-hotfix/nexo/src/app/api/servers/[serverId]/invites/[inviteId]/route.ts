import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { emitAdminRefresh, emitToServerMembers } from "@/lib/live";
import { requireServerPermission } from "@/lib/permissions";

async function canManage(serverId: string, user: { id: string; isAdmin: boolean }) {
  return Boolean(await requireServerPermission(serverId, user, "MANAGE_SERVER")) || Boolean(await requireServerPermission(serverId, user, "CREATE_INVITES"));
}

export async function DELETE(_: Request, { params }: { params: { serverId: string; inviteId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    if (!(await canManage(params.serverId, user))) return error("Keine Berechtigung", 403);
    const invite = await prisma.invite.findUnique({ where: { id: params.inviteId } });
    if (!invite || invite.serverId !== params.serverId) return error("Invite nicht gefunden", 404);
    await prisma.invite.update({ where: { id: params.inviteId }, data: { disabledAt: new Date() } });
    await prisma.auditLog.create({ data: { action: "SERVER_UPDATED", actorId: user.id, serverId: params.serverId, targetId: params.inviteId, meta: JSON.stringify({ inviteDisabled: invite.code }) } }).catch(() => undefined);
    await emitToServerMembers(params.serverId, "server:invite:changed", { serverId: params.serverId, action: "disabled", inviteId: params.inviteId });
    emitAdminRefresh("invite_disabled", { serverId: params.serverId, inviteId: params.inviteId });
    return json({ ok: true });
  } catch (err) { return handleError(err); }
}
