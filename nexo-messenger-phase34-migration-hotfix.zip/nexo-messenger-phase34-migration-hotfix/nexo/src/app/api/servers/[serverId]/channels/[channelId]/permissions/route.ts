import { z } from "zod";
import prisma from "@/lib/prisma";
import type { Prisma } from "@prisma/client";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { emitChannelRoomRecheck, emitToServerMembers } from "@/lib/live";
import { requireServerPermission, sanitizePermissions } from "@/lib/permissions";

const overrideInput = z.object({
  roleId: z.string().uuid().optional().nullable(),
  memberId: z.string().uuid().optional().nullable(),
  allow: z.array(z.string()).max(20).optional().default([]),
  deny: z.array(z.string()).max(20).optional().default([])
}).refine((value) => Boolean(value.roleId) !== Boolean(value.memberId), "Override braucht genau eine Rolle oder ein Mitglied.");

const schema = z.object({
  isPrivate: z.boolean(),
  overrides: z.array(overrideInput).max(100).default([])
});

export async function PATCH(request: Request, { params }: { params: { serverId: string; channelId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    if (!(await requireServerPermission(params.serverId, user, "MANAGE_CHANNELS"))) return error("Keine Berechtigung", 403);
    const channel = await prisma.channel.findFirst({ where: { id: params.channelId, serverId: params.serverId } });
    if (!channel) return error("Channel nicht gefunden", 404);
    const body = schema.parse(await request.json());

    const roleIds = body.overrides.map((item) => item.roleId).filter(Boolean) as string[];
    const memberIds = body.overrides.map((item) => item.memberId).filter(Boolean) as string[];
    const [roles, members] = await Promise.all([
      roleIds.length ? prisma.role.findMany({ where: { id: { in: roleIds }, serverId: params.serverId }, select: { id: true } }) : Promise.resolve([]),
      memberIds.length ? prisma.serverMember.findMany({ where: { id: { in: memberIds }, serverId: params.serverId }, select: { id: true, isOwner: true } }) : Promise.resolve([])
    ]);
    if (roles.length !== new Set(roleIds).size || members.length !== new Set(memberIds).size) return error("Override enthält fremde Rollen oder Mitglieder.", 400);

    await prisma.$transaction(async (tx: Prisma.TransactionClient) => {
      await tx.channel.update({ where: { id: channel.id }, data: { isPrivate: body.isPrivate } });
      await tx.channelPermissionOverride.deleteMany({ where: { channelId: channel.id } });
      for (const item of body.overrides) {
        const allow = sanitizePermissions(item.allow).filter((permission) => permission !== "*");
        const deny = sanitizePermissions(item.deny).filter((permission) => permission !== "*");
        if (!allow.length && !deny.length) continue;
        await tx.channelPermissionOverride.create({ data: { channelId: channel.id, roleId: item.roleId || null, memberId: item.memberId || null, allow, deny } });
      }
    });

    const fresh = await prisma.channel.findUnique({ where: { id: channel.id }, include: { permissionOverrides: true } });
    await prisma.auditLog.create({ data: { action: "PRIVATE_CHANNEL_UPDATED", actorId: user.id, serverId: params.serverId, targetId: channel.id, meta: JSON.stringify({ isPrivate: body.isPrivate }) } }).catch(() => undefined);
    await emitChannelRoomRecheck(channel.id);
    await emitToServerMembers(params.serverId, "server:channel:changed", { serverId: params.serverId, action: "permissions", channel: fresh });
    return json({ channel: fresh });
  } catch (err) {
    return handleError(err);
  }
}
