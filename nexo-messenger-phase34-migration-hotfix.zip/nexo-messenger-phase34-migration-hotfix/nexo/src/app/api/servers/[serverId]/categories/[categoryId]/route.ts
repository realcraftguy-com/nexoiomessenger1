import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { categorySchema } from "@/lib/validators";
import { emitAdminRefresh, emitToServerMembers } from "@/lib/live";
import { requireServerPermission } from "@/lib/permissions";

async function canManage(serverId: string, user: { id: string; isAdmin: boolean }) {
  return Boolean(await requireServerPermission(serverId, user, "MANAGE_CHANNELS"));
}

export async function PATCH(request: Request, { params }: { params: { serverId: string; categoryId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    if (!(await canManage(params.serverId, user))) return error("Keine Berechtigung", 403);
    const body = categorySchema.parse(await request.json());
    const existing = await prisma.channelCategory.findFirst({ where: { id: params.categoryId, serverId: params.serverId } });
    if (!existing) return error("Kategorie nicht gefunden", 404);
    const category = await prisma.channelCategory.update({ where: { id: params.categoryId }, data: { name: body.name, collapsed: body.collapsed } });
    await prisma.auditLog.create({ data: { action: "CHANNEL_CATEGORY_UPDATED", actorId: user.id, serverId: params.serverId, targetId: category.id, meta: JSON.stringify({ name: category.name }) } }).catch(() => undefined);
    await emitToServerMembers(params.serverId, "server:category:changed", { serverId: params.serverId, action: "updated", category });
    emitAdminRefresh("category_updated", { serverId: params.serverId, categoryId: category.id });
    return json({ category });
  } catch (err) { return handleError(err); }
}

export async function DELETE(_: Request, { params }: { params: { serverId: string; categoryId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    if (!(await canManage(params.serverId, user))) return error("Keine Berechtigung", 403);
    const existing = await prisma.channelCategory.findFirst({ where: { id: params.categoryId, serverId: params.serverId } });
    if (!existing) return error("Kategorie nicht gefunden", 404);
    await prisma.channel.updateMany({ where: { serverId: params.serverId, categoryId: params.categoryId }, data: { categoryId: null } });
    await prisma.channelCategory.delete({ where: { id: params.categoryId } });
    await prisma.auditLog.create({ data: { action: "CHANNEL_CATEGORY_DELETED", actorId: user.id, serverId: params.serverId, targetId: params.categoryId } }).catch(() => undefined);
    await emitToServerMembers(params.serverId, "server:category:changed", { serverId: params.serverId, action: "deleted", categoryId: params.categoryId });
    emitAdminRefresh("category_deleted", { serverId: params.serverId, categoryId: params.categoryId });
    return json({ ok: true });
  } catch (err) { return handleError(err); }
}
