import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { categorySchema } from "@/lib/validators";
import { emitAdminRefresh, emitToServerMembers } from "@/lib/live";
import { requireServerPermission } from "@/lib/permissions";

async function canManage(serverId: string, user: { id: string; isAdmin: boolean }) {
  return Boolean(await requireServerPermission(serverId, user, "MANAGE_CHANNELS"));
}

export async function POST(request: Request, { params }: { params: { serverId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    if (!(await canManage(params.serverId, user))) return error("Keine Berechtigung", 403);
    const body = categorySchema.parse(await request.json());
    const count = await prisma.channelCategory.count({ where: { serverId: params.serverId } });
    const category = await prisma.channelCategory.create({ data: { serverId: params.serverId, name: body.name, collapsed: body.collapsed, position: count } });
    await prisma.auditLog.create({ data: { action: "CHANNEL_CATEGORY_CREATED", actorId: user.id, serverId: params.serverId, targetId: category.id, meta: JSON.stringify({ name: category.name }) } }).catch(() => undefined);
    await emitToServerMembers(params.serverId, "server:category:changed", { serverId: params.serverId, action: "created", category });
    emitAdminRefresh("category_created", { serverId: params.serverId, categoryId: category.id });
    return json({ category }, 201);
  } catch (err) { return handleError(err); }
}
