import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { roleSchema } from "@/lib/validators";
import { emitAdminRefresh, emitToServerMembers, emitServerPrivateChannelsRecheck } from "@/lib/live";
import { canManageRole } from "@/lib/permissions";

export async function PATCH(request: Request, { params }: { params: { serverId: string; roleId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    const state = await canManageRole(params.serverId, user, params.roleId);
    if (!state) return error("Keine Berechtigung", 403);
    const body = roleSchema.parse(await request.json());
    const existing = await prisma.role.findFirst({ where: { id: params.roleId, serverId: params.serverId } });
    if (!existing) return error("Rolle nicht gefunden", 404);
    if (existing.name.toLowerCase() === "owner") return error("Owner-Rolle kann nicht geändert werden", 400);
    const role = await prisma.role.update({ where: { id: params.roleId }, data: { name: body.name, color: body.color, permissions: JSON.stringify(body.permissions) } });
    await prisma.auditLog.create({ data: { action: "ROLE_UPDATED", actorId: user.id, serverId: params.serverId, targetId: role.id, meta: JSON.stringify({ name: role.name }) } }).catch(() => undefined);
    await emitServerPrivateChannelsRecheck(params.serverId);
    await emitToServerMembers(params.serverId, "server:role:changed", { serverId: params.serverId, action: "updated", role });
    emitAdminRefresh("role_updated", { serverId: params.serverId, roleId: role.id });
    return json({ role });
  } catch (err) { return handleError(err); }
}

export async function DELETE(_: Request, { params }: { params: { serverId: string; roleId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    const state = await canManageRole(params.serverId, user, params.roleId);
    if (!state) return error("Keine Berechtigung", 403);
    const existing = await prisma.role.findFirst({ where: { id: params.roleId, serverId: params.serverId } });
    if (!existing) return error("Rolle nicht gefunden", 404);
    if (existing.name.toLowerCase() === "owner") return error("Owner-Rolle kann nicht gelöscht werden", 400);
    await prisma.role.delete({ where: { id: params.roleId } });
    await prisma.auditLog.create({ data: { action: "ROLE_DELETED", actorId: user.id, serverId: params.serverId, targetId: params.roleId } }).catch(() => undefined);
    await emitServerPrivateChannelsRecheck(params.serverId);
    await emitToServerMembers(params.serverId, "server:role:changed", { serverId: params.serverId, action: "deleted", roleId: params.roleId });
    emitAdminRefresh("role_deleted", { serverId: params.serverId, roleId: params.roleId });
    return json({ ok: true });
  } catch (err) { return handleError(err); }
}
