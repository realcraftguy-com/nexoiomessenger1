import { z } from "zod";
import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { emitAdminRefresh, emitToServerMembers, emitToUser, emitServerPrivateChannelsRecheck } from "@/lib/live";
import { canAssignRoles, canManageMember, requireServerPermission } from "@/lib/permissions";

const memberSchema = z.object({
  nickname: z.string().max(40).optional().nullable(),
  isAdmin: z.boolean().optional(),
  roleIds: z.array(z.string()).max(50).optional()
});

export async function PATCH(request: Request, { params }: { params: { serverId: string; memberId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    const body = memberSchema.parse(await request.json());
    const before = await prisma.serverMember.findFirst({ where: { id: params.memberId, serverId: params.serverId }, include: { roleAssignments: true } });
    if (!before) return error("Mitglied nicht gefunden", 404);
    if (before.isOwner) return error("Owner kann hier nicht geändert werden", 400);

    if (typeof body.isAdmin === "boolean") {
      if (before.userId === user.id) return error("Du kannst deine eigenen Admin-Rechte nicht ändern", 400);
      if (!(await requireServerPermission(params.serverId, user, "MANAGE_SERVER"))) return error("Nur Owner/Server-Verwaltung darf Adminrechte ändern", 403);
    }

    if (body.roleIds) {
      if (before.userId === user.id) return error("Du kannst dir nicht selbst Rollen geben oder entfernen", 400);
      const manageableTarget = await canManageMember(params.serverId, user, params.memberId, "MANAGE_ROLES");
      if (!manageableTarget) return error("Dieses Mitglied hat eine zu hohe Rolle", 403);
      const assignable = await canAssignRoles(params.serverId, user, body.roleIds);
      if (!assignable) return error("Eine Rolle ist zu hoch oder nicht erlaubt", 403);
    } else if (typeof body.nickname !== "undefined" || typeof body.isAdmin !== "undefined") {
      const needed = typeof body.isAdmin === "boolean" ? "MANAGE_SERVER" : "KICK_MEMBERS";
      const manageableTarget = await canManageMember(params.serverId, user, params.memberId, needed);
      if (!manageableTarget) return error("Keine Berechtigung", 403);
    }

    const member = await prisma.serverMember.update({
      where: { id: before.id },
      data: { nickname: body.nickname ?? before.nickname, ...(typeof body.isAdmin === "boolean" ? { isAdmin: body.isAdmin } : {}) },
      include: { roleAssignments: { include: { role: true } }, user: { select: { id: true, username: true, displayName: true, avatarColor: true, avatarUrl: true, status: true } } }
    });

    if (body.roleIds) {
      const assignable = await canAssignRoles(params.serverId, user, body.roleIds);
      if (!assignable) return error("Eine Rolle ist zu hoch oder nicht erlaubt", 403);
      const validIds = new Set(assignable.roles.map((role: { id: string }) => role.id));
      await prisma.roleAssignment.deleteMany({ where: { memberId: member.id, roleId: { notIn: [...validIds] } } });
      for (const roleId of validIds) {
        await prisma.roleAssignment.upsert({
          where: { roleId_memberId: { roleId, memberId: member.id } },
          create: { roleId, memberId: member.id, userId: member.userId, serverId: params.serverId },
          update: {}
        });
      }
    }

    const freshMember = await prisma.serverMember.findUnique({ where: { id: member.id }, include: { roleAssignments: { include: { role: true } }, user: { select: { id: true, username: true, displayName: true, avatarColor: true, avatarUrl: true, status: true } } } });
    await prisma.auditLog.create({ data: { action: "MEMBER_UPDATED", actorId: user.id, serverId: params.serverId, targetId: member.userId, meta: JSON.stringify({ memberUpdated: member.user.username, roleIds: body.roleIds, adminChanged: typeof body.isAdmin === "boolean" }) } }).catch(() => undefined);
    await emitServerPrivateChannelsRecheck(params.serverId);
    await emitToServerMembers(params.serverId, "server:member:changed", { serverId: params.serverId, action: "updated", member: freshMember || member });
    emitAdminRefresh("member_updated", { serverId: params.serverId, userId: member.userId });
    return json({ member: freshMember || member });
  } catch (err) { return handleError(err); }
}

export async function DELETE(_: Request, { params }: { params: { serverId: string; memberId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    const manageable = await canManageMember(params.serverId, user, params.memberId, "KICK_MEMBERS");
    if (!manageable) return error("Keine Berechtigung", 403);
    const member = await prisma.serverMember.findFirst({ where: { id: params.memberId, serverId: params.serverId }, include: { user: true } });
    if (!member) return error("Mitglied nicht gefunden", 404);
    if (member.isOwner) return error("Owner kann nicht entfernt werden", 400);
    await prisma.serverMember.delete({ where: { id: member.id } });
    await prisma.auditLog.create({ data: { action: "SERVER_UPDATED", actorId: user.id, serverId: params.serverId, targetId: member.userId, meta: JSON.stringify({ memberRemoved: member.user.username }) } }).catch(() => undefined);
    await emitServerPrivateChannelsRecheck(params.serverId);
    await emitToServerMembers(params.serverId, "server:member:changed", { serverId: params.serverId, action: "removed", memberId: member.id, userId: member.userId });
    emitToUser(member.userId, "server:deleted", { serverId: params.serverId });
    emitAdminRefresh("member_removed", { serverId: params.serverId, userId: member.userId });
    return json({ ok: true });
  } catch (err) { return handleError(err); }
}
