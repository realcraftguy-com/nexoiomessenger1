import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { serverSettingsSchema } from "@/lib/validators";
import { emitAdminRefresh, emitToAdmins, emitToServerMembers } from "@/lib/live";
import { requireServerPermission } from "@/lib/permissions";

async function requireManager(serverId: string, userId: string, isAdmin: boolean) {
  const state = await requireServerPermission(serverId, { id: userId, isAdmin }, "MANAGE_SERVER");
  return state?.member || null;
}

const includeServer = {
  categories: { orderBy: { position: "asc" as const }, include: { channels: { orderBy: { position: "asc" as const }, include: { permissionOverrides: true } } } },
  channels: { orderBy: { position: "asc" as const }, include: { permissionOverrides: true } },
  roles: { orderBy: { position: "asc" as const } },
  members: { include: { roleAssignments: { include: { role: true } }, user: { select: { id: true, username: true, displayName: true, avatarColor: true, avatarUrl: true, status: true } } }, orderBy: { joinedAt: "asc" as const } },
  invites: { orderBy: { createdAt: "desc" as const }, take: 50, include: { createdBy: { select: { id: true, username: true, displayName: true } }, channel: { select: { id: true, name: true, type: true } } } },
  auditLogs: { orderBy: { createdAt: "desc" as const }, take: 80, include: { actor: { select: { username: true, displayName: true } } } }
};

export async function GET(_: Request, { params }: { params: { serverId: string } }) {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);
  const member = await requireManager(params.serverId, user.id, user.isAdmin);
  if (!member) return error("Keine Berechtigung", 403);
  const server = await prisma.server.findUnique({ where: { id: params.serverId }, include: includeServer });
  if (!server) return error("Server nicht gefunden", 404);
  return json({ server, membership: member });
}

export async function PATCH(request: Request, { params }: { params: { serverId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    const member = await requireManager(params.serverId, user.id, user.isAdmin);
    if (!member) return error("Keine Berechtigung", 403);
    const body = serverSettingsSchema.parse(await request.json());
    const server = await prisma.server.update({ where: { id: params.serverId }, data: { name: body.name, iconUrl: body.iconUrl || null, isPrivate: body.isPrivate }, include: includeServer });
    await prisma.auditLog.create({ data: { action: "SERVER_UPDATED", actorId: user.id, serverId: server.id, meta: JSON.stringify({ name: body.name }) } }).catch(() => undefined);
    await emitToServerMembers(server.id, "server:updated", { serverId: server.id, action: "updated" });
    emitToAdmins("admin:server:updated", { server });
    emitAdminRefresh("server_updated", { serverId: server.id });
    return json({ server });
  } catch (err) {
    return handleError(err);
  }
}
