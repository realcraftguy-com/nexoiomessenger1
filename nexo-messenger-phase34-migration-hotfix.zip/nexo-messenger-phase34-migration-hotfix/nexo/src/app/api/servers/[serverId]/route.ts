import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, json } from "@/lib/http";
import { emitAdminRefresh, emitToAdmins, emitToServerMembers, emitToUser } from "@/lib/live";
import { canAccessChannel } from "@/lib/permissions";

export async function GET(_: Request, { params }: { params: { serverId: string } }) {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);

  const member = await prisma.serverMember.findUnique({ where: { serverId_userId: { serverId: params.serverId, userId: user.id } } });
  if (!member) return error("Kein Zugriff", 403);

  const server = await prisma.server.findUnique({
    where: { id: params.serverId },
    include: {
      channels: { orderBy: [{ categoryId: "asc" }, { position: "asc" }] },
      categories: { orderBy: { position: "asc" } },
      roles: { orderBy: { position: "asc" } },
      members: { include: { user: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true, status: true } } }, orderBy: { joinedAt: "asc" } }
    }
  });

  if (!server) return error("Server nicht gefunden", 404);
  const visibleChannels = [];
  for (const channel of server.channels) {
    if (await canAccessChannel(channel.id, user.id, user.isAdmin, "VIEW_CHANNEL")) visibleChannels.push(channel);
  }
  return json({ server: { ...server, channels: visibleChannels }, membership: member });
}

export async function DELETE(_: Request, { params }: { params: { serverId: string } }) {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);

  const server = await prisma.server.findUnique({ where: { id: params.serverId }, include: { members: { select: { userId: true } } } });
  if (!server) return error("Server nicht gefunden", 404);
  if (server.ownerId !== user.id && !user.isAdmin) return error("Nur Owner darf löschen", 403);

  const targets = server.members.map((member: { userId: string }) => member.userId);
  await prisma.server.delete({ where: { id: server.id } });
  await prisma.auditLog.create({ data: { action: "SERVER_DELETED", actorId: user.id, targetId: server.id, meta: JSON.stringify({ name: server.name }) } }).catch(() => undefined);

  for (const id of targets) emitToUser(id, "server:deleted", { serverId: server.id, name: server.name });
  emitToAdmins("admin:server:deleted", { serverId: server.id, name: server.name });
  emitAdminRefresh("server_deleted", { serverId: server.id });
  return json({ ok: true });
}
