import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { channelSchema } from "@/lib/validators";
import { error, handleError, json } from "@/lib/http";
import { emitAdminRefresh, emitToServerMembers } from "@/lib/live";
import { requireServerPermission } from "@/lib/permissions";

export async function POST(request: Request, { params }: { params: { serverId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);

    if (!(await requireServerPermission(params.serverId, user, "MANAGE_CHANNELS"))) return error("Keine Berechtigung", 403);

    const body = channelSchema.parse(await request.json());
    if (body.categoryId) {
      const category = await prisma.channelCategory.findFirst({ where: { id: body.categoryId, serverId: params.serverId } });
      if (!category) return error("Kategorie nicht gefunden", 404);
    }
    const count = await prisma.channel.count({ where: { serverId: params.serverId } });
    const channel = await prisma.channel.create({ data: { serverId: params.serverId, name: body.name, type: body.type, categoryId: body.categoryId || null, topic: body.topic || "", isPrivate: body.isPrivate, slowmodeSeconds: body.slowmodeSeconds, position: count } });

    await prisma.auditLog.create({ data: { action: "CHANNEL_CREATED", actorId: user.id, serverId: params.serverId, targetId: channel.id, meta: JSON.stringify({ name: channel.name, type: channel.type }) } });
    await emitToServerMembers(params.serverId, "server:channel:created", { serverId: params.serverId, channel });
    emitAdminRefresh("channel_created", { serverId: params.serverId, channelId: channel.id });
    return json({ channel }, 201);
  } catch (err) {
    return handleError(err);
  }
}
