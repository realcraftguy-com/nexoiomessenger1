import crypto from "node:crypto";
import { z } from "zod";
import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { emitAdminRefresh, emitToServerMembers } from "@/lib/live";
import { requireServerPermission } from "@/lib/permissions";

const createInviteSchema = z.object({
  expiresInHours: z
    .number()
    .int()
    .min(1)
    .max(24 * 30)
    .nullable()
    .optional(),
  maxUses: z.number().int().min(1).max(1000).nullable().optional(),
  channelId: z.string().uuid().nullable().optional(),
});

function code() {
  return crypto.randomBytes(6).toString("base64url");
}

type InviteListItem = {
  id: string;
  code: string;
  channelId: string | null;
  channel?: { id: string; name: string; type: string } | null;
  [key: string]: unknown;
};

function inviteUrl(inviteCode: string) {
  return `${process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000"}/invite/${inviteCode}`;
}

export async function GET(
  _: Request,
  { params }: { params: { serverId: string } },
) {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);
  const state = await requireServerPermission(
    params.serverId,
    user,
    "CREATE_INVITES",
  );
  const canManage =
    Boolean(state) ||
    Boolean(
      await requireServerPermission(params.serverId, user, "MANAGE_SERVER"),
    );
  const member = await prisma.serverMember.findUnique({
    where: { serverId_userId: { serverId: params.serverId, userId: user.id } },
  });
  if (!member) return error("Kein Zugriff", 403);

  const invites = await prisma.invite.findMany({
    where: canManage
      ? { serverId: params.serverId }
      : { serverId: params.serverId, createdById: user.id },
    orderBy: { createdAt: "desc" },
    take: 50,
    include: {
      createdBy: { select: { id: true, username: true, displayName: true } },
      channel: { select: { id: true, name: true, type: true } },
    },
  });
  return json({
    invites: invites.map((invite: InviteListItem) => ({
      ...invite,
      channel: canManage
        ? invite.channel
        : invite.channel
          ? {
              id: invite.channelId,
              name: "Privater oder eingeschränkter Channel",
              type: "PRIVATE",
            }
          : null,
      url: inviteUrl(invite.code),
    })),
  });
}

export async function POST(
  request: Request,
  { params }: { params: { serverId: string } },
) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);

    if (
      !(await requireServerPermission(params.serverId, user, "CREATE_INVITES"))
    )
      return error("Keine Berechtigung", 403);

    const body = createInviteSchema.parse(
      await request.json().catch(() => ({})),
    );
    if (body.channelId) {
      const channel = await prisma.channel.findFirst({
        where: { id: body.channelId, serverId: params.serverId },
        select: { id: true },
      });
      if (!channel) return error("Channel-Ziel nicht gefunden", 404);
    }

    let inviteCode = code();
    while (await prisma.invite.findUnique({ where: { code: inviteCode } }))
      inviteCode = code();

    const invite = await prisma.invite.create({
      data: {
        code: inviteCode,
        serverId: params.serverId,
        createdById: user.id,
        channelId: body.channelId || null,
        maxUses: body.maxUses || null,
        expiresAt: body.expiresInHours
          ? new Date(Date.now() + body.expiresInHours * 60 * 60 * 1000)
          : null,
      },
      include: {
        createdBy: { select: { id: true, username: true, displayName: true } },
        channel: { select: { id: true, name: true, type: true } },
      },
    });

    await prisma.auditLog
      .create({
        data: {
          action: "SERVER_UPDATED",
          actorId: user.id,
          serverId: params.serverId,
          targetId: invite.id,
          meta: JSON.stringify({
            inviteCreated: invite.code,
            channelId: invite.channelId,
            maxUses: invite.maxUses,
            expiresAt: invite.expiresAt,
          }),
        },
      })
      .catch(() => undefined);
    await emitToServerMembers(params.serverId, "server:invite:changed", {
      serverId: params.serverId,
      action: "created",
      invite,
    });
    emitAdminRefresh("invite_created", {
      serverId: params.serverId,
      inviteId: invite.id,
    });
    return json(
      {
        invite: { ...invite, url: inviteUrl(invite.code) },
        url: inviteUrl(invite.code),
      },
      201,
    );
  } catch (err) {
    return handleError(err);
  }
}
