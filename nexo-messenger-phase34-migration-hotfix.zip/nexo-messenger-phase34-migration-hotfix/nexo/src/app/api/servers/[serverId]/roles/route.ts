import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { roleSchema } from "@/lib/validators";
import { emitAdminRefresh, emitToServerMembers, emitServerPrivateChannelsRecheck } from "@/lib/live";
import { canManageRole } from "@/lib/permissions";

export async function POST(request: Request, { params }: { params: { serverId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    if (!(await canManageRole(params.serverId, user))) return error("Keine Berechtigung", 403);
    const body = roleSchema.parse(await request.json());
    const count = await prisma.role.count({ where: { serverId: params.serverId } });
    const role = await prisma.role.create({ data: { serverId: params.serverId, name: body.name, color: body.color, permissions: JSON.stringify(body.permissions), position: count } });
    await prisma.auditLog.create({ data: { action: "ROLE_CREATED", actorId: user.id, serverId: params.serverId, targetId: role.id, meta: JSON.stringify({ name: role.name }) } }).catch(() => undefined);
    await emitServerPrivateChannelsRecheck(params.serverId);
    await emitToServerMembers(params.serverId, "server:role:changed", { serverId: params.serverId, action: "created", role });
    emitAdminRefresh("role_created", { serverId: params.serverId, roleId: role.id });
    return json({ role }, 201);
  } catch (err) { return handleError(err); }
}
