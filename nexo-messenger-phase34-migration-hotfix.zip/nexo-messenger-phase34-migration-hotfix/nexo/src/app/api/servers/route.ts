import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { serverSchema } from "@/lib/validators";
import { emitAdminRefresh, emitToAdmins, emitToUser } from "@/lib/live";
import { filterVisibleChannelsForUser } from "@/lib/permissions";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);

  const serversRaw = await prisma.server.findMany({
    where: { members: { some: { userId: user.id } } },
    orderBy: { createdAt: "asc" },
    include: { channels: { orderBy: { position: "asc" }, select: { id: true, name: true, type: true, categoryId: true, isPrivate: true } }, _count: { select: { members: true } } }
  });

  const servers = [];
  for (const server of serversRaw) {
    const channels = await filterVisibleChannelsForUser(server.channels, user);
    servers.push({ ...server, channels });
  }

  return json({ servers });
}

export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);

    const body = serverSchema.parse(await request.json());
    const server = await prisma.server.create({
      data: {
        name: body.name,
        iconUrl: body.iconUrl || null,
        isPrivate: body.isPrivate,
        ownerId: user.id,
        members: { create: { userId: user.id, isOwner: true, isAdmin: true } },
        roles: { create: [{ name: "Owner", color: "#ffffff", permissions: JSON.stringify(["*"]) }, { name: "Moderator", color: "#a1a1aa", permissions: JSON.stringify(["MANAGE_MESSAGES", "MANAGE_CHANNELS"]) }] },
        categories: { create: [{ name: "Text", position: 0 }, { name: "Voice", position: 1 }] },
        channels: { create: [{ name: "general", type: "TEXT", position: 0 }, { name: "voice", type: "VOICE", position: 1 }] }
      },
      include: { channels: true, _count: { select: { members: true } } }
    });

    await prisma.auditLog.create({ data: { action: "SERVER_CREATED", actorId: user.id, serverId: server.id, meta: JSON.stringify({ name: body.name }) } });
    emitToUser(user.id, "server:created", { server });
    emitToAdmins("admin:server:created", { server });
    emitAdminRefresh("server_created", { serverId: server.id });
    return json({ server }, 201);
  } catch (err) {
    return handleError(err);
  }
}
