import bcrypt from "bcryptjs";
import prisma from "@/lib/prisma";
import { createSessionCookie } from "@/lib/auth";
import { loginSchema } from "@/lib/validators";
import { error, handleError, json } from "@/lib/http";
import { rateLimits } from "@/lib/rate-limit";

export async function POST(request: Request) {
  try {
    const ip = request.headers.get("x-forwarded-for") || "local";
    const body = loginSchema.parse(await request.json());
    const limited = await rateLimits.login(ip, body.email);
    if (!limited.ok) return error("Zu viele Login-Versuche. Warte kurz.", 429);
    const user = await prisma.user.findUnique({ where: { email: body.email.toLowerCase() } });
    if (!user) return error("Login fehlgeschlagen", 401);
    if (user.isBanned) return error(`Du wurdest gesperrt. Grund: ${user.banReason || "Kein Grund angegeben"}`, 403);

    const ok = await bcrypt.compare(body.password, user.passwordHash);
    if (!ok) return error("Login fehlgeschlagen", 401);

    if (user.twoFactorEnabled) {
      const code = String(body.twoFactorCode || "").trim();
      if (!code) return json({ requiresTwoFactor: true, message: "Bitte gib deinen Login-Code ein." }, 202);
      const codeOk = user.twoFactorCodeHash ? await bcrypt.compare(code, user.twoFactorCodeHash) : false;
      if (!codeOk) return error("Login-Code ist falsch", 401);
    }

    const updated = await prisma.user.update({
      where: { id: user.id },
      data: { status: "ONLINE", lastSeenAt: new Date() },
      select: { id: true, email: true, username: true, displayName: true, avatarUrl: true, avatarColor: true, status: true, onboarded: true, sessionVersion: true }
    });

    await createSessionCookie(updated);
    const { sessionVersion: _sessionVersion, ...publicUser } = updated;
    return json({ user: publicUser });
  } catch (err) {
    return handleError(err);
  }
}
