import { clearSessionCookie, getCurrentUser } from "@/lib/auth";
import prisma from "@/lib/prisma";
import { json } from "@/lib/http";

export async function POST() {
  const user = await getCurrentUser();
  if (user) {
    await prisma.user.update({ where: { id: user.id }, data: { status: "OFFLINE", lastSeenAt: new Date() } });
  }
  clearSessionCookie();
  return json({ ok: true });
}
