import { getCurrentUser } from "@/lib/auth";
import { error, json } from "@/lib/http";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);
  const { sessionVersion: _sessionVersion, ...publicUser } = user;
  return json({ user: publicUser });
}
