import bcrypt from "bcryptjs";
import prisma from "@/lib/prisma";
import { createSessionCookie } from "@/lib/auth";
import { registerSchema } from "@/lib/validators";
import { error, handleError, json } from "@/lib/http";
import { rateLimits } from "@/lib/rate-limit";

function avatarColor(seed: string) {
  const colors = ["#ffffff", "#e5e7eb", "#d4d4d8", "#a1a1aa", "#f4f4f5", "#cbd5e1"];
  let sum = 0;
  for (const char of seed) sum += char.charCodeAt(0);
  return colors[sum % colors.length];
}

export async function POST(request: Request) {
  try {
    const ip = request.headers.get("x-forwarded-for") || "local";
    const limited = await rateLimits.register(ip);
    if (!limited.ok) return error("Zu viele Registrierungen. Warte bitte etwas.", 429);
    const body = registerSchema.parse(await request.json());
    const email = body.email.toLowerCase();
    const username = body.username.toLowerCase();

    const existing = await prisma.user.findFirst({ where: { OR: [{ email }, { username }] } });
    if (existing) return error("E-Mail oder Username ist bereits vergeben", 409);

    const user = await prisma.user.create({
      data: {
        email,
        username,
        displayName: body.displayName,
        avatarColor: avatarColor(email),
        passwordHash: await bcrypt.hash(body.password, 12),
        status: "ONLINE"
      },
      select: { id: true, email: true, username: true, displayName: true, avatarUrl: true, avatarColor: true, status: true, onboarded: true, sessionVersion: true }
    });

    await createSessionCookie(user);
    const { sessionVersion: _sessionVersion, ...publicUser } = user;
    return json({ user: publicUser });
  } catch (err) {
    return handleError(err);
  }
}
