import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, json } from "@/lib/http";

const publicUserSelect = { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true, isBanned: true } as const;

type AdminPublicUser = { id: string; username: string; displayName: string; avatarUrl: string | null; avatarColor: string; isBanned: boolean };
type AdminReportMessage = { id: string; content: string; deletedAt: Date | null; createdAt: Date; channel?: { id: string; name: string; isPrivate: boolean; server?: { id: string; name: string } | null } | null; threadId?: string; author?: AdminPublicUser | null };
type AdminReportServer = { id: string; name: string };

type AdminReport = {
  id: string;
  reporterId: string;
  targetUserId: string | null;
  messageId: string | null;
  dmMessageId: string | null;
  serverId: string | null;
  reason: string;
  status: string;
  createdAt: Date;
  updatedAt: Date;
};

export async function GET(request: Request) {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);
  if (!user.isAdmin) return error("Nur Admin", 403);

  const q = new URL(request.url).searchParams.get("q")?.trim() || "";
  const [users, tickets, servers, logs, reports, counts] = await Promise.all([
    prisma.user.findMany({
      where: q ? { OR: [{ username: { contains: q } }, { displayName: { contains: q } }, { email: { contains: q } }] } : {},
      orderBy: { createdAt: "desc" },
      take: 25,
      select: { id: true, email: true, username: true, displayName: true, isBanned: true, banReason: true, bannedAt: true, status: true, createdAt: true }
    }),
    prisma.ticket.findMany({ orderBy: { updatedAt: "desc" }, take: 100, include: { user: { select: { id: true, username: true, displayName: true, email: true } }, messages: { orderBy: { createdAt: "asc" }, include: { author: { select: { displayName: true, username: true } }, attachments: { orderBy: { createdAt: "asc" } } } } } }),
    prisma.server.findMany({ orderBy: { createdAt: "desc" }, take: 20, include: { _count: { select: { members: true, channels: true } } } }),
    prisma.auditLog.findMany({ where: { archivedAt: null }, orderBy: { createdAt: "desc" }, take: 40, include: { actor: { select: { username: true, displayName: true } }, server: { select: { name: true } } } }),
    prisma.report.findMany({ orderBy: { createdAt: "desc" }, take: 80, include: { notes: { orderBy: { createdAt: "desc" }, include: { admin: { select: { id: true, username: true, displayName: true } } } } } }) as Promise<(AdminReport & { notes?: Array<{ id: string; reportId: string; adminId: string; note: string; createdAt: Date; admin?: { id: string; username: string; displayName: string } | null }> })[]>,
    Promise.all([prisma.user.count(), prisma.server.count(), prisma.message.count(), prisma.ticket.count({ where: { status: { not: "CLOSED" }, archivedAt: null } }), prisma.ticket.count({ where: { archivedAt: { not: null } } }), prisma.report.count({ where: { status: "open" } })])
  ]);


  const userIds = Array.from(new Set(reports.flatMap((report: AdminReport) => [report.reporterId, report.targetUserId]).filter(Boolean) as string[]));
  const messageIds = reports.map((report: AdminReport) => report.messageId).filter(Boolean) as string[];
  const dmMessageIds = reports.map((report: AdminReport) => report.dmMessageId).filter(Boolean) as string[];
  const serverIds = reports.map((report: AdminReport) => report.serverId).filter(Boolean) as string[];

  const [reportUsers, reportMessages, reportDmMessages, reportServers] = await Promise.all([
    userIds.length ? prisma.user.findMany({ where: { id: { in: userIds } }, select: publicUserSelect }) as Promise<AdminPublicUser[]> : Promise.resolve([] as AdminPublicUser[]),
    messageIds.length ? prisma.message.findMany({ where: { id: { in: messageIds } }, select: { id: true, content: true, deletedAt: true, createdAt: true, channel: { select: { id: true, name: true, isPrivate: true, server: { select: { id: true, name: true } } } }, author: { select: publicUserSelect } } }) as Promise<AdminReportMessage[]> : Promise.resolve([] as AdminReportMessage[]),
    dmMessageIds.length ? prisma.directMessage.findMany({ where: { id: { in: dmMessageIds } }, select: { id: true, content: true, deletedAt: true, createdAt: true, threadId: true, author: { select: publicUserSelect } } }) as Promise<AdminReportMessage[]> : Promise.resolve([] as AdminReportMessage[]),
    serverIds.length ? prisma.server.findMany({ where: { id: { in: serverIds } }, select: { id: true, name: true } }) as Promise<AdminReportServer[]> : Promise.resolve([] as AdminReportServer[])
  ]);

  const userMap = new Map(reportUsers.map((item) => [item.id, item]));
  const messageMap = new Map(reportMessages.map((item) => [item.id, item]));
  const dmMessageMap = new Map(reportDmMessages.map((item) => [item.id, item]));
  const serverMap = new Map(reportServers.map((item) => [item.id, item]));
  const enrichedReports = reports.map((report: AdminReport & { notes?: Array<{ id: string; reportId: string; adminId: string; note: string; createdAt: Date; admin?: { id: string; username: string; displayName: string } | null }> }) => ({
    ...report,
    reporter: userMap.get(report.reporterId) || null,
    targetUser: report.targetUserId ? userMap.get(report.targetUserId) || null : null,
    message: report.messageId ? messageMap.get(report.messageId) || null : null,
    dmMessage: report.dmMessageId ? dmMessageMap.get(report.dmMessageId) || null : null,
    server: report.serverId ? serverMap.get(report.serverId) || null : null
  }));

  return json({ users, tickets, servers, logs, reports: enrichedReports, stats: { users: counts[0], servers: counts[1], messages: counts[2], openTickets: counts[3], archivedTickets: counts[4], openReports: counts[5] } });
}
