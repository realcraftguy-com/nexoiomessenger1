import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { emitAdminRefresh, emitToAdmins, emitToTicket, emitToUser } from "@/lib/live";

const ticketInclude = {
  user: { select: { id: true, username: true, displayName: true, email: true, avatarColor: true } },
  messages: { orderBy: { createdAt: "asc" as const }, include: { author: { select: { id: true, displayName: true, username: true, avatarColor: true } }, attachments: { orderBy: { createdAt: "asc" as const } } } },
  attachments: { orderBy: { createdAt: "asc" as const } }
};

export async function PATCH() {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    if (!user.isAdmin) return error("Nur Admin", 403);

    const affected = await prisma.ticket.findMany({ where: { status: "CLOSED", archivedAt: null }, select: { id: true, userId: true } });
    const now = new Date();
    const result = await prisma.ticket.updateMany({ where: { id: { in: affected.map((ticket: { id: string }) => ticket.id) } }, data: { archivedAt: now, archivedById: user.id } });
    const tickets = await prisma.ticket.findMany({ where: { id: { in: affected.map((ticket: { id: string }) => ticket.id) } }, include: ticketInclude });

    await prisma.auditLog.create({ data: { action: "TICKETS_CLEANED", actorId: user.id, meta: JSON.stringify({ archivedCount: result.count }) } }).catch(() => undefined);

    emitToAdmins("admin:tickets:cleanup", { count: result.count, ids: affected.map((ticket: { id: string }) => ticket.id), tickets });
    for (const ticket of tickets) {
      emitToTicket(ticket.id, "ticket:updated", { ticketId: ticket.id, ticket });
      emitToUser(ticket.userId, "ticket:updated", { ticketId: ticket.id, ticket });
    }
    emitAdminRefresh("tickets_cleanup", { count: result.count });

    return json({ ok: true, archivedCount: result.count, tickets });
  } catch (err) {
    return handleError(err);
  }
}
