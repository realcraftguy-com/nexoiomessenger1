import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { emitAdminRefresh, emitToAdmins, emitToTicket, emitToUser } from "@/lib/live";

const ticketInclude = {
  user: { select: { id: true, username: true, displayName: true, email: true, avatarColor: true } },
  messages: {
    orderBy: { createdAt: "asc" as const },
    include: {
      author: { select: { id: true, displayName: true, username: true, avatarColor: true } },
      attachments: { orderBy: { createdAt: "asc" as const } }
    }
  },
  attachments: { orderBy: { createdAt: "asc" as const } }
};

export async function PATCH(request: Request, { params }: { params: { ticketId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    if (!user.isAdmin) return error("Nur Admin", 403);

    const body = await request.json().catch(() => ({}));
    const archive = body.archive !== false;

    const ticket = await prisma.ticket.findUnique({ where: { id: params.ticketId } });
    if (!ticket) return error("Ticket nicht gefunden", 404);
    if (archive && ticket.status !== "CLOSED") return error("Nur geschlossene Tickets können archiviert werden.", 400);

    const updated = await prisma.ticket.update({
      where: { id: ticket.id },
      data: archive ? { archivedAt: new Date(), archivedById: user.id } : { archivedAt: null, archivedById: null },
      include: ticketInclude
    });

    await prisma.auditLog.create({ data: { action: archive ? "TICKET_ARCHIVED" : "TICKET_RESTORED", actorId: user.id, targetId: ticket.id, meta: JSON.stringify({ archived: archive, title: ticket.title }) } }).catch(() => undefined);

    emitToTicket(updated.id, "ticket:updated", { ticketId: updated.id, ticket: updated });
    emitToUser(updated.userId, "ticket:updated", { ticketId: updated.id, ticket: updated });
    emitToAdmins("admin:ticket:archived", { ticket: updated, archive });
    emitAdminRefresh(archive ? "ticket_archived" : "ticket_restored", { ticketId: updated.id });

    return json({ ticket: updated });
  } catch (err) {
    return handleError(err);
  }
}
