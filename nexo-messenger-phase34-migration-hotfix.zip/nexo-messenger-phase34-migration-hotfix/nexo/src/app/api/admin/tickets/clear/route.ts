import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, json } from "@/lib/http";
import { emitAdminRefresh, emitToAdmins, emitToUser } from "@/lib/live";

export async function DELETE(request: Request) {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);
  if (!user.isAdmin) return error("Nur Admin", 403);

  const params = new URL(request.url).searchParams;
  const mode = params.get("mode") || "closed";
  const where = mode === "all" ? { archivedAt: null } : mode === "closed" ? { status: "CLOSED" as const, archivedAt: null } : { archivedAt: null };
  const tickets = await prisma.ticket.findMany({ where, select: { id: true, userId: true } });
  const ids = tickets.map((ticket: { id: string }) => ticket.id);
  const now = new Date();
  const result = await prisma.ticket.updateMany({ where: { id: { in: ids } }, data: { archivedAt: now, archivedById: user.id } });

  await prisma.auditLog.create({ data: { action: "TICKETS_CLEARED", actorId: user.id, meta: JSON.stringify({ archivedCount: result.count, mode }) } }).catch(() => undefined);
  emitToAdmins("admin:tickets:archived", { mode, ids, count: result.count });
  for (const ticket of tickets) emitToUser(ticket.userId, "ticket:updated", { ticketId: ticket.id, archived: true });
  emitAdminRefresh("tickets_archived", { mode, count: result.count });

  return json({ ok: true, archivedCount: result.count, ids });
}
