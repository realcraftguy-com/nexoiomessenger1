import bcrypt from "bcryptjs";
import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { emitAdminRefresh, emitToAdmins, emitToUser } from "@/lib/live";
import { z } from "zod";

const schema = z.object({
  isBanned: z.boolean().optional(),
  banReason: z.string().max(300).optional(),
  username: z.string().min(3).max(24).regex(/^[a-zA-Z0-9_.-]+$/).optional(),
  displayName: z.string().min(2).max(40).optional(),
  newPassword: z.string().min(8).max(120).optional()
});

export async function PATCH(request: Request, { params }: { params: { userId: string } }) {
  try {
    const admin = await getCurrentUser();
    if (!admin) return error("Nicht eingeloggt", 401);
    if (!admin.isAdmin) return error("Nur Admin", 403);

    const body = schema.parse(await request.json());
    const data: Record<string, unknown> = {};
    if (typeof body.isBanned === "boolean") {
      data.isBanned = body.isBanned;
      data.banReason = body.isBanned ? (body.banReason?.trim() || "Kein Grund angegeben") : null;
      data.bannedAt = body.isBanned ? new Date() : null;
      if (body.isBanned) data.status = "OFFLINE";
    }
    if (body.username) data.username = body.username.toLowerCase();
    if (body.displayName) data.displayName = body.displayName;
    if (body.newPassword) {
      data.passwordHash = await bcrypt.hash(body.newPassword, 12);
      data.sessionVersion = { increment: 1 };
      data.status = "OFFLINE";
    }

    const user = await prisma.user.update({ where: { id: params.userId }, data, select: { id: true, email: true, username: true, displayName: true, isBanned: true, banReason: true, bannedAt: true, status: true, sessionVersion: true, createdAt: true } });

    const action = body.newPassword ? "PASSWORD_RESET" : typeof body.isBanned === "boolean" ? (body.isBanned ? "USER_BANNED" : "USER_UNBANNED") : "USER_RENAMED";
    await prisma.auditLog.create({ data: { action, actorId: admin.id, targetId: user.id, meta: JSON.stringify({ changed: Object.keys(data).filter((key) => key !== "passwordHash"), banReason: body.banReason?.trim() || undefined, revokedSessions: Boolean(body.newPassword) }) } });

    emitToAdmins("admin:user:updated", { user });
    emitAdminRefresh("user_updated", { userId: user.id, action });
    if (body.newPassword) emitToUser(user.id, "account:session_revoked", { reason: "Dein Passwort wurde von einem Admin zurückgesetzt. Bitte melde dich neu an." });
    if (body.isBanned === true) emitToUser(user.id, "account:banned", { reason: user.banReason || "Kein Grund angegeben" });

    return json({ user });
  } catch (err) {
    return handleError(err);
  }
}
