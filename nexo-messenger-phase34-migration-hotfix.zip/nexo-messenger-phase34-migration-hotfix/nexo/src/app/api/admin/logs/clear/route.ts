import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, json } from "@/lib/http";
import { emitAdminRefresh, emitToAdmins } from "@/lib/live";

export async function DELETE() {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);
  if (!user.isAdmin) return error("Nur Admin", 403);

  const result = await prisma.auditLog.updateMany({ where: { archivedAt: null }, data: { archivedAt: new Date() } });
  emitToAdmins("admin:audit:archived", { count: result.count, by: user.id });
  emitAdminRefresh("audit_archived", { count: result.count });
  return json({ ok: true, count: result.count, archived: true });
}
