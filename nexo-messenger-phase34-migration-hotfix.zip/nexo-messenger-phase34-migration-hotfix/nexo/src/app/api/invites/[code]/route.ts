import prisma from "@/lib/prisma";
import { canAccessChannel } from "@/lib/permissions";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import {
  emitAdminRefresh,
  emitToAdmins,
  emitToServerMembers,
  emitToUser,
} from "@/lib/live";

function validateInvite(invite: {
  disabledAt?: Date | null;
  expiresAt?: Date | null;
  maxUses?: number | null;
  uses: number;
}) {
  if (invite.disabledAt) return "Invite wurde deaktiviert";
  if (invite.expiresAt && invite.expiresAt < new Date())
    return "Invite ist abgelaufen";
  if (invite.maxUses && invite.uses >= invite.maxUses)
    return "Invite wurde zu oft benutzt";
  return null;
}

export async function GET(
  _: Request,
  { params }: { params: { code: string } },
) {
  const invite = await prisma.invite.findUnique({
    where: { code: params.code },
    include: {
      channel: { select: { id: true, name: true, type: true } },
      createdBy: { select: { id: true, username: true, displayName: true } },
      server: {
        select: {
          id: true,
          name: true,
          iconUrl: true,
          _count: { select: { members: true } },
        },
      },
    },
  });
  if (!invite) return error("Invite nicht gefunden", 404);
  const invalid = validateInvite(invite);
  if (invalid) return error(invalid, 410);
  const user = await getCurrentUser().catch(() => null);
  let channel = invite.channel;
  if (invite.channel?.id) {
    const canSeeTarget = user
      ? await canAccessChannel(
          invite.channel.id,
          user.id,
          user.isAdmin,
          "VIEW_CHANNEL",
        )
      : null;
    if (!canSeeTarget) channel = null;
  }
  return json({ invite: { ...invite, channel } });
}

export async function POST(
  _: Request,
  { params }: { params: { code: string } },
) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    const invite = await prisma.invite.findUnique({
      where: { code: params.code },
      include: {
        server: { include: { channels: { orderBy: { position: "asc" } } } },
      },
    });
    if (!invite) return error("Invite nicht gefunden", 404);
    const invalid = validateInvite(invite);
    if (invalid) return error(invalid, 410);

    const member = await prisma.serverMember.upsert({
      where: {
        serverId_userId: { serverId: invite.serverId, userId: user.id },
      },
      update: {},
      create: { serverId: invite.serverId, userId: user.id },
      include: {
        user: {
          select: {
            id: true,
            username: true,
            displayName: true,
            avatarUrl: true,
            avatarColor: true,
            status: true,
          },
        },
      },
    });
    await prisma.invite.update({
      where: { id: invite.id },
      data: { uses: { increment: 1 } },
    });

    emitToUser(user.id, "server:created", { server: invite.server });
    await emitToServerMembers(invite.serverId, "server:member:joined", {
      serverId: invite.serverId,
      member,
    });
    emitToAdmins("admin:server:updated", { serverId: invite.serverId });
    emitAdminRefresh("server_member_joined", {
      serverId: invite.serverId,
      userId: user.id,
      inviteId: invite.id,
    });

    let targetChannel = invite.channelId
      ? invite.server.channels.find(
          (channel: { id: string }) => channel.id === invite.channelId,
        )
      : null;
    if (
      targetChannel &&
      !(await canAccessChannel(
        targetChannel.id,
        user.id,
        user.isAdmin,
        "VIEW_CHANNEL",
      ))
    )
      targetChannel = null;
    let firstText = targetChannel || null;
    if (!firstText) {
      for (const channel of invite.server.channels) {
        if (
          channel.type === "TEXT" &&
          (await canAccessChannel(
            channel.id,
            user.id,
            user.isAdmin,
            "VIEW_CHANNEL",
          ))
        ) {
          firstText = channel;
          break;
        }
      }
    }
    return json({ serverId: invite.serverId, channelId: firstText?.id });
  } catch (err) {
    return handleError(err);
  }
}
