import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, json } from "@/lib/http";
import { canAccessChannel } from "@/lib/permissions";

export async function GET(_: Request, { params }: { params: { channelId: string } }) {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);
  if (!(await canAccessChannel(params.channelId, user.id, user.isAdmin, "VIEW_CHANNEL"))) return error("Kein Zugriff", 403);
  const canPin = Boolean(await canAccessChannel(params.channelId, user.id, user.isAdmin, "MANAGE_MESSAGES"));
  const pins = await prisma.pinnedMessage.findMany({ where: { channelId: params.channelId }, orderBy: { createdAt: "desc" }, include: { message: { include: { author: { select: { id: true, username: true, displayName: true, avatarColor: true, avatarUrl: true } }, fileAttachments: { orderBy: { createdAt: "asc" } } } }, pinnedBy: { select: { id: true, username: true, displayName: true } } } });
  return json({ pins, canPin });
}
