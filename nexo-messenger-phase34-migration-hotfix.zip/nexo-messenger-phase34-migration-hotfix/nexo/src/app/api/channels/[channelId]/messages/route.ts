import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { messageSchema } from "@/lib/validators";
import { error, handleError, json } from "@/lib/http";
import { emitAdminRefresh, emitChannelEvent } from "@/lib/live";
import { attachMessageFilesByIds, attachmentIdsFromPayload, normalizeMessageForClient } from "@/lib/message-uploads";
import { rateLimits } from "@/lib/rate-limit";
import { createMentionNotifications } from "@/lib/notifications";
import { canAccessChannel } from "@/lib/permissions";

export async function GET(request: Request, { params }: { params: { channelId: string } }) {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);
  const channel = await canAccessChannel(params.channelId, user.id, user.isAdmin, "VIEW_CHANNEL");
  if (!channel) return error("Kein Zugriff", 403);
  const search = new URL(request.url).searchParams;
  const limit = Math.min(Math.max(Number(search.get("limit") || 80), 1), 100);
  const before = search.get("before");
  const around = search.get("around");
  const include = {
    author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } },
    fileAttachments: { orderBy: { createdAt: "asc" as const } },
    replyTo: { select: { id: true, content: true, deletedAt: true, author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } } } }
  };

  if (around) {
    const target = await prisma.message.findFirst({ where: { id: around, channelId: params.channelId, deletedAt: null }, select: { id: true, createdAt: true } });
    if (!target) return error("Nachricht nicht gefunden oder nicht sichtbar.", 404);
    const windowLimit = Math.min(Math.max(Number(search.get("limit") || 40), 10), 80);
    const [olderDesc, targetMessage, newer] = await Promise.all([
      prisma.message.findMany({ where: { channelId: params.channelId, deletedAt: null, createdAt: { lt: target.createdAt } }, orderBy: { createdAt: "desc" }, take: Math.floor(windowLimit / 2), include }),
      prisma.message.findUnique({ where: { id: target.id }, include }),
      prisma.message.findMany({ where: { channelId: params.channelId, deletedAt: null, createdAt: { gt: target.createdAt } }, orderBy: { createdAt: "asc" }, take: Math.ceil(windowLimit / 2), include })
    ]);
    const messages = [...olderDesc.reverse(), ...(targetMessage ? [targetMessage] : []), ...newer];
    return json({ messages: messages.map(normalizeMessageForClient), hasMoreBefore: olderDesc.length >= Math.floor(windowLimit / 2), hasMoreAfter: newer.length >= Math.ceil(windowLimit / 2), around: target.id });
  }

  const beforeMessage = before ? await prisma.message.findFirst({ where: { id: before, channelId: params.channelId }, select: { createdAt: true } }) : null;
  const messages = await prisma.message.findMany({
    where: { channelId: params.channelId, deletedAt: null, ...(beforeMessage ? { createdAt: { lt: beforeMessage.createdAt } } : {}) },
    orderBy: { createdAt: "desc" },
    take: limit,
    include
  });
  return json({ messages: messages.reverse().map(normalizeMessageForClient), hasMore: messages.length === limit });
}

export async function POST(request: Request, { params }: { params: { channelId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    const channel = await canAccessChannel(params.channelId, user.id, user.isAdmin, "SEND_MESSAGES");
    if (!channel) return error("Keine Schreibberechtigung", 403);

    const body = messageSchema.parse(await request.json());
    const attachmentIds = attachmentIdsFromPayload(body);
    if (attachmentIds.length && !(await canAccessChannel(params.channelId, user.id, user.isAdmin, "UPLOAD_FILES"))) return error("Keine Upload-Berechtigung", 403);

    if (body.clientMessageId) {
      const existing = await prisma.message.findFirst({
        where: { channelId: params.channelId, authorId: user.id, clientMessageId: body.clientMessageId },
        include: { author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } }, fileAttachments: { orderBy: { createdAt: "asc" } } }
      });
      if (existing) return json({ message: normalizeMessageForClient(existing) }, 200);
    }

    const canBypassSlowmode = Boolean(await canAccessChannel(params.channelId, user.id, user.isAdmin, "MANAGE_MESSAGES"));
    if (!canBypassSlowmode && channel.slowmodeSeconds > 0) {
      const recent = await prisma.message.findFirst({ where: { channelId: params.channelId, authorId: user.id, createdAt: { gt: new Date(Date.now() - channel.slowmodeSeconds * 1000) } }, select: { id: true } });
      if (recent) return error(`Slowmode aktiv. Warte ${channel.slowmodeSeconds} Sekunden.`, 429);
    }
    const limited = await rateLimits.message(user.id, params.channelId);
    if (!limited.ok) return error("Du sendest gerade zu schnell.", 429);

    const message = await prisma.message.create({
      data: { channelId: params.channelId, authorId: user.id, content: body.content.trim(), replyToId: body.replyToId || null, clientMessageId: body.clientMessageId || null, attachments: "[]" },
      include: { author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } }, fileAttachments: true }
    });
    const files = await attachMessageFilesByIds({ uploaderId: user.id, attachmentIds, messageId: message.id });
    await createMentionNotifications({ content: body.content, messageId: message.id, excludeUserId: user.id }).catch(() => undefined);
    const fullMessage = await prisma.message.findUnique({ where: { id: message.id }, include: { author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } }, fileAttachments: { orderBy: { createdAt: "asc" } }, replyTo: { select: { id: true, content: true, deletedAt: true, author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } } } } } });
    await emitChannelEvent(params.channelId, "channel:message", normalizeMessageForClient(fullMessage || message));
    if (files.length) emitAdminRefresh("message_attachment_uploaded", { serverId: channel.serverId });
    return json({ message: normalizeMessageForClient(fullMessage || message) }, 201);
  } catch (err) { return handleError(err); }
}
