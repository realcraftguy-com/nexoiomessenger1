import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { z } from "zod";

export async function PATCH(request: Request, { params }: { params: { chatId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    const body = z.object({ title: z.string().min(1).max(80) }).parse(await request.json());
    const chat = await prisma.aIChat.findFirst({ where: { id: params.chatId, userId: user.id } });
    if (!chat) return error("Chat nicht gefunden", 404);
    const updated = await prisma.aIChat.update({ where: { id: chat.id }, data: { title: body.title } });
    await prisma.auditLog.create({ data: { action: "AI_CHAT_RENAMED", actorId: user.id, targetId: chat.id, meta: JSON.stringify({ title: body.title }) } }).catch(() => undefined);
    return json({ chat: updated });
  } catch (err) { return handleError(err); }
}

export async function DELETE(_: Request, { params }: { params: { chatId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    const chat = await prisma.aIChat.findFirst({ where: { id: params.chatId, userId: user.id } });
    if (!chat) return error("Chat nicht gefunden", 404);
    await prisma.aIChat.delete({ where: { id: chat.id } });
    await prisma.auditLog.create({ data: { action: "AI_CHAT_DELETED", actorId: user.id, targetId: chat.id } }).catch(() => undefined);
    return json({ ok: true });
  } catch (err) { return handleError(err); }
}
