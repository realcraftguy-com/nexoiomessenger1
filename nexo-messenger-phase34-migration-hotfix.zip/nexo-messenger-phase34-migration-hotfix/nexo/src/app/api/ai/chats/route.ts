import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, json } from "@/lib/http";

export async function POST() {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);
  const chat = await prisma.aIChat.create({ data: { userId: user.id, title: "Neuer AI-Chat" }, include: { messages: { orderBy: { createdAt: "asc" } } } });
  await prisma.auditLog.create({ data: { action: "AI_CHAT_CREATED", actorId: user.id, targetId: chat.id } }).catch(() => undefined);
  return json({ chat }, 201);
}
