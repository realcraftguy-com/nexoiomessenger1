import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { aiSchema } from "@/lib/validators";
import { error, handleError, json } from "@/lib/http";
import { rateLimits } from "@/lib/rate-limit";

const systemPrompt = `Du bist Nexo AI, ein hilfreicher AI-Assistent im Messenger Nexo. Du hilfst beim Lernen, Planen, Schreiben und Coden. Antworte klar, ehrlich und freundlich. Gib keine API-Keys oder Secrets aus und erkläre bei Code Sicherheitsrisiken einfach.`;

function aiBaseUrl(apiKey?: string) {
  const configured = process.env.OPENAI_BASE_URL?.trim();
  if (configured) return configured.replace(/\/$/, "");
  if (apiKey?.startsWith("nvapi-")) return "https://integrate.api.nvidia.com/v1";
  return "https://api.openai.com/v1";
}

function extractToken(line: string) {
  if (!line.startsWith("data:")) return "";
  const payload = line.slice(5).trim();
  if (!payload || payload === "[DONE]") return "";
  try {
    const parsed = JSON.parse(payload);
    return parsed.choices?.[0]?.delta?.content || parsed.choices?.[0]?.message?.content || "";
  } catch {
    return "";
  }
}

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function chunkText(text: string) {
  const chunks = text.match(/\S+\s*/g);
  return chunks && chunks.length > 0 ? chunks : [text];
}

async function saveAssistantMessage(chatId: string, answer: string) {
  await prisma.aIMessage.create({ data: { chatId, role: "assistant", content: answer } });
  await prisma.aIChat.update({ where: { id: chatId }, data: { updatedAt: new Date() } });
}

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);

  const chats = await prisma.aIChat.findMany({
    where: { userId: user.id },
    orderBy: { updatedAt: "desc" },
    include: { messages: { orderBy: { createdAt: "asc" }, take: 30 } }
  });

  return json({ chats });
}

export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);

    const setting = await prisma.systemSetting.findUnique({ where: { key: "ai.enabled" } }).catch(() => null);
    if (setting && setting.value === false) return error("Nexo AI ist aktuell deaktiviert", 503);
    if ((user as any).aiDisabled) return error("Nexo AI ist für diesen Account deaktiviert", 403);
    const limitedUser = await rateLimits.aiUser(user.id);
    const limitedGlobal = await rateLimits.aiGlobal();
    if (!limitedUser.ok || !limitedGlobal.ok) return error("AI-Limit erreicht. Versuche es später erneut.", 429);

    const apiKey = process.env.OPENAI_API_KEY?.trim();
    if (!apiKey) return error("Nexo AI ist gerade nicht verfügbar", 503);

    const body = aiSchema.parse(await request.json());
    const chat = body.chatId
      ? await prisma.aIChat.findFirst({ where: { id: body.chatId, userId: user.id } })
      : await prisma.aIChat.create({ data: { userId: user.id, title: body.content.slice(0, 48) || "Neuer AI-Chat" } });

    if (!chat) return error("AI-Chat nicht gefunden", 404);

    await prisma.aIMessage.create({ data: { chatId: chat.id, userId: user.id, role: "user", content: body.content } });

    const history = await prisma.aIMessage.findMany({ where: { chatId: chat.id }, orderBy: { createdAt: "asc" }, take: 20 });
    const messages = [
      { role: "system", content: systemPrompt },
      ...history.map((msg: { role: string; content: string }) => ({ role: msg.role as "user" | "assistant", content: msg.content }))
    ];

    const baseUrl = aiBaseUrl(apiKey);
    const model = process.env.OPENAI_MODEL || (apiKey.startsWith("nvapi-") ? "nvidia/llama-3.3-nemotron-super-49b-v1" : "gpt-4o-mini");
    const headers = {
      "content-type": "application/json",
      authorization: `Bearer ${apiKey}`
    };

    const streamResponse = await fetch(`${baseUrl}/chat/completions`, {
      method: "POST",
      headers,
      body: JSON.stringify({
        model,
        messages,
        temperature: 0.7,
        max_tokens: Number(process.env.AI_MAX_TOKENS || 1200),
        stream: true
      })
    });

    const encoder = new TextEncoder();
    const decoder = new TextDecoder();

    if (streamResponse.ok && streamResponse.body) {
      let answer = "";
      const stream = new ReadableStream({
        async start(controller) {
          const reader = streamResponse.body!.getReader();
          let buffer = "";

          try {
            while (true) {
              const { done, value } = await reader.read();
              if (done) break;
              buffer += decoder.decode(value, { stream: true });
              const lines = buffer.split("\n");
              buffer = lines.pop() || "";

              for (const rawLine of lines) {
                const token = extractToken(rawLine.trim());
                if (!token) continue;
                answer += token;
                controller.enqueue(encoder.encode(token));
              }
            }

            if (!answer.trim()) answer = "Ich konnte gerade keine Antwort erstellen.";
            await saveAssistantMessage(chat.id, answer);
            controller.close();
          } catch (err) {
            console.error("AI stream error", err);
            if (!answer.trim()) controller.enqueue(encoder.encode("Nexo AI konnte die Antwort gerade nicht fertigstellen."));
            controller.close();
          }
        }
      });

      return new Response(stream, {
        headers: {
          "content-type": "text/plain; charset=utf-8",
          "cache-control": "no-store",
          "x-nexo-chat-id": chat.id
        }
      });
    }

    const streamErrorText = await streamResponse.text().catch(() => "");
    console.error("AI streaming provider error", streamErrorText.slice(0, 800));

    const normalResponse = await fetch(`${baseUrl}/chat/completions`, {
      method: "POST",
      headers,
      body: JSON.stringify({
        model,
        messages,
        temperature: 0.7,
        max_tokens: Number(process.env.AI_MAX_TOKENS || 1200),
        stream: false
      })
    });

    if (!normalResponse.ok) {
      const text = await normalResponse.text().catch(() => "");
      console.error("AI provider error", text.slice(0, 800));
      return error("Nexo AI konnte gerade nicht antworten", 502);
    }

    const data = await normalResponse.json();
    const answer = data.choices?.[0]?.message?.content || "Ich konnte gerade keine Antwort erstellen.";

    const simulatedStream = new ReadableStream({
      async start(controller) {
        try {
          for (const chunk of chunkText(answer)) {
            controller.enqueue(encoder.encode(chunk));
            await sleep(18);
          }
          await saveAssistantMessage(chat.id, answer);
          controller.close();
        } catch (err) {
          console.error("AI fallback stream error", err);
          controller.close();
        }
      }
    });

    return new Response(simulatedStream, {
      headers: {
        "content-type": "text/plain; charset=utf-8",
        "cache-control": "no-store",
        "x-nexo-chat-id": chat.id
      }
    });
  } catch (err) {
    return handleError(err);
  }
}
