import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { ticketCloseSchema } from "@/lib/validators";
import { error, handleError, json } from "@/lib/http";
import { emitAdminRefresh, emitToTicket, emitToUser } from "@/lib/live";

const ticketInclude = {
  user: { select: { id: true, username: true, displayName: true, email: true, avatarColor: true } },
  messages: { orderBy: { createdAt: "asc" as const }, include: { author: { select: { id: true, displayName: true, username: true, avatarColor: true } }, attachments: { orderBy: { createdAt: "asc" as const } } } },
  attachments: { orderBy: { createdAt: "asc" as const } }
};

export async function GET(_: Request, { params }: { params: { ticketId: string } }) {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);
  const ticket = await prisma.ticket.findUnique({ where: { id: params.ticketId }, include: ticketInclude });
  if (!ticket) return error("Ticket nicht gefunden", 404);
  if (ticket.userId !== user.id && !user.isAdmin) return error("Kein Zugriff", 403);
  return json({ ticket });
}

export async function PATCH(request: Request, { params }: { params: { ticketId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);

    const ticket = await prisma.ticket.findUnique({ where: { id: params.ticketId } });
    if (!ticket) return error("Ticket nicht gefunden", 404);
    if (ticket.userId !== user.id && !user.isAdmin) return error("Kein Zugriff", 403);
    if (ticket.status === "CLOSED") return error("Ticket ist bereits geschlossen", 400);

    const body = ticketCloseSchema.parse(await request.json().catch(() => ({})));
    const updated = await prisma.ticket.update({ where: { id: ticket.id }, data: { status: "CLOSED", closedAt: new Date(), closedById: user.id, closeReason: body.reason }, include: ticketInclude });
    await prisma.auditLog.create({ data: { action: "TICKET_CLOSED", actorId: user.id, targetId: ticket.id, meta: JSON.stringify({ reason: body.reason, title: ticket.title }) } }).catch(() => undefined);

    emitToTicket(ticket.id, "ticket:closed", { ticketId: ticket.id, ticket: updated, reason: body.reason });
    emitToTicket(ticket.id, "ticket:updated", { ticketId: ticket.id, ticket: updated });
    emitToUser(ticket.userId, "ticket:updated", { ticketId: ticket.id, ticket: updated });
    emitAdminRefresh("ticket_closed", { ticketId: ticket.id });
    return json({ ticket: updated });
  } catch (err) {
    return handleError(err);
  }
}
