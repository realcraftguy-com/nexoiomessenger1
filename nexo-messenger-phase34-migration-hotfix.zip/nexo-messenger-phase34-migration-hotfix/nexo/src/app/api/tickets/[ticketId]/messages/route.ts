import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { ticketMessageSchema } from "@/lib/validators";
import { error, handleError, json } from "@/lib/http";
import { filesFromFormData, saveTicketAttachments } from "@/lib/ticket-uploads";
import { emitAdminRefresh, emitToTicket, emitToUser } from "@/lib/live";
import { createNotification } from "@/lib/notifications";

async function parseMessageRequest(request: Request) {
  const contentType = request.headers.get("content-type") || "";
  if (contentType.includes("multipart/form-data")) {
    const formData = await request.formData();
    return { body: ticketMessageSchema.parse({ content: formData.get("content") }), files: filesFromFormData(formData) };
  }
  return { body: ticketMessageSchema.parse(await request.json()), files: [] as File[] };
}

const ticketInclude = {
  user: { select: { id: true, username: true, displayName: true, avatarColor: true } },
  messages: { orderBy: { createdAt: "asc" as const }, include: { author: { select: { id: true, displayName: true, username: true, avatarColor: true } }, attachments: { orderBy: { createdAt: "asc" as const } } } },
  attachments: { orderBy: { createdAt: "asc" as const } }
};

export async function POST(request: Request, { params }: { params: { ticketId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);

    const ticket = await prisma.ticket.findUnique({ where: { id: params.ticketId } });
    if (!ticket) return error("Ticket nicht gefunden", 404);
    if (ticket.userId !== user.id && !user.isAdmin) return error("Kein Zugriff", 403);
    if (ticket.status === "CLOSED") return error("Ticket ist geschlossen", 400);

    const { body, files } = await parseMessageRequest(request);
    const message = await prisma.ticketMessage.create({ data: { ticketId: ticket.id, authorId: user.id, content: body.content, isStaff: user.isAdmin }, include: { author: { select: { id: true, username: true, displayName: true, avatarColor: true } }, attachments: { orderBy: { createdAt: "asc" } } } });
    if (files.length) await saveTicketAttachments({ files, ticketId: ticket.id, messageId: message.id, uploaderId: user.id });
    const fullMessage = await prisma.ticketMessage.findUnique({ where: { id: message.id }, include: { author: { select: { id: true, username: true, displayName: true, avatarColor: true } }, attachments: { orderBy: { createdAt: "asc" } } } });
    await prisma.ticket.update({ where: { id: ticket.id }, data: { status: user.isAdmin ? "ANSWERED" : "OPEN", updatedAt: new Date() } });
    if (user.isAdmin) await prisma.auditLog.create({ data: { action: "ADMIN_REPLY", actorId: user.id, targetId: ticket.id, meta: JSON.stringify({ ticketTitle: ticket.title, attachments: files.length }) } });
    if (files.length) await prisma.auditLog.create({ data: { action: "TICKET_ATTACHMENT_UPLOADED", actorId: user.id, targetId: ticket.id, meta: JSON.stringify({ count: files.length }) } }).catch(() => undefined);
    const fullTicket = await prisma.ticket.findUnique({ where: { id: ticket.id }, include: ticketInclude });
    if (fullMessage) emitToTicket(ticket.id, "ticket:message", { ticketId: ticket.id, message: fullMessage });
    if (user.isAdmin && ticket.userId !== user.id) await createNotification({ userId: ticket.userId, type: "ticket_reply", title: "Neue Ticket-Antwort", body: ticket.title, href: `/app/support` }).catch(() => undefined);
    if (fullTicket) {
      emitToTicket(ticket.id, "ticket:updated", { ticketId: ticket.id, ticket: fullTicket });
      emitToUser(ticket.userId, "ticket:updated", { ticketId: ticket.id, ticket: fullTicket });
      emitAdminRefresh("ticket_message", { ticketId: ticket.id });
    }
    return json({ message: fullMessage, ticket: fullTicket }, 201);
  } catch (err) {
    return handleError(err);
  }
}
