import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { ticketSchema } from "@/lib/validators";
import { error, handleError, json } from "@/lib/http";
import { filesFromFormData, saveTicketAttachments } from "@/lib/ticket-uploads";
import { emitAdminRefresh, emitToAdmins, emitToTicket, emitToUser } from "@/lib/live";
import { rateLimits } from "@/lib/rate-limit";

const ticketInclude = {
  user: { select: { id: true, username: true, displayName: true, avatarColor: true } },
  messages: { orderBy: { createdAt: "asc" as const }, include: { author: { select: { id: true, displayName: true, username: true, avatarColor: true } }, attachments: { orderBy: { createdAt: "asc" as const } } } },
  attachments: { orderBy: { createdAt: "asc" as const } }
};

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);
  const tickets = await prisma.ticket.findMany({ where: user.isAdmin ? {} : { userId: user.id }, orderBy: { updatedAt: "desc" }, include: ticketInclude });
  return json({ tickets });
}

async function parseTicketRequest(request: Request) {
  const contentType = request.headers.get("content-type") || "";
  if (contentType.includes("multipart/form-data")) {
    const formData = await request.formData();
    return { body: ticketSchema.parse({ title: formData.get("title"), category: formData.get("category"), description: formData.get("description"), priority: formData.get("priority") || "NORMAL" }), files: filesFromFormData(formData) };
  }
  return { body: ticketSchema.parse(await request.json()), files: [] as File[] };
}

export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);

    const limited = await rateLimits.ticket(user.id);
    if (!limited.ok) return error("Ticket-Limit erreicht. Versuche es später erneut.", 429);

    const { body, files } = await parseTicketRequest(request);
    const ticket = await prisma.ticket.create({
      data: { userId: user.id, title: body.title, category: body.category, description: body.description, priority: body.priority, messages: { create: { authorId: user.id, content: body.description, isStaff: false } } },
      include: { messages: { orderBy: { createdAt: "asc" }, include: { attachments: true } } }
    });

    const firstMessage = ticket.messages[0];
    if (firstMessage && files.length) await saveTicketAttachments({ files, ticketId: ticket.id, messageId: firstMessage.id, uploaderId: user.id });
    const fullTicket = await prisma.ticket.findUnique({ where: { id: ticket.id }, include: ticketInclude });
    if (fullTicket) {
      emitToAdmins("ticket:created", { ticket: fullTicket });
      emitToUser(user.id, "ticket:created", { ticket: fullTicket });
      emitToTicket(fullTicket.id, "ticket:updated", { ticketId: fullTicket.id, ticket: fullTicket });
      emitAdminRefresh("ticket_created", { ticketId: fullTicket.id });
    }
    return json({ ticket: fullTicket }, 201);
  } catch (err) {
    return handleError(err);
  }
}
