import { readFile, stat } from "node:fs/promises";
import path from "node:path";
import { getCurrentUser } from "@/lib/auth";
import prisma from "@/lib/prisma";
import { contentDisposition, mimeFromName, safeResponseMime, storagePath } from "@/lib/upload-security";
import { canAccessChannel } from "@/lib/permissions";

function responseBody(buffer: Buffer): BodyInit { return buffer as unknown as BodyInit; }

function rangeResponse(file: Buffer, size: number, request: Request, type: string, fileName: string) {
  const safeType = safeResponseMime(fileName, type);
  const range = request.headers.get("range");
  const baseHeaders = {
    "content-type": safeType,
    "cache-control": "private, max-age=900",
    "accept-ranges": "bytes",
    "content-disposition": contentDisposition(fileName, safeType),
    "x-content-type-options": "nosniff"
  };
  if (!range) return new Response(responseBody(file), { headers: { ...baseHeaders, "content-length": String(size) } });
  const match = /^bytes=(\d*)-(\d*)$/.exec(range);
  if (!match) return new Response("Invalid range", { status: 416, headers: { "content-range": `bytes */${size}` } });
  let start = match[1] ? Number(match[1]) : 0;
  let end = match[2] ? Number(match[2]) : size - 1;
  if (!match[1] && match[2]) { start = Math.max(size - Number(match[2]), 0); end = size - 1; }
  if (!Number.isFinite(start) || !Number.isFinite(end) || start < 0 || end >= size || start > end) return new Response("Invalid range", { status: 416, headers: { "content-range": `bytes */${size}` } });
  const chunk = file.subarray(start, end + 1);
  return new Response(responseBody(chunk), { status: 206, headers: { ...baseHeaders, "content-length": String(chunk.length), "content-range": `bytes ${start}-${end}/${size}` } });
}

async function canReadAttachment(userId: string, attachmentId: string) {
  const attachment = await prisma.messageAttachment.findUnique({
    where: { id: attachmentId },
    include: {
      message: { select: { channelId: true, deletedAt: true, channel: { select: { serverId: true, isPrivate: true } } } },
      dmMessage: { select: { threadId: true, deletedAt: true, thread: { select: { status: true } } } }
    }
  });
  if (!attachment) return null;
  if (!attachment.messageId && !attachment.dmMessageId && attachment.uploaderId === userId) return attachment;
  if (attachment.message?.deletedAt || attachment.dmMessage?.deletedAt) return null;
  if (attachment.message?.channel) {
    return await canAccessChannel(attachment.message.channelId, userId, false, "VIEW_CHANNEL") ? attachment : null;
  }
  if (attachment.dmMessage?.threadId) {
    const dmMember = await prisma.directMessageThreadMember.findFirst({ where: { threadId: attachment.dmMessage.threadId, userId, thread: { status: "ACCEPTED" } } });
    return dmMember ? attachment : null;
  }
  return null;
}

export async function GET(request: Request, { params }: { params: { path: string[] } }) {
  const user = await getCurrentUser();
  if (!user) return new Response("Nicht eingeloggt", { status: 401 });
  const id = params.path?.[0];
  if (!id || id.includes("..") || id.includes("/") || id.includes("\\")) return new Response("Datei nicht gefunden", { status: 404 });

  const attachment = await canReadAttachment(user.id, id);
  if (!attachment) return new Response("Kein Zugriff", { status: 403 });

  try {
    const filePath = storagePath(attachment.storagePath);
    const info = await stat(filePath);
    if (!info.isFile()) return new Response("Datei nicht gefunden", { status: 404 });
    const data = await readFile(filePath);
    return rangeResponse(data, info.size, request, attachment.mimeType || mimeFromName(attachment.originalName), attachment.originalName || path.basename(filePath));
  } catch {
    return new Response("Datei nicht gefunden", { status: 404 });
  }
}
