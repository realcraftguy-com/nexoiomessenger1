import { readFile, stat } from "node:fs/promises";
import path from "node:path";
import prisma from "@/lib/prisma";
import { contentDisposition, safeResponseMime, storagePath } from "@/lib/upload-security";

function responseBody(buffer: Buffer): BodyInit { return buffer as unknown as BodyInit; }

export async function GET(_: Request, { params }: { params: { userId: string; fileName: string } }) {
  const fileName = params.fileName || "";
  if (!/^[a-f0-9-]{36}\.(png|jpg|webp)$/i.test(fileName)) return new Response("Datei nicht gefunden", { status: 404 });
  const avatarUrl = `/api/files/avatars/${params.userId}/${fileName}`;
  const owner = await prisma.user.findFirst({ where: { id: params.userId, avatarUrl }, select: { id: true } });
  if (!owner) return new Response("Datei nicht gefunden", { status: 404 });
  try {
    const relative = path.posix.join("avatars", params.userId, fileName);
    const filePath = storagePath(relative);
    const info = await stat(filePath);
    if (!info.isFile()) return new Response("Datei nicht gefunden", { status: 404 });
    const data = await readFile(filePath);
    const mime = fileName.endsWith(".webp") ? "image/webp" : fileName.endsWith(".png") ? "image/png" : "image/jpeg";
    const safeType = safeResponseMime(fileName, mime);
    return new Response(responseBody(data), { headers: { "content-type": safeType, "cache-control": "public, max-age=3600", "content-disposition": contentDisposition(fileName, safeType), "x-content-type-options": "nosniff", "content-length": String(info.size) } });
  } catch { return new Response("Datei nicht gefunden", { status: 404 }); }
}
