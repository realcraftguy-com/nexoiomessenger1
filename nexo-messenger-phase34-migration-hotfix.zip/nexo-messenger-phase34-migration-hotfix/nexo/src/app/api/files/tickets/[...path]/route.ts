import { readFile, stat } from "node:fs/promises";
import path from "node:path";
import { NextRequest } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import prisma from "@/lib/prisma";
import { contentDisposition, mimeFromName, safeResponseMime, storagePath } from "@/lib/upload-security";

function responseBody(buffer: Buffer): BodyInit { return buffer as unknown as BodyInit; }
function rangeResponse(file: Buffer, size: number, request: NextRequest, type: string, fileName: string) {
  const safeType = safeResponseMime(fileName, type);
  const range = request.headers.get("range");
  const baseHeaders = { "content-type": safeType, "cache-control": "private, max-age=900", "accept-ranges": "bytes", "content-disposition": contentDisposition(fileName, safeType), "x-content-type-options": "nosniff" };
  if (!range) return new Response(responseBody(file), { headers: { ...baseHeaders, "content-length": String(size) } });
  const match = /^bytes=(\d*)-(\d*)$/.exec(range);
  if (!match) return new Response("Invalid range", { status: 416, headers: { "content-range": `bytes */${size}` } });
  let start = match[1] ? Number(match[1]) : 0;
  let end = match[2] ? Number(match[2]) : size - 1;
  if (!match[1] && match[2]) { start = Math.max(size - Number(match[2]), 0); end = size - 1; }
  if (!Number.isFinite(start) || !Number.isFinite(end) || start < 0 || end >= size || start > end) return new Response("Invalid range", { status: 416, headers: { "content-range": `bytes */${size}` } });
  const chunk = file.subarray(start, end + 1);
  return new Response(responseBody(chunk), { status: 206, headers: { ...baseHeaders, "content-length": String(chunk.length), "content-range": `bytes ${start}-${end}/${size}` } });
}

export async function GET(request: NextRequest, { params }: { params: { path: string[] } }) {
  const user = await getCurrentUser();
  if (!user) return new Response("Nicht eingeloggt", { status: 401 });
  try {
    const segments = params.path || [];
    if (!segments.length || segments.some((segment) => !segment || segment.includes("..") || segment.includes("/") || segment.includes("\\"))) return new Response("Not found", { status: 404 });

    const attachment = await prisma.ticketAttachment.findFirst({
      where: segments.length === 1 ? { id: segments[0] } : { ticketId: segments[0], url: `/api/files/tickets/${segments.join("/")}` },
      include: { ticket: { select: { userId: true } } }
    });
    if (!attachment) return new Response("Not found", { status: 404 });
    if (attachment.ticket.userId !== user.id && !user.isAdmin) return new Response("Kein Zugriff", { status: 403 });

    if (!attachment.storagePath) return new Response("Legacy-Datei muss erst migriert werden", { status: 410 });
    const filePath = storagePath(attachment.storagePath);
    const info = await stat(filePath);
    if (!info.isFile()) return new Response("Not found", { status: 404 });
    const file = await readFile(filePath);
    const fileName = attachment.originalName || attachment.name || segments.at(-1) || "datei";
    return rangeResponse(file, info.size, request, attachment.mimeType || mimeFromName(fileName), fileName);
  } catch {
    return new Response("Not found", { status: 404 });
  }
}
