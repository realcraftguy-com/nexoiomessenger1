import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, json } from "@/lib/http";

export async function GET(_: Request, { params }: { params: { userId: string } }) {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);
  if (params.userId === user.id) return json({ self: true, friend: false, outgoingRequest: null, incomingRequest: null, blockedByMe: false, blockedMe: false });
  const [friendship, outgoingRequest, incomingRequest, blockedByMe, blockedMe] = await Promise.all([
    prisma.friendship.findFirst({ where: { OR: [{ userAId: user.id, userBId: params.userId }, { userAId: params.userId, userBId: user.id }] } }),
    prisma.friendRequest.findFirst({ where: { senderId: user.id, receiverId: params.userId, status: "pending" } }),
    prisma.friendRequest.findFirst({ where: { senderId: params.userId, receiverId: user.id, status: "pending" } }),
    prisma.blockedUser.findUnique({ where: { blockerId_blockedId: { blockerId: user.id, blockedId: params.userId } } }),
    prisma.blockedUser.findUnique({ where: { blockerId_blockedId: { blockerId: params.userId, blockedId: user.id } } })
  ]);
  return json({ self: false, friend: Boolean(friendship), friendship, outgoingRequest, incomingRequest, blockedByMe: Boolean(blockedByMe), blockedMe: Boolean(blockedMe) });
}
