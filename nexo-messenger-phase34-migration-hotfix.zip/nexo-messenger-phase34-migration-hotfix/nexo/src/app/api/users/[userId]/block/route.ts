import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { emitToUser, emitToDmMembers } from "@/lib/live";

async function affectedDmThreadIds(userAId: string, userBId: string) {
  const memberships = await prisma.directMessageThreadMember.findMany({ where: { userId: userAId }, select: { threadId: true } });
  const ids = memberships.map((item: { threadId: string }) => item.threadId);
  if (!ids.length) return [] as string[];
  const shared = await prisma.directMessageThreadMember.findMany({ where: { userId: userBId, threadId: { in: ids } }, select: { threadId: true } });
  return shared.map((item: { threadId: string }) => item.threadId);
}

async function emitBlockChange(blockerId: string, blockedId: string, blocked: boolean) {
  emitToUser(blockerId, "user:block:changed", { userId: blockedId, blockedByMe: blocked });
  emitToUser(blockedId, "user:block:changed", { userId: blockerId, blockedMe: blocked });
  const reason = blocked ? "Eine Person in diesem DM hat die andere blockiert." : "Blockierung aufgehoben.";
  for (const threadId of await affectedDmThreadIds(blockerId, blockedId)) {
    await emitToDmMembers(threadId, "dm:safety:changed", { threadId, blocked, reason });
  }
}

export async function POST(_: Request, { params }: { params: { userId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    if (params.userId === user.id) return error("Du kannst dich nicht selbst blockieren.", 400);
    const target = await prisma.user.findUnique({ where: { id: params.userId }, select: { id: true } });
    if (!target) return error("User nicht gefunden", 404);
    await prisma.blockedUser.upsert({ where: { blockerId_blockedId: { blockerId: user.id, blockedId: params.userId } }, create: { blockerId: user.id, blockedId: params.userId }, update: {} });
    await emitBlockChange(user.id, params.userId, true);
    return json({ ok: true });
  } catch (err) { return handleError(err); }
}

export async function DELETE(_: Request, { params }: { params: { userId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    await prisma.blockedUser.deleteMany({ where: { blockerId: user.id, blockedId: params.userId } });
    await emitBlockChange(user.id, params.userId, false);
    return json({ ok: true });
  } catch (err) { return handleError(err); }
}
