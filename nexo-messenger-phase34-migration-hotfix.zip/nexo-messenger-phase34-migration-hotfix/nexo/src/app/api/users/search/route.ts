import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, json } from "@/lib/http";

export async function GET(request: Request) {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);

  const q = new URL(request.url).searchParams.get("q")?.trim() || "";
  if (q.length < 2) return json({ users: [] });

  const users = await prisma.user.findMany({
    where: {
      AND: [
        { id: { not: user.id } },
        { isBanned: false },
        { OR: [{ username: { contains: q } }, { displayName: { contains: q } }] }
      ]
    },
    take: 12,
    select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true, status: true }
  });

  return json({ users });
}
