import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, json } from "@/lib/http";

const userSelect = { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true, status: true } as const;

type BlockedUserRow = {
  id: string;
  blockerId: string;
  blockedId: string;
  createdAt: Date;
};

type BlockedPublicUser = {
  id: string;
  username: string;
  displayName: string;
  avatarUrl: string | null;
  avatarColor: string;
  status: string;
};

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);
  const blocks: BlockedUserRow[] = await prisma.blockedUser.findMany({ where: { blockerId: user.id }, orderBy: { createdAt: "desc" } });
  const ids = blocks.map((item) => item.blockedId);
  const users: BlockedPublicUser[] = ids.length ? await prisma.user.findMany({ where: { id: { in: ids } }, select: userSelect }) : [];
  const userMap = new Map(users.map((item) => [item.id, item]));
  return json({ blocks: blocks.map((item) => ({ ...item, user: userMap.get(item.blockedId) || null })) });
}
