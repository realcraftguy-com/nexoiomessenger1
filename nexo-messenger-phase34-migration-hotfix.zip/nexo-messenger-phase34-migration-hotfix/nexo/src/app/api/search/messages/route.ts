import prisma from "@/lib/prisma";
import type { Prisma } from "@prisma/client";
import { getCurrentUser } from "@/lib/auth";
import { error, json } from "@/lib/http";
import { canAccessChannel, filterVisibleChannelsForUser } from "@/lib/permissions";
import { normalizeMessageForClient } from "@/lib/message-uploads";

const userSelect = { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } as const;
const fileOrder = { createdAt: "asc" } as const;

type SearchChannelMessage = Prisma.MessageGetPayload<{
  include: { author: { select: typeof userSelect }; fileAttachments: { orderBy: typeof fileOrder } };
}>;

type SearchDmMessage = Prisma.DirectMessageGetPayload<{
  include: { author: { select: typeof userSelect }; fileAttachments: { orderBy: typeof fileOrder } };
}>;

type ServerMembershipId = { serverId: string };
type ChannelIdOnly = { id: string };

export async function GET(request: Request) {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);
  const search = new URL(request.url).searchParams;
  const q = String(search.get("q") || "").trim();
  const channelId = search.get("channelId");
  const threadId = search.get("threadId");
  if (q.length < 2) return json({ results: [] });

  if (channelId) {
    if (!(await canAccessChannel(channelId, user.id, user.isAdmin, "VIEW_CHANNEL"))) return error("Kein Zugriff", 403);
    const messages = await prisma.message.findMany({
      where: { channelId, deletedAt: null, content: { contains: q, mode: "insensitive" } },
      orderBy: { createdAt: "desc" },
      take: 25,
      include: { author: { select: userSelect }, fileAttachments: { orderBy: fileOrder } }
    });
    return json({ results: messages.map((message: SearchChannelMessage) => ({ type: "channel", message: normalizeMessageForClient(message) })) });
  }

  if (threadId) {
    const member = await prisma.directMessageThreadMember.findFirst({ where: { threadId, userId: user.id, thread: { status: "ACCEPTED" } } });
    if (!member) return error("Kein Zugriff", 403);
    const messages = await prisma.directMessage.findMany({
      where: { threadId, deletedAt: null, content: { contains: q, mode: "insensitive" } },
      orderBy: { createdAt: "desc" },
      take: 25,
      include: { author: { select: userSelect }, fileAttachments: { orderBy: fileOrder } }
    });
    return json({ results: messages.map((message: SearchDmMessage) => ({ type: "dm", message: normalizeMessageForClient(message) })) });
  }

  const memberships = await prisma.serverMember.findMany({ where: { userId: user.id }, select: { serverId: true } });
  const channels = await prisma.channel.findMany({ where: { serverId: { in: memberships.map((item: ServerMembershipId) => item.serverId) } }, select: { id: true } });
  const visible = await filterVisibleChannelsForUser(channels, user);
  const channelMessages = await prisma.message.findMany({
    where: { channelId: { in: visible.map((channel) => channel.id) }, deletedAt: null, content: { contains: q, mode: "insensitive" } },
    orderBy: { createdAt: "desc" },
    take: 25,
    include: { author: { select: userSelect }, fileAttachments: { orderBy: fileOrder } }
  });
  return json({ results: channelMessages.map((message: SearchChannelMessage) => ({ type: "channel", message: normalizeMessageForClient(message) })) });
}
