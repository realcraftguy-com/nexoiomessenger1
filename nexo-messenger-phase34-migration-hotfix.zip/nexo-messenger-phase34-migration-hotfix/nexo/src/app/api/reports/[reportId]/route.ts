import { z } from "zod";
import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { emitAdminRefresh, emitToAdmins } from "@/lib/live";

const statusSchema = z.object({
  status: z.enum(["open", "reviewing", "resolved", "rejected"]).optional(),
  note: z.string().max(1000).optional(),
  action: z.enum(["delete_message"]).optional()
});

async function loadReport(reportId: string) {
  return prisma.report.findUnique({
    where: { id: reportId },
    include: { notes: { orderBy: { createdAt: "desc" }, include: { admin: { select: { id: true, username: true, displayName: true } } } } }
  });
}

export async function PATCH(request: Request, { params }: { params: { reportId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    if (!user.isAdmin) return error("Nur Admin", 403);
    const body = statusSchema.parse(await request.json());
    const existing = await prisma.report.findUnique({ where: { id: params.reportId } });
    if (!existing) return error("Report nicht gefunden", 404);

    let report = existing;
    if (body.status) report = await prisma.report.update({ where: { id: params.reportId }, data: { status: body.status } });

    if (body.action === "delete_message") {
      if (existing.messageId) await prisma.message.update({ where: { id: existing.messageId }, data: { deletedAt: new Date(), content: "", attachments: "[]" } }).catch(() => undefined);
      if (existing.dmMessageId) await prisma.directMessage.update({ where: { id: existing.dmMessageId }, data: { deletedAt: new Date(), content: "", attachments: "[]" } }).catch(() => undefined);
    }

    const cleanNote = String(body.note || "").trim();
    let note = null;
    if (cleanNote) {
      note = await prisma.reportNote.create({
        data: { reportId: report.id, adminId: user.id, note: cleanNote },
        include: { admin: { select: { id: true, username: true, displayName: true } } }
      });
    }
    await prisma.auditLog.create({ data: { action: "REPORT_UPDATED", actorId: user.id, targetId: report.id, meta: JSON.stringify({ status: body.status, action: body.action, noteId: note?.id }) } }).catch(() => undefined);
    const fullReport = await loadReport(report.id);
    emitToAdmins("admin:report:updated", { report: fullReport || report });
    emitAdminRefresh("report_updated", { reportId: report.id, status: report.status, action: body.action });
    return json({ report: fullReport || report, note });
  } catch (err) { return handleError(err); }
}
