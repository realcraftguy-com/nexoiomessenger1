import { z } from "zod";
import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { canAccessChannel } from "@/lib/permissions";
import { emitAdminRefresh, emitToAdmins } from "@/lib/live";

const reportSchema = z.object({
  targetUserId: z.string().uuid().optional(),
  messageId: z.string().uuid().optional(),
  dmMessageId: z.string().uuid().optional(),
  serverId: z.string().uuid().optional(),
  reason: z.string().min(5).max(800)
});

export async function POST(request: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    const body = reportSchema.parse(await request.json());
    if (!body.targetUserId && !body.messageId && !body.dmMessageId) return error("Bitte wähle Nachricht oder User aus.", 400);

    if (body.messageId) {
      const message = await prisma.message.findUnique({ where: { id: body.messageId }, select: { channelId: true, channel: { select: { serverId: true } } } });
      if (!message || !(await canAccessChannel(message.channelId, user.id, user.isAdmin, "VIEW_CHANNEL"))) return error("Nachricht nicht gefunden", 404);
      body.serverId = message.channel.serverId;
    }
    if (body.dmMessageId) {
      const message = await prisma.directMessage.findUnique({ where: { id: body.dmMessageId }, select: { threadId: true } });
      if (!message) return error("Nachricht nicht gefunden", 404);
      const member = await prisma.directMessageThreadMember.findFirst({ where: { threadId: message.threadId, userId: user.id } });
      if (!member) return error("Nachricht nicht gefunden", 404);
    }

    const report = await prisma.report.create({ data: { reporterId: user.id, targetUserId: body.targetUserId || null, messageId: body.messageId || null, dmMessageId: body.dmMessageId || null, serverId: body.serverId || null, reason: body.reason } });
    emitToAdmins("admin:report:new", { report });
    emitAdminRefresh("report_created", { reportId: report.id });
    return json({ report }, 201);
  } catch (err) { return handleError(err); }
}

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);
  if (!user.isAdmin) return error("Nur Admin", 403);
  const reports = await prisma.report.findMany({ orderBy: { createdAt: "desc" }, take: 80 });
  return json({ reports });
}
