import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { messageSchema } from "@/lib/validators";
import { error, handleError, json } from "@/lib/http";
import { emitToDmMembers } from "@/lib/live";
import { normalizeMessageForClient } from "@/lib/message-uploads";

async function canAccessDmMessage(messageId: string, userId: string) {
  const message = await prisma.directMessage.findUnique({
    where: { id: messageId },
    include: { thread: { include: { members: true } } }
  });
  if (!message || message.deletedAt) return null;
  if (message.thread.status !== "ACCEPTED") return null;
  if (!message.thread.members.some((member: { userId: string }) => member.userId === userId)) return null;
  return message;
}

export async function PATCH(request: Request, { params }: { params: { messageId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    const message = await canAccessDmMessage(params.messageId, user.id);
    if (!message) return error("Nachricht nicht gefunden", 404);
    if (message.authorId !== user.id) return error("Nur eigene DM-Nachrichten können bearbeitet werden", 403);
    const body = messageSchema.parse(await request.json());
    const updated = await prisma.directMessage.update({
      where: { id: message.id },
      data: { content: body.content.trim(), editedAt: new Date() },
      include: {
        author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } },
        fileAttachments: { orderBy: { createdAt: "asc" } },
        replyTo: { select: { id: true, content: true, deletedAt: true, author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } } } }
      }
    });
    const normalized = normalizeMessageForClient(updated);
    await emitToDmMembers(message.threadId, "dm:message:updated", { threadId: message.threadId, message: normalized });
    return json({ message: normalized });
  } catch (err) {
    return handleError(err);
  }
}

export async function DELETE(_: Request, { params }: { params: { messageId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    const message = await canAccessDmMessage(params.messageId, user.id);
    if (!message) return error("Nachricht nicht gefunden", 404);
    if (message.authorId !== user.id && !user.isAdmin) return error("Keine Berechtigung", 403);
    await prisma.directMessage.update({ where: { id: message.id }, data: { deletedAt: new Date(), content: "", attachments: "[]" } });
    await emitToDmMembers(message.threadId, "dm:message:deleted", { messageId: message.id, threadId: message.threadId });
    return json({ ok: true });
  } catch (err) {
    return handleError(err);
  }
}
