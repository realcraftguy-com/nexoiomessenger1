import { access, mkdir, readdir, stat, writeFile, unlink } from "node:fs/promises";
import path from "node:path";
import prisma from "@/lib/prisma";
import { json } from "@/lib/http";
import { storageRoot } from "@/lib/env";
import { redisPing } from "@/lib/redis";

async function checkDatabase() {
  try { await prisma.$queryRaw`SELECT 1`; return "ok"; } catch { return "error"; }
}

async function checkRedis() {
  try { await redisPing(); return "ok"; } catch { return "error"; }
}

async function storageUsageBytes(dir = storageRoot): Promise<number> {
  try {
    const entries = await readdir(dir, { withFileTypes: true });
    const sizes = await Promise.all(entries.map(async (entry) => {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) return storageUsageBytes(full);
      const info = await stat(full).catch(() => null);
      return info?.size || 0;
    }));
    return sizes.reduce((sum, size) => sum + size, 0);
  } catch { return 0; }
}

async function checkStorage() {
  try {
    await mkdir(storageRoot, { recursive: true });
    const file = path.join(storageRoot, `.health-${Date.now()}`);
    await writeFile(file, "ok");
    await access(file);
    await unlink(file).catch(() => undefined);
    return "ok";
  } catch { return "error"; }
}

export async function GET() {
  const [database, redis, storage] = await Promise.all([checkDatabase(), checkRedis(), checkStorage()]);
  const ok = database === "ok" && redis === "ok" && storage === "ok";
  const storageBytes = await storageUsageBytes();
  return json({ ok, database, redis, storage, storageBytes, version: "phase-34" }, ok ? 200 : 503);
}
