import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { messageSchema } from "@/lib/validators";
import { error, handleError, json } from "@/lib/http";
import { emitAdminRefresh, emitChannelEvent } from "@/lib/live";
import { canAccessChannel } from "@/lib/permissions";
import { normalizeMessageForClient } from "@/lib/message-uploads";

async function getEditableMessage(messageId: string, userId: string, isAdmin: boolean) {
  const message = await prisma.message.findUnique({ where: { id: messageId }, include: { channel: true } });
  if (!message) return null;
  const channel = await canAccessChannel(message.channelId, userId, isAdmin, "VIEW_CHANNEL");
  if (!channel) return null;
  const canManage = Boolean(await canAccessChannel(message.channelId, userId, isAdmin, "MANAGE_MESSAGES"));
  if (message.authorId !== userId && !canManage) return null;
  return message;
}

export async function PATCH(request: Request, { params }: { params: { messageId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);
    const message = await getEditableMessage(params.messageId, user.id, user.isAdmin);
    if (!message) return error("Keine Berechtigung", 403);
    if (message.authorId !== user.id) return error("Nur eigene Nachrichten können bearbeitet werden", 403);
    const body = messageSchema.parse(await request.json());
    const updated = await prisma.message.update({ where: { id: params.messageId }, data: { content: body.content, editedAt: new Date() }, include: { author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } }, fileAttachments: { orderBy: { createdAt: "asc" } } } });
    await emitChannelEvent(message.channelId, "channel:message:updated", { message: normalizeMessageForClient(updated), channelId: message.channelId });
    return json({ message: normalizeMessageForClient(updated) });
  } catch (err) { return handleError(err); }
}

export async function DELETE(_: Request, { params }: { params: { messageId: string } }) {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);
  const message = await getEditableMessage(params.messageId, user.id, user.isAdmin);
  if (!message) return error("Keine Berechtigung", 403);
  await prisma.message.update({ where: { id: params.messageId }, data: { deletedAt: new Date(), content: "", attachments: "[]" } });
  await prisma.auditLog.create({ data: { action: "MESSAGE_DELETED", actorId: user.id, serverId: message.channel.serverId, targetId: message.id } });
  await emitChannelEvent(message.channelId, "channel:message:deleted", { messageId: message.id, channelId: message.channelId });
  emitAdminRefresh("message_deleted", { serverId: message.channel.serverId, messageId: message.id });
  return json({ ok: true });
}
