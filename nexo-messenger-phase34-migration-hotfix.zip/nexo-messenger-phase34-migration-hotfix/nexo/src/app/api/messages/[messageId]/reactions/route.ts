import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { canAccessChannel } from "@/lib/permissions";
import { error, json } from "@/lib/http";

function parseReactions(
  raw: string | null | undefined,
): Record<string, string[]> {
  try {
    const parsed: unknown = JSON.parse(raw || "{}");
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed))
      return parsed as Record<string, string[]>;
  } catch {}
  return {};
}

export async function GET(
  request: Request,
  { params }: { params: { messageId: string } },
) {
  const user = await getCurrentUser();
  if (!user) return error("Nicht eingeloggt", 401);
  const emoji = new URL(request.url).searchParams.get("emoji") || "";
  if (!emoji) return json({ users: [] });

  const channelMessage = await prisma.message.findUnique({
    where: { id: params.messageId },
    select: { channelId: true, reactions: true },
  });
  if (channelMessage) {
    const allowed = await canAccessChannel(
      channelMessage.channelId,
      user.id,
      user.isAdmin,
      "VIEW_CHANNEL",
    );
    if (!allowed) return error("Nachricht nicht gefunden", 404);
    const ids = parseReactions(channelMessage.reactions)[emoji] || [];
    const users = ids.length
      ? await prisma.user.findMany({
          where: { id: { in: ids } },
          select: {
            id: true,
            username: true,
            displayName: true,
            avatarUrl: true,
            avatarColor: true,
          },
        })
      : [];
    const sorted = ids
      .map((id: string) => users.find((item: { id: string }) => item.id === id))
      .filter(Boolean);
    return json({ users: sorted });
  }

  const dmMessage = await prisma.directMessage.findUnique({
    where: { id: params.messageId },
    select: { threadId: true, reactions: true },
  });
  if (!dmMessage) return error("Nachricht nicht gefunden", 404);
  const member = await prisma.directMessageThreadMember.findFirst({
    where: { threadId: dmMessage.threadId, userId: user.id },
    select: { userId: true },
  });
  if (!member) return error("Nachricht nicht gefunden", 404);
  const ids = parseReactions(dmMessage.reactions)[emoji] || [];
  const users = ids.length
    ? await prisma.user.findMany({
        where: { id: { in: ids } },
        select: {
          id: true,
          username: true,
          displayName: true,
          avatarUrl: true,
          avatarColor: true,
        },
      })
    : [];
  const sorted = ids
    .map((id: string) => users.find((item: { id: string }) => item.id === id))
    .filter(Boolean);
  return json({ users: sorted });
}
