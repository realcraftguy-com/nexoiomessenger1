import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { error, handleError, json } from "@/lib/http";
import { canAccessChannel } from "@/lib/permissions";
import { emitChannelEvent, emitToDmMembers } from "@/lib/live";

async function findChannelMessage(messageId: string) {
  return prisma.message.findUnique({ where: { id: messageId }, include: { channel: true } });
}

async function findDmMessage(messageId: string) {
  return prisma.directMessage.findUnique({ where: { id: messageId }, include: { thread: { include: { members: true } } } });
}

function isDmParticipant(message: NonNullable<Awaited<ReturnType<typeof findDmMessage>>>, userId: string) {
  return message.thread.status === "ACCEPTED" && message.thread.members.some((member: { userId: string }) => member.userId === userId);
}

export async function POST(_: Request, { params }: { params: { messageId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);

    const message = await findChannelMessage(params.messageId);
    if (message) {
      const channel = await canAccessChannel(message.channelId, user.id, user.isAdmin, "MANAGE_MESSAGES");
      if (!channel) return error("Keine Berechtigung", 403);
      const existing = await prisma.pinnedMessage.findFirst({ where: { messageId: message.id } });
      const pin = existing || await prisma.pinnedMessage.create({ data: { channelId: message.channelId, messageId: message.id, pinnedById: user.id } });
      const count = await prisma.pinnedMessage.count({ where: { channelId: message.channelId } });
      await prisma.auditLog.create({ data: { action: "MESSAGE_PINNED", actorId: user.id, serverId: message.channel.serverId, targetId: message.id } }).catch(() => undefined);
      await emitChannelEvent(message.channelId, "channel:pins:changed", { channelId: message.channelId, count });
      return json({ pin, count, alreadyPinned: Boolean(existing) }, existing ? 200 : 201);
    }

    const dmMessage = await findDmMessage(params.messageId);
    if (!dmMessage) return error("Nachricht nicht gefunden", 404);
    if (!isDmParticipant(dmMessage, user.id)) return error("Keine Berechtigung", 403);
    const existing = await prisma.pinnedMessage.findFirst({ where: { dmMessageId: dmMessage.id } });
    const pin = existing || await prisma.pinnedMessage.create({ data: { dmThreadId: dmMessage.threadId, dmMessageId: dmMessage.id, pinnedById: user.id } });
    const count = await prisma.pinnedMessage.count({ where: { dmThreadId: dmMessage.threadId } });
    await emitToDmMembers(dmMessage.threadId, "dm:pins:changed", { threadId: dmMessage.threadId, count });
    return json({ pin, count, alreadyPinned: Boolean(existing) }, existing ? 200 : 201);
  } catch (err) { return handleError(err); }
}

export async function DELETE(_: Request, { params }: { params: { messageId: string } }) {
  try {
    const user = await getCurrentUser();
    if (!user) return error("Nicht eingeloggt", 401);

    const message = await findChannelMessage(params.messageId);
    if (message) {
      if (!(await canAccessChannel(message.channelId, user.id, user.isAdmin, "MANAGE_MESSAGES"))) return error("Keine Berechtigung", 403);
      await prisma.pinnedMessage.deleteMany({ where: { messageId: message.id } });
      const count = await prisma.pinnedMessage.count({ where: { channelId: message.channelId } });
      await prisma.auditLog.create({ data: { action: "MESSAGE_UNPINNED", actorId: user.id, serverId: message.channel.serverId, targetId: message.id } }).catch(() => undefined);
      await emitChannelEvent(message.channelId, "channel:pins:changed", { channelId: message.channelId, count });
      return json({ ok: true, count });
    }

    const dmMessage = await findDmMessage(params.messageId);
    if (!dmMessage) return error("Nachricht nicht gefunden", 404);
    if (!isDmParticipant(dmMessage, user.id)) return error("Keine Berechtigung", 403);
    await prisma.pinnedMessage.deleteMany({ where: { dmMessageId: dmMessage.id } });
    const count = await prisma.pinnedMessage.count({ where: { dmThreadId: dmMessage.threadId } });
    await emitToDmMembers(dmMessage.threadId, "dm:pins:changed", { threadId: dmMessage.threadId, count });
    return json({ ok: true, count });
  } catch (err) { return handleError(err); }
}
