declare module "@emoji-mart/data" {
  const data: unknown;
  export default data;
}

declare module "@emoji-mart/react" {
  import type { ComponentType } from "react";
  const Picker: ComponentType<any>;
  export default Picker;
}
