export type ApiUserSummary = {
  id: string;
  username: string;
  displayName: string;
  avatarUrl?: string | null;
  avatarColor?: string | null;
  status?: string | null;
};

export type ApiReportNote = {
  id: string;
  note: string;
  createdAt: string | Date;
  admin?: Pick<ApiUserSummary, "id" | "username" | "displayName"> | null;
};

export type ApiReportStatus = "open" | "reviewing" | "resolved" | "rejected";

export type ApiReport = {
  id: string;
  reason: string;
  status: ApiReportStatus;
  createdAt: string | Date;
  reporter?: ApiUserSummary | null;
  targetUser?: ApiUserSummary | null;
  message?: { id: string; content?: string | null; deletedAt?: string | Date | null } | null;
  notes?: ApiReportNote[];
  server?: { id: string; name: string } | null;
  channel?: { id: string; name: string } | null;
};

export type ApiInvite = {
  id: string;
  code: string;
  uses: number;
  maxUses?: number | null;
  expiresAt?: string | Date | null;
  disabledAt?: string | Date | null;
  channel?: { id: string; name: string; type: string } | null;
  createdBy?: Pick<ApiUserSummary, "id" | "username" | "displayName"> | null;
  url?: string;
};

export type ApiNotificationBadge = {
  unread: number;
  dmUnread: number;
  mentionUnread: number;
  friendRequestUnread: number;
  reportUnread: number;
  totalBadge: number;
};
