import { NextResponse, type NextRequest } from "next/server";
import { jwtVerify } from "jose";
import { getJwtSecret, isAdminEmail } from "./lib/env";
import { verifyOrigin } from "./lib/security/origin";

function secret() {
  return new TextEncoder().encode(getJwtSecret());
}

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  if (pathname.startsWith("/api/")) {
    const origin = verifyOrigin({
      method: request.method,
      origin: request.headers.get("origin"),
      referer: request.headers.get("referer"),
      host: request.headers.get("host")
    });
    if (!origin.ok) return NextResponse.json({ error: "CSRF/Origin-Schutz: Anfrage blockiert." }, { status: 403 });
    return NextResponse.next();
  }

  const token = request.cookies.get("nexo_token")?.value;
  const protectedPath = pathname.startsWith("/app") || pathname.startsWith("/admin") || pathname.startsWith("/onboarding");

  if (!protectedPath) return NextResponse.next();

  if (!token) {
    const url = new URL("/login", request.url);
    url.searchParams.set("next", pathname);
    return NextResponse.redirect(url);
  }

  try {
    const result = await jwtVerify(token, secret());
    const email = String(result.payload.email || "");
    if ((pathname.startsWith("/app/admin") || pathname.startsWith("/admin")) && !isAdminEmail(email)) {
      return NextResponse.redirect(new URL("/app", request.url));
    }
    return NextResponse.next();
  } catch {
    return NextResponse.redirect(new URL("/login", request.url));
  }
}

export const config = {
  matcher: ["/app/:path*", "/admin/:path*", "/onboarding", "/api/:path*"]
};
