"use client";

import Link from "next/link";
import { FormEvent, ReactNode, useEffect, useMemo, useRef, useState } from "react";
import { io, Socket } from "socket.io-client";
import {
  Activity,
  AlertTriangle,
  ArrowLeft,
  Ban,
  Bell,
  BookOpen,
  Bot,
  ChevronRight,
  Hash,
  ImagePlus,
  KeyRound,
  Link2,
  Lock,
  Megaphone,
  Pencil,
  Plus,
  Radio,
  Save,
  Search,
  Shield,
  SlidersHorizontal,
  Trash2,
  UserMinus,
  Users,
  Volume2,
  type LucideIcon
} from "lucide-react";
import clsx from "clsx";
import { Avatar } from "@/components/ui/Avatar";
import { CustomSelect } from "@/components/ui/CustomSelect";
import { Modal } from "@/components/ui/Modal";
import { Notice } from "@/components/ui/Notice";
import type { ApiInvite } from "@/types/app";

const permissions = [
  { id: "VIEW_CHANNEL", label: "Channels sehen", description: "Kann öffentliche Channels öffnen." },
  { id: "SEND_MESSAGES", label: "Nachrichten senden", description: "Kann in Textchannels schreiben." },
  { id: "MANAGE_MESSAGES", label: "Nachrichten moderieren", description: "Kann Nachrichten löschen und Inhalte prüfen." },
  { id: "MANAGE_CHANNELS", label: "Channels verwalten", description: "Kann Channels und Kategorien erstellen." },
  { id: "MANAGE_ROLES", label: "Rollen verwalten", description: "Kann Rollen erstellen und bearbeiten." },
  { id: "KICK_MEMBERS", label: "Mitglieder kicken", description: "Kann Mitglieder aus dem Server entfernen." },
  { id: "BAN_MEMBERS", label: "Mitglieder bannen", description: "Kann Mitglieder serverweit sperren. Gefährlich." },
  { id: "CREATE_INVITES", label: "Einladungen erstellen", description: "Kann Invite-Links erzeugen." },
  { id: "VIEW_AUDIT_LOG", label: "Audit-Log ansehen", description: "Kann Verwaltungsaktionen sehen." },
  { id: "MANAGE_SERVER", label: "Server verwalten", description: "Kann Profileinstellungen ändern. Gefährlich." },
  { id: "UPLOAD_FILES", label: "Dateien senden", description: "Kann Dateien und Medien hochladen." },
  { id: "MENTION_EVERYONE", label: "@everyone erwähnen", description: "Kann alle sichtbaren Mitglieder benachrichtigen. Gefährlich." },
  { id: "MANAGE_TICKETS", label: "Tickets verwalten", description: "Kann Support-Tickets moderieren." }
];

const dangerousPermissions = new Set(["MANAGE_SERVER", "MANAGE_ROLES", "BAN_MEMBERS", "VIEW_AUDIT_LOG"]);
const permissionGroups = [
  { label: "Allgemein", ids: ["VIEW_CHANNEL", "CREATE_INVITES", "MENTION_EVERYONE"] },
  { label: "Channels", ids: ["MANAGE_CHANNELS"] },
  { label: "Nachrichten", ids: ["SEND_MESSAGES", "UPLOAD_FILES", "MANAGE_MESSAGES"] },
  { label: "Moderation", ids: ["KICK_MEMBERS", "BAN_MEMBERS", "VIEW_AUDIT_LOG"] },
  { label: "Tickets", ids: ["MANAGE_TICKETS"] },
  { label: "Admin", ids: ["MANAGE_SERVER", "MANAGE_ROLES"] }
] as const;
const privateChannelPermissions = ["VIEW_CHANNEL", "SEND_MESSAGES", "UPLOAD_FILES", "MANAGE_MESSAGES"] as const;
function permissionMeta(id: string) { return permissions.find((permission) => permission.id === id) || { id, label: id, description: "" }; }


type IconComponent = LucideIcon;
type RoleRow = { id: string; name: string; color: string; permissions: string; position?: number | null };
type UserSummary = { id: string; username: string; displayName: string; avatarUrl?: string | null; avatarColor?: string | null; status?: string | null };
type RoleAssignmentRow = { roleId: string; role: RoleRow };
type MemberRow = { id: string; userId?: string; nickname?: string | null; isOwner?: boolean; isAdmin?: boolean; user: UserSummary; roleAssignments?: RoleAssignmentRow[] };
type InviteRow = ApiInvite;
type AuditLogRow = { id: string; action: string; meta?: string | null; createdAt: string | Date; actor?: { username?: string | null; displayName?: string | null } | null };
type ChannelOverride = { roleId: string | null; memberId: string | null; allow: string[]; deny: string[] };
type ChannelRow = { id: string; name: string; type: string; categoryId?: string | null; isPrivate: boolean; permissionOverrides?: ChannelOverride[] };
type CategoryRow = { id: string; name: string; channels?: ChannelRow[] };
type ServerSettingsState = { id: string; name: string; iconUrl?: string | null; isPrivate: boolean; channels?: ChannelRow[]; categories?: CategoryRow[]; roles?: RoleRow[]; members?: MemberRow[]; invites?: InviteRow[]; auditLogs?: AuditLogRow[] };
type MemberUpdatePayload = { isAdmin?: boolean; nickname?: string | null; roleIds?: string[] };

type NavId =
  | "profile"
  | "overview"
  | "invites"
  | "channels"
  | "categories"
  | "members"
  | "roles"
  | "access"
  | "bans"
  | "emoji"
  | "soundboard"
  | "apps"
  | "safety"
  | "audit"
  | "voice"
  | "notifications"
  | "danger";

type SettingsNavItem = {
  id: NavId;
  label: string;
  icon: IconComponent;
  danger?: boolean;
};

type SettingsNavGroup = {
  group: string;
  items: SettingsNavItem[];
};

const nav: SettingsNavGroup[] = [
  { group: "Server", items: [
    { id: "profile", label: "Serverprofil", icon: ImagePlus },
    { id: "overview", label: "Übersicht", icon: SlidersHorizontal },
    { id: "invites", label: "Einladungen", icon: Link2 },
    { id: "channels", label: "Channels", icon: Hash },
    { id: "categories", label: "Kategorien", icon: BookOpen }
  ] },
  { group: "Personen", items: [
    { id: "members", label: "Mitglieder", icon: Users },
    { id: "roles", label: "Rollen", icon: Shield },
    { id: "access", label: "Zugriff", icon: KeyRound },
    { id: "bans", label: "Gebannte Mitglieder", icon: Ban }
  ] },
  { group: "Ausdruck", items: [
    { id: "emoji", label: "Emoji", icon: Megaphone },
    { id: "soundboard", label: "Soundboard", icon: Volume2 },
    { id: "apps", label: "Integrationen", icon: Bot }
  ] },
  { group: "Moderation", items: [
    { id: "safety", label: "Sicherheit", icon: Lock },
    { id: "audit", label: "Audit-Log", icon: Activity },
    { id: "voice", label: "Sprachbereiche", icon: Radio },
    { id: "notifications", label: "Benachrichtigungen", icon: Bell },
    { id: "danger", label: "Server löschen", icon: Trash2, danger: true }
  ] }
];

function parsePermissions(value: string) {
  try { const parsed = JSON.parse(value || "[]"); return Array.isArray(parsed) ? parsed : []; } catch { return []; }
}

function SectionCard({ title, description, children, icon: Icon }: { title: string; description?: string; children: ReactNode; icon?: IconComponent }) {
  return (
    <section className="rounded-[2rem] border border-white/10 bg-white/[.035] p-5 shadow-2xl shadow-black/20">
      <div className="mb-5 flex items-start gap-3">
        {Icon && <span className="grid size-10 place-items-center rounded-2xl border border-white/10 bg-white/[.05] text-zinc-200"><Icon size={18} /></span>}
        <div><h3 className="text-lg font-semibold tracking-[-.03em] text-white">{title}</h3>{description && <p className="mt-1 text-sm leading-6 text-zinc-500">{description}</p>}</div>
      </div>
      {children}
    </section>
  );
}

function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return <label className="block space-y-2"><span className="label">{label}</span>{children}{hint && <span className="block text-xs text-zinc-500">{hint}</span>}</label>;
}

function AuditText({ log }: { log: AuditLogRow }) {
  let meta: { name?: string; title?: string } = {};
  try { meta = JSON.parse(log.meta || "{}"); } catch {}
  return <span>{log.action.replaceAll("_", " ").toLowerCase()} {meta?.name || meta?.title ? <b className="text-zinc-300">· {meta.name || meta.title}</b> : null}</span>;
}

export function ServerSettingsClient({ serverId }: { serverId: string }) {
  const [server, setServer] = useState<ServerSettingsState | null>(null);
  const [active, setActive] = useState<NavId>("profile");
  const [query, setQuery] = useState("");
  const [notice, setNotice] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [saving, setSaving] = useState(false);
  const [categoryName, setCategoryName] = useState("");
  const [channelName, setChannelName] = useState("");
  const [channelType, setChannelType] = useState("TEXT");
  const [channelCategory, setChannelCategory] = useState("");
  const [roleName, setRoleName] = useState("");
  const [roleColor, setRoleColor] = useState("#a1a1aa");
  const [editingRole, setEditingRole] = useState<RoleRow | null>(null);
  const [roleDeleteCandidate, setRoleDeleteCandidate] = useState<RoleRow | null>(null);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleteName, setDeleteName] = useState("");
  const [inviteExpiresInHours, setInviteExpiresInHours] = useState("168");
  const [inviteMaxUses, setInviteMaxUses] = useState("");
  const [inviteChannelId, setInviteChannelId] = useState("");
  const [roleAccessQuery, setRoleAccessQuery] = useState("");
  const [memberAccessQuery, setMemberAccessQuery] = useState("");
  const socketRef = useRef<Socket | null>(null);

  const allItems = useMemo(() => nav.flatMap((group) => group.items), []);
  const activeItem = allItems.find((item) => item.id === active);

  async function load() {
    const res = await fetch(`/api/servers/${serverId}/settings`, { cache: "no-store" });
    if (res.ok) setServer((await res.json()).server);
  }

  useEffect(() => { load(); }, [serverId]);
  useEffect(() => {
    const socket = io({ withCredentials: true, transports: ["websocket", "polling"] });
    socketRef.current = socket;
    const refresh = (payload: { serverId?: string } = {}) => { if (!payload.serverId || payload.serverId === serverId) load(); };
    socket.on("server:updated", refresh);
    socket.on("server:changed", refresh);
    socket.on("server:channel:created", refresh);
    socket.on("server:channel:changed", refresh);
    socket.on("server:category:changed", refresh);
    socket.on("server:role:changed", refresh);
    socket.on("server:member:joined", refresh);
    socket.on("server:member:changed", refresh);
    socket.on("server:invite:changed", refresh);
    socket.on("admin:server:changed", refresh);
    socket.on("admin:server:updated", refresh);
    socket.on("admin:overview:refresh", refresh);
    socket.on("server:deleted", ({ serverId: deletedId }: { serverId: string }) => { if (deletedId === serverId) window.location.href = "/app/@me"; });
    return () => { socket.disconnect(); };
  }, [serverId]);

  async function api(path: string, init?: RequestInit) {
    setNotice(null);
    const res = await fetch(path, init);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      setNotice({ type: "error", text: data.error || "Aktion fehlgeschlagen." });
      return null;
    }
    return data;
  }

  async function saveServer(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSaving(true);
    const form = new FormData(event.currentTarget);
    const payload = { name: String(form.get("name") || ""), iconUrl: String(form.get("iconUrl") || ""), isPrivate: Boolean(form.get("isPrivate")) };
    const data = await api(`/api/servers/${serverId}/settings`, { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify(payload) });
    setSaving(false);
    if (data?.server) { setServer(data.server); setNotice({ type: "success", text: "Server gespeichert." }); }
  }

  async function createCategory(event: FormEvent) {
    event.preventDefault();
    if (!categoryName.trim()) return;
    const data = await api(`/api/servers/${serverId}/categories`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ name: categoryName.trim() }) });
    if (data?.category) { setCategoryName(""); await load(); }
  }

  async function deleteCategory(id: string) {
    const data = await api(`/api/servers/${serverId}/categories/${id}`, { method: "DELETE" });
    if (data) await load();
  }

  async function createChannel(event: FormEvent) {
    event.preventDefault();
    if (!channelName.trim()) return;
    const data = await api(`/api/servers/${serverId}/channels`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ name: channelName.trim().toLowerCase().replaceAll(" ", "-"), type: channelType, categoryId: channelCategory || null, topic: "" }) });
    if (data?.channel) { setChannelName(""); await load(); }
  }

  async function deleteChannel(id: string) {
    const data = await api(`/api/servers/${serverId}/channels/${id}`, { method: "DELETE" });
    if (data) await load();
  }

  async function createRole(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const selected = permissions.filter((p) => form.get(p.id)).map((p) => p.id);
    const data = await api(`/api/servers/${serverId}/roles`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ name: roleName, color: roleColor, permissions: selected }) });
    if (data?.role) { setRoleName(""); await load(); }
  }

  async function updateRole(event: FormEvent<HTMLFormElement>, roleId: string) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const selected = permissions.filter((permission) => form.get(permission.id)).map((permission) => permission.id);
    const payload = { name: String(form.get("name") || "").trim(), color: String(form.get("color") || "#ffffff"), permissions: selected };
    const data = await api(`/api/servers/${serverId}/roles/${roleId}`, { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify(payload) });
    if (data?.role) { setEditingRole(null); await load(); setNotice({ type: "success", text: "Rolle gespeichert." }); }
  }

  async function deleteRole(id: string) {
    const data = await api(`/api/servers/${serverId}/roles/${id}`, { method: "DELETE" });
    if (data) { setRoleDeleteCandidate(null); await load(); setNotice({ type: "success", text: "Rolle gelöscht." }); }
  }

  async function createInvite() {
    const payload = {
      expiresInHours: inviteExpiresInHours ? Number(inviteExpiresInHours) : null,
      maxUses: inviteMaxUses ? Number(inviteMaxUses) : null,
      channelId: inviteChannelId || null
    };
    const data = await api(`/api/servers/${serverId}/invites`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(payload) });
    if (data?.url) { await navigator.clipboard?.writeText(data.url).catch(() => undefined); setNotice({ type: "success", text: "Invite erstellt und kopiert." }); await load(); }
  }

  async function deleteInvite(id: string) {
    const data = await api(`/api/servers/${serverId}/invites/${id}`, { method: "DELETE" });
    if (data) await load();
  }

  async function updateMember(memberId: string, body: MemberUpdatePayload) {
    const data = await api(`/api/servers/${serverId}/members/${memberId}`, { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
    if (data) await load();
  }

  async function kickMember(memberId: string) {
    const data = await api(`/api/servers/${serverId}/members/${memberId}`, { method: "DELETE" });
    if (data) await load();
  }

  async function deleteServer() {
    const data = await api(`/api/servers/${serverId}`, { method: "DELETE" });
    if (data?.ok) window.location.href = "/app/@me";
  }


  function channelOverrides(channel: ChannelRow): ChannelOverride[] {
    return (channel.permissionOverrides || []).map((override) => ({ roleId: override.roleId || null, memberId: override.memberId || null, allow: override.allow || [], deny: override.deny || [] }));
  }

  function overrideFor(channel: ChannelRow, key: "roleId" | "memberId", id: string) {
    return channelOverrides(channel).find((override) => override[key] === id);
  }

  async function updateChannelAccess(channel: ChannelRow, nextPrivate: boolean, overrides = channelOverrides(channel)) {
    const data = await api(`/api/servers/${serverId}/channels/${channel.id}/permissions`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ isPrivate: nextPrivate, overrides: overrides.filter((override) => override.allow.length || override.deny.length) })
    });
    if (data) { await load(); setNotice({ type: "success", text: "Channel-Zugriff gespeichert." }); }
  }

  async function setChannelPermission(channel: ChannelRow, key: "roleId" | "memberId", id: string, permission: string, mode: "allow" | "deny", checked: boolean) {
    const overrides = channelOverrides(channel);
    let target = overrides.find((override) => override[key] === id);
    if (!target) {
      target = { roleId: key === "roleId" ? id : null, memberId: key === "memberId" ? id : null, allow: [], deny: [] };
      overrides.push(target);
    }
    const allow = new Set(target.allow);
    const deny = new Set(target.deny);
    if (mode === "allow") {
      checked ? allow.add(permission) : allow.delete(permission);
      if (checked) deny.delete(permission);
    } else {
      checked ? deny.add(permission) : deny.delete(permission);
      if (checked) allow.delete(permission);
    }
    target.allow = [...allow];
    target.deny = [...deny];
    await updateChannelAccess(channel, true, overrides);
  }

  function renderRolePermissionGroups(defaultSelected: string[] = []) {
    const selected = new Set(defaultSelected);
    return <div className="grid gap-3 lg:grid-cols-2">{permissionGroups.map((group) => <div key={group.label} className="rounded-3xl border border-white/10 bg-white/[.025] p-3"><p className="mb-2 text-[11px] font-bold uppercase tracking-[.16em] text-zinc-600">{group.label}</p><div className="space-y-2">{group.ids.map((id) => { const meta = permissionMeta(id); return <label key={id} className="rounded-2xl border border-white/10 bg-black/20 p-3"><span className="flex items-center gap-2 text-sm text-white"><input name={id} type="checkbox" defaultChecked={selected.has(id)} className="accent-white" /> {meta.label}{dangerousPermissions.has(id) && <AlertTriangle size={13} className="text-amber-200" />}</span><span className="mt-1 block pl-6 text-xs text-zinc-500">{meta.description}</span></label>; })}</div></div>)}</div>;
  }

  function renderPermissionMatrix(ch: ChannelRow, key: "roleId" | "memberId", id: string) {
    const override = overrideFor(ch, key, id);
    return (
      <div className="grid gap-2 md:grid-cols-2">
        {privateChannelPermissions.map((permission) => {
          const label = permission.replaceAll("_", " ");
          return (
            <div key={permission} className="rounded-2xl border border-white/10 bg-black/20 p-2">
              <p className="mb-2 text-[11px] font-semibold uppercase tracking-[.12em] text-zinc-500">{label}</p>
              <div className="flex gap-2">
                <label className="flex flex-1 items-center justify-center gap-2 rounded-xl border border-emerald-400/15 bg-emerald-500/5 px-2 py-1.5 text-[11px] text-emerald-100">
                  <input type="checkbox" checked={(override?.allow || []).includes(permission)} onChange={(event) => setChannelPermission(ch, key, id, permission, "allow", event.currentTarget.checked)} className="accent-white" /> Allow
                </label>
                <label className="flex flex-1 items-center justify-center gap-2 rounded-xl border border-red-400/15 bg-red-500/5 px-2 py-1.5 text-[11px] text-red-100">
                  <input type="checkbox" checked={(override?.deny || []).includes(permission)} onChange={(event) => setChannelPermission(ch, key, id, permission, "deny", event.currentTarget.checked)} className="accent-white" /> Deny
                </label>
              </div>
            </div>
          );
        })}
      </div>
    );
  }

  function renderChannelRow(ch: ChannelRow) {
    const roleQuery = roleAccessQuery.trim().toLowerCase();
    const memberQuery = memberAccessQuery.trim().toLowerCase();
    const visibleRoles = (server?.roles || [])
      .filter((role) => role.name.toLowerCase() !== "owner")
      .filter((role) => !roleQuery || role.name.toLowerCase().includes(roleQuery));
    const visibleMembers = (server?.members || [])
      .filter((member) => !member.isOwner)
      .filter((member) => {
        const name = `${member.nickname || ""} ${member.user.displayName} ${member.user.username}`.toLowerCase();
        return !memberQuery || name.includes(memberQuery);
      });

    return (
      <div key={ch.id} className="rounded-2xl border border-white/10 bg-white/[.025] p-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <span className="flex items-center gap-2 text-sm"><Hash size={14} /> {ch.name} <span className="text-zinc-600">{ch.type}</span>{ch.isPrivate && <span className="inline-flex items-center gap-1 rounded-full border border-amber-400/20 bg-amber-500/10 px-2 py-0.5 text-[10px] text-amber-100"><Lock size={10} /> privat</span>}</span>
          <div className="flex items-center gap-2">
            <label className="flex items-center gap-2 rounded-xl border border-white/10 bg-black/20 px-3 py-2 text-xs text-zinc-300"><input type="checkbox" checked={ch.isPrivate} onChange={(event) => updateChannelAccess(ch, event.currentTarget.checked)} className="accent-white" /> Privater Channel</label>
            <button onClick={() => deleteChannel(ch.id)} className="rounded-xl p-2 text-zinc-500 hover:bg-red-500/10 hover:text-red-200"><Trash2 size={15} /></button>
          </div>
        </div>
        {ch.isPrivate && <div className="mt-3 space-y-4 rounded-2xl border border-white/10 bg-black/20 p-3">
          <div className="rounded-2xl border border-amber-400/15 bg-amber-500/10 p-3 text-xs leading-5 text-amber-50/80">
            <b>Deny überschreibt Allow.</b> User-Overrides sind stärker als Rollen-Overrides. Owner/Admin behalten einen Schutz, damit du dich nicht aus dem Channel aussperrst.
          </div>
          <div className="grid gap-3 lg:grid-cols-2">
            <div>
              <div className="mb-2 flex items-center justify-between gap-2"><p className="text-[11px] font-bold uppercase tracking-[.16em] text-zinc-600">Rollen</p><input value={roleAccessQuery} onChange={(event) => setRoleAccessQuery(event.target.value)} className="field h-9 max-w-[220px] text-xs" placeholder="Rollen suchen" /></div>
              <div className="space-y-2">{visibleRoles.length ? visibleRoles.map((role) => <div key={role.id} className="rounded-2xl border border-white/10 bg-white/[.03] p-3"><p className="mb-2 text-xs font-semibold" style={{ color: role.color }}>{role.name}</p>{renderPermissionMatrix(ch, "roleId", role.id)}</div>) : <p className="rounded-2xl border border-white/10 bg-white/[.03] p-3 text-xs text-zinc-500">Keine Rollen gefunden.</p>}</div>
            </div>
            <div>
              <div className="mb-2 flex items-center justify-between gap-2"><p className="text-[11px] font-bold uppercase tracking-[.16em] text-zinc-600">Einzelne User</p><input value={memberAccessQuery} onChange={(event) => setMemberAccessQuery(event.target.value)} className="field h-9 max-w-[220px] text-xs" placeholder="User suchen" /></div>
              <div className="space-y-2">{visibleMembers.length ? visibleMembers.map((member) => <div key={member.id} className="rounded-2xl border border-white/10 bg-white/[.03] p-3"><p className="mb-2 text-xs text-zinc-300">{member.nickname || member.user.displayName} <span className="text-zinc-600">@{member.user.username}</span></p>{renderPermissionMatrix(ch, "memberId", member.id)}</div>) : <p className="rounded-2xl border border-white/10 bg-white/[.03] p-3 text-xs text-zinc-500">Keine User gefunden.</p>}</div>
            </div>
          </div>
        </div>}
      </div>
    );
  }

  const filteredNav = nav.map((group) => ({ ...group, items: group.items.filter((item) => item.label.toLowerCase().includes(query.toLowerCase())) })).filter((group) => group.items.length);
  if (!server) return <div className="grid h-full place-items-center text-sm text-zinc-500">Lade Server-Einstellungen...</div>;
  const channelsWithoutCategory = (server.channels || []).filter((channel) => !channel.categoryId);

  return (
    <div className="grid h-full min-h-0 grid-cols-[300px_1fr] bg-black/20">
      <aside className="nexo-scrollbar border-r border-white/10 bg-[#0b0b0d] p-4">
        <Link href={`/app/servers/${serverId}/channels/${server.channels?.[0]?.id || ""}`} className="mb-4 flex items-center gap-2 rounded-2xl px-3 py-2 text-sm text-zinc-400 hover:bg-white/[.06] hover:text-white"><ArrowLeft size={16} /> Zurück zum Server</Link>
        <div className="mb-4 rounded-3xl border border-white/10 bg-white/[.04] p-4"><p className="text-sm font-semibold text-white">{server.name}</p><p className="text-xs text-zinc-500">{server.members?.length || 0} Mitglieder · {server.channels?.length || 0} Channels</p></div>
        <div className="relative mb-4"><Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" /><input value={query} onChange={(e) => setQuery(e.target.value)} className="field h-11 pl-9" placeholder="Server Settings suchen" /></div>
        <nav className="space-y-5">
          {filteredNav.map((group) => <div key={group.group}><p className="mb-2 px-2 text-[11px] font-bold uppercase tracking-[.16em] text-zinc-600">{group.group}</p><div className="space-y-1">{group.items.map((item) => { const Icon = item.icon; const selected = active === item.id; return <button key={item.id} onClick={() => setActive(item.id)} className={clsx("flex w-full items-center gap-3 rounded-2xl px-3 py-2.5 text-left text-sm transition", selected ? "bg-white text-black" : item.danger ? "text-red-300 hover:bg-red-500/10" : "text-zinc-400 hover:bg-white/[.06] hover:text-white")}><Icon size={17} /> {item.label}</button>; })}</div></div>)}
        </nav>
      </aside>

      <main className="nexo-scrollbar overflow-y-auto p-6">
        <div className="mx-auto max-w-6xl space-y-6">
          <header className="flex items-end justify-between gap-4 border-b border-white/10 pb-6"><div><p className="text-xs font-bold uppercase tracking-[.18em] text-zinc-600">Server Settings</p><h1 className="mt-2 text-3xl font-semibold tracking-[-.06em] text-white">{activeItem?.label}</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-zinc-500">Discord-inspirierte Struktur, aber komplett im Nexo-Stil: ruhiger, dunkler, cleaner und ohne Kopie der Discord-Marke.</p></div></header>
          {notice && <Notice type={notice.type}>{notice.text}</Notice>}

          {active === "profile" && <form onSubmit={saveServer} className="grid gap-6 xl:grid-cols-[1fr_.8fr]"><SectionCard title="Serverprofil" description="Name, Icon und Sichtbarkeit." icon={ImagePlus}><div className="space-y-4"><Field label="Servername"><input name="name" className="field" defaultValue={server.name} minLength={2} maxLength={60} /></Field><Field label="Icon URL / Data URL"><input name="iconUrl" className="field" defaultValue={server.iconUrl || ""} placeholder="Optional" /></Field><label className="flex items-center justify-between rounded-3xl border border-white/10 bg-black/20 p-4"><span><b>Privater Server</b><p className="text-xs text-zinc-500">Beitritt nur über Invite.</p></span><input type="checkbox" name="isPrivate" defaultChecked={server.isPrivate} className="h-5 w-5 accent-white" /></label><button disabled={saving} className="primary-button inline-flex items-center gap-2"><Save size={16} /> Speichern</button></div></SectionCard><SectionCard title="Preview" icon={ChevronRight}><div className="rounded-[2rem] border border-white/10 bg-black/30 p-5"><div className="mb-4 grid size-16 place-items-center rounded-3xl border border-white/10 bg-white text-2xl font-black text-black">{server.iconUrl ? <img src={server.iconUrl} alt="Icon" className="size-16 rounded-3xl object-cover" /> : server.name.slice(0, 2).toUpperCase()}</div><h3 className="text-xl font-semibold text-white">{server.name}</h3><p className="mt-1 text-sm text-zinc-500">{server.isPrivate ? "Privater Server" : "Öffentlicher Server"}</p></div></SectionCard></form>}

          {active === "overview" && <div className="grid gap-4 md:grid-cols-4"><SectionCard title="Mitglieder"><p className="text-3xl font-semibold">{server.members?.length || 0}</p></SectionCard><SectionCard title="Channels"><p className="text-3xl font-semibold">{server.channels?.length || 0}</p></SectionCard><SectionCard title="Rollen"><p className="text-3xl font-semibold">{server.roles?.length || 0}</p></SectionCard><SectionCard title="Invites"><p className="text-3xl font-semibold">{server.invites?.length || 0}</p></SectionCard></div>}

          {active === "channels" && <SectionCard title="Channels" description="Text- und Voice-Channels verwalten. Private Channels werden nur berechtigten Rollen angezeigt." icon={Hash}><form onSubmit={createChannel} className="mb-5 grid gap-3 md:grid-cols-[1fr_180px_220px_auto]"><input value={channelName} onChange={(e) => setChannelName(e.target.value)} className="field" placeholder="neuer-channel" /><CustomSelect value={channelType} onChange={setChannelType} options={[{ value: "TEXT", label: "Text" }, { value: "VOICE", label: "Voice" }]} /><CustomSelect value={channelCategory} onChange={setChannelCategory} options={[{ value: "", label: "Keine Kategorie" }, ...(server.categories || []).map((cat: { id: string; name: string }) => ({ value: cat.id, label: cat.name }))]} /><button className="primary-button"><Plus size={16} /></button></form><Notice type="success">Private-Channel-Rechte sind jetzt echte Security-Regeln: API, Socket und Dateien prüfen dieselbe Permission-Logik.</Notice><div className="mt-5 space-y-4">{channelsWithoutCategory.length > 0 && <div className="rounded-3xl border border-white/10 bg-black/20 p-4"><p className="mb-2 text-xs font-bold uppercase tracking-[.16em] text-zinc-600">Ohne Kategorie</p><div className="space-y-2">{channelsWithoutCategory.map(renderChannelRow)}</div></div>}{server.categories?.map((cat: { id: string; name: string }) => <div key={cat.id} className="rounded-3xl border border-white/10 bg-black/20 p-4"><p className="mb-2 text-xs font-bold uppercase tracking-[.16em] text-zinc-600">{cat.name}</p><div className="space-y-2">{(server.channels || []).filter((ch: { categoryId?: string | null }) => ch.categoryId === cat.id).map(renderChannelRow)}</div></div>)}</div></SectionCard>}

          {active === "categories" && <SectionCard title="Kategorien" icon={BookOpen}><form onSubmit={createCategory} className="mb-5 flex gap-2"><input value={categoryName} onChange={(e) => setCategoryName(e.target.value)} className="field" placeholder="Neue Kategorie" /><button className="primary-button"><Plus size={16} /></button></form><div className="grid gap-3 md:grid-cols-2">{server.categories?.map((cat) => <div key={cat.id} className="rounded-3xl border border-white/10 bg-black/20 p-4"><div className="flex items-center justify-between"><b>{cat.name}</b><button onClick={() => deleteCategory(cat.id)} className="rounded-xl p-2 text-zinc-500 hover:bg-red-500/10 hover:text-red-200"><Trash2 size={15} /></button></div><p className="mt-1 text-xs text-zinc-500">{(server.channels || []).filter((ch) => ch.categoryId === cat.id).length} Channels</p></div>)}</div></SectionCard>}

          {active === "roles" && <SectionCard title="Rollen" description="Rollen bearbeiten, Farbe setzen, Rechte gruppiert prüfen und gefährliche Rechte bewusst vergeben." icon={Shield}><form onSubmit={createRole} className="mb-5 space-y-4 rounded-3xl border border-white/10 bg-black/20 p-4"><div className="grid gap-3 sm:grid-cols-[1fr_160px]"><input value={roleName} onChange={(e) => setRoleName(e.target.value)} className="field" placeholder="Rollenname" required /><input value={roleColor} onChange={(e) => setRoleColor(e.target.value)} className="field" placeholder="#ffffff" /></div>{renderRolePermissionGroups()}<button className="primary-button"><Plus size={16} /> Rolle erstellen</button></form><div className="grid gap-3">{server.roles?.map((role) => { const selected = parsePermissions(role.permissions); const protectedRole = role.name.toLowerCase() === "owner"; return <div key={role.id} className="rounded-3xl border border-white/10 bg-black/20 p-4"><div className="flex flex-wrap items-center justify-between gap-3"><div><p className="font-semibold" style={{ color: role.color }}>{role.name} <span className="ml-2 text-xs text-zinc-500">Position {role.position ?? 0}</span></p><p className="mt-1 text-xs text-zinc-500">{selected.join(" · ") || "Keine extra Rechte"}</p>{protectedRole && <p className="mt-2 text-xs text-amber-200">Systemrolle geschützt.</p>}</div><div className="flex gap-2"><button disabled={protectedRole} onClick={() => setEditingRole(editingRole?.id === role.id ? null : role)} className="soft-button px-3 py-2 text-xs"><Pencil size={14} /> Bearbeiten</button><button disabled={protectedRole} onClick={() => setRoleDeleteCandidate(role)} className="rounded-xl p-2 text-zinc-500 hover:bg-red-500/10 hover:text-red-200 disabled:opacity-40"><Trash2 size={15} /></button></div></div>{editingRole?.id === role.id && <form onSubmit={(event) => updateRole(event, role.id)} className="mt-4 space-y-4 rounded-3xl border border-white/10 bg-white/[.025] p-4"><div className="grid gap-3 sm:grid-cols-[1fr_160px]"><input name="name" className="field" defaultValue={role.name} required /><input name="color" className="field" defaultValue={role.color} /></div>{renderRolePermissionGroups(selected)}<div className="flex justify-end gap-2"><button type="button" onClick={() => setEditingRole(null)} className="soft-button">Abbrechen</button><button className="primary-button"><Save size={16} /> Speichern</button></div></form>}</div>; })}</div></SectionCard>}

          {active === "members" && <SectionCard title="Mitglieder" description="Member suchen, Nicknames setzen und Rollen zuweisen." icon={Users}><div className="space-y-3">{server.members?.map((member) => { const assigned = new Set((member.roleAssignments || []).map((assignment) => assignment.roleId)); return <div key={member.id} className="rounded-3xl border border-white/10 bg-black/20 p-4"><div className="flex flex-wrap items-start justify-between gap-3"><div className="flex items-center gap-3"><Avatar user={member.user} /><div><p className="font-medium text-white">{member.nickname || member.user.displayName} <span className="text-zinc-500">@{member.user.username}</span></p><p className="text-xs text-zinc-500">{member.isOwner ? "Owner" : member.isAdmin ? "Admin" : "Mitglied"}</p><div className="mt-2 flex flex-wrap gap-1">{(member.roleAssignments || []).map((assignment) => <span key={assignment.roleId} className="rounded-full border border-white/10 bg-white/[.04] px-2 py-1 text-[11px]" style={{ color: assignment.role.color }}>{assignment.role.name}</span>)}</div></div></div><div className="flex gap-2"><button onClick={() => updateMember(member.id, { isAdmin: !member.isAdmin })} disabled={member.isOwner} className="secondary-button text-xs">{member.isAdmin ? "Admin entfernen" : "Admin geben"}</button><button onClick={() => kickMember(member.id)} disabled={member.isOwner} className="rounded-2xl border border-red-400/20 bg-red-500/10 px-3 py-2 text-xs font-semibold text-red-200 disabled:opacity-40"><UserMinus size={14} /></button></div></div><div className="mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-3">{(server.roles || []).map((role) => <label key={role.id} className="flex items-center gap-2 rounded-2xl border border-white/10 bg-white/[.03] px-3 py-2 text-xs"><input type="checkbox" checked={assigned.has(role.id)} disabled={member.isOwner} onChange={(event) => { const next = new Set(assigned); event.currentTarget.checked ? next.add(role.id) : next.delete(role.id); updateMember(member.id, { roleIds: [...next] }); }} className="accent-white" /><span style={{ color: role.color }}>{role.name}</span></label>)}</div></div>; })}</div></SectionCard>}

          {active === "invites" && <SectionCard title="Einladungen" description="Erstelle kontrollierte Invite-Links mit Ablaufzeit, maximalen Nutzungen und optionalem Ziel-Channel." icon={Link2}>
            <div className="mb-5 grid gap-3 rounded-3xl border border-white/10 bg-black/20 p-4 md:grid-cols-[1fr_1fr_1fr_auto]">
              <Field label="Ablauf"><select value={inviteExpiresInHours} onChange={(event) => setInviteExpiresInHours(event.target.value)} className="field"><option value="">Kein Ablauf</option><option value="1">1 Stunde</option><option value="24">24 Stunden</option><option value="168">7 Tage</option><option value="720">30 Tage</option></select></Field>
              <Field label="Max. Nutzungen"><input value={inviteMaxUses} onChange={(event) => setInviteMaxUses(event.target.value)} className="field" type="number" min={1} max={1000} placeholder="Unbegrenzt" /></Field>
              <Field label="Ziel-Channel"><select value={inviteChannelId} onChange={(event) => setInviteChannelId(event.target.value)} className="field"><option value="">Erster Textchannel</option>{(server.channels || []).filter((channel) => channel.type === "TEXT").map((channel) => <option key={channel.id} value={channel.id}>#{channel.name}</option>)}</select></Field>
              <div className="flex items-end"><button onClick={createInvite} className="primary-button w-full"><Plus size={16} /> Erstellen</button></div>
            </div>
            <div className="space-y-2">{server.invites?.length ? server.invites.map((invite) => { const expired = invite.expiresAt ? new Date(invite.expiresAt) < new Date() : false; const disabled = Boolean(invite.disabledAt); const usedUp = Boolean(invite.maxUses && invite.uses >= invite.maxUses); const inviteLink = invite.url || `${window.location.origin}/invite/${invite.code}`; return <div key={invite.id} className={clsx("rounded-3xl border p-4", disabled || expired || usedUp ? "border-red-500/20 bg-red-500/5" : "border-white/10 bg-black/20")}><div className="flex flex-wrap items-center justify-between gap-3"><div><p className="font-mono text-sm text-white">/invite/{invite.code}</p><p className="mt-1 text-xs text-zinc-500">{invite.uses}{invite.maxUses ? `/${invite.maxUses}` : ""} Nutzungen · {invite.expiresAt ? `läuft ${new Date(invite.expiresAt).toLocaleString("de-DE")} ab` : "ohne Ablauf"}{invite.channel ? ` · Ziel #${invite.channel.name}` : ""}</p><p className="mt-1 text-xs text-zinc-600">Erstellt von {invite.createdBy?.displayName || invite.createdBy?.username || "Unbekannt"}{disabled ? " · deaktiviert" : expired ? " · abgelaufen" : usedUp ? " · Limit erreicht" : ""}</p></div><div className="flex gap-2"><button onClick={() => navigator.clipboard?.writeText(inviteLink)} className="soft-button px-3 py-2 text-xs">Kopieren</button><button disabled={disabled} onClick={() => deleteInvite(invite.id)} className="rounded-xl p-2 text-zinc-500 hover:bg-red-500/10 hover:text-red-200 disabled:opacity-40"><Trash2 size={15} /></button></div></div></div>; }) : <p className="rounded-3xl border border-white/10 bg-white/[.03] p-4 text-sm text-zinc-500">Noch keine Invites erstellt.</p>}</div>
          </SectionCard>}

          {active === "audit" && <SectionCard title="Audit-Log" description="Serveraktionen in chronologischer Reihenfolge." icon={Activity}><div className="space-y-2">{server.auditLogs?.length ? server.auditLogs.map((log) => <div key={log.id} className="rounded-3xl border border-white/10 bg-black/20 p-4 text-sm"><p className="text-zinc-200"><AuditText log={log} /></p><p className="mt-1 text-xs text-zinc-500">{log.actor?.displayName || "System"} · {new Date(log.createdAt).toLocaleString("de-DE")}</p></div>) : <p className="text-sm text-zinc-500">Noch keine Einträge.</p>}</div></SectionCard>}

          {active === "access" && <SectionCard title="Zugriff" icon={KeyRound}><div className="grid gap-3 md:grid-cols-2">{permissions.map((p) => <div key={p.id} className="rounded-3xl border border-white/10 bg-black/20 p-4"><b>{p.label}</b><p className="mt-1 text-sm text-zinc-500">{p.description}</p></div>)}</div></SectionCard>}
          {active === "bans" && <SectionCard title="Gebannte Mitglieder" icon={Ban}><p className="text-sm text-zinc-500">Server-spezifische Bans sind vorbereitet. Globale Account-Sperren verwaltest du aktuell im Admin-Panel.</p></SectionCard>}
          {active === "emoji" && <SectionCard title="Emoji" icon={Megaphone}><p className="text-sm text-zinc-500">Server-Emojis und Sticker sind als eigener Nexo-Bereich vorbereitet. Der globale Emoji-Picker nutzt bereits den vollständigen Emoji-Mart-Katalog.</p></SectionCard>}
          {active === "soundboard" && <SectionCard title="Soundboard" icon={Volume2}><p className="text-sm text-zinc-500">Soundboard-Slots und Audioverwaltung sind für die Voice-Phase vorbereitet.</p></SectionCard>}
          {active === "apps" && <SectionCard title="Integrationen" icon={Bot}><p className="text-sm text-zinc-500">Bots, Webhooks und Apps sind aktuell deaktiviert, damit Nexo privat und lokal bleibt.</p></SectionCard>}
          {active === "safety" && <SectionCard title="Sicherheit" icon={Lock}><div className="grid gap-3 md:grid-cols-2"><div className="rounded-3xl border border-white/10 bg-black/20 p-4"><b>Invite-Schutz</b><p className="mt-1 text-sm text-zinc-500">Server bleibt privat, solange du ihn nicht öffentlich stellst.</p></div><div className="rounded-3xl border border-white/10 bg-black/20 p-4"><b>Moderation</b><p className="mt-1 text-sm text-zinc-500">Audit-Log, Rollen und Admin-Aktionen sind verbunden.</p></div></div></SectionCard>}
          {active === "voice" && <SectionCard title="Sprachbereiche" icon={Radio}><p className="text-sm text-zinc-500">Voice-Channels sind als Struktur vorhanden. Echtes Voice braucht später WebRTC/Media-Server.</p></SectionCard>}
          {active === "notifications" && <SectionCard title="Benachrichtigungen" icon={Bell}><p className="text-sm text-zinc-500">Serverweite Mute-/Mention-Regeln sind als UI- und Datenmodell-Phase vorbereitet.</p></SectionCard>}
          {active === "danger" && <SectionCard title="Danger Zone" description="Diese Aktionen sind absichtlich getrennt und klar markiert." icon={Trash2}><button onClick={() => setDeleteOpen(true)} className="rounded-2xl border border-red-400/20 bg-red-500/10 px-4 py-3 text-sm font-semibold text-red-200 hover:bg-red-500/20">Server löschen</button></SectionCard>}
        </div>
      </main>
      <Modal open={Boolean(roleDeleteCandidate)} onClose={() => setRoleDeleteCandidate(null)} title="Rolle löschen?" description="Diese Aktion entfernt die Rolle von allen Usern und aus privaten Channel-Overrides.">
        {roleDeleteCandidate && <div className="space-y-4"><div className="rounded-3xl border border-red-500/20 bg-red-500/10 p-4 text-sm text-red-100">Rolle <b>{roleDeleteCandidate.name}</b> wirklich löschen?</div><div className="flex justify-end gap-3"><button className="soft-button" onClick={() => setRoleDeleteCandidate(null)}>Abbrechen</button><button className="primary-button bg-red-100 text-red-950 hover:bg-red-200" onClick={() => deleteRole(roleDeleteCandidate.id)}>Löschen</button></div></div>}
      </Modal>

      <Modal open={deleteOpen} title="Server endgültig löschen" description="Diese Aktion entfernt Server, Channels, Rollen, Nachrichten und Invites." onClose={() => setDeleteOpen(false)}>
        <div className="space-y-4"><p className="text-sm text-zinc-400">Tippe <b className="text-white">{server.name}</b>, um die Löschung zu bestätigen.</p><input value={deleteName} onChange={(e) => setDeleteName(e.target.value)} className="field" placeholder={server.name} /><button disabled={deleteName !== server.name} onClick={deleteServer} className="w-full rounded-2xl border border-red-400/20 bg-red-500/10 px-4 py-3 text-sm font-semibold text-red-200 disabled:opacity-40">Endgültig löschen</button></div>
      </Modal>
    </div>
  );
}
