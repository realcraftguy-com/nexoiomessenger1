"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { Bell, CheckCheck } from "lucide-react";
import { io, Socket } from "socket.io-client";
import { useToast } from "@/hooks/use-toast";

type Notification = { id: string; type: string; title: string; body?: string | null; href?: string | null; readAt?: string | null; createdAt: string };

export function NotificationBell() {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<Notification[]>([]);
  const [unread, setUnread] = useState(0);
  const [dmUnread, setDmUnread] = useState(0);
  const [mentionUnread, setMentionUnread] = useState(0);
  const [friendRequestUnread, setFriendRequestUnread] = useState(0);
  const [reportUnread, setReportUnread] = useState(0);
  const socketRef = useRef<Socket | null>(null);
  const { toast } = useToast();

  async function load() {
    const res = await fetch("/api/notifications", { cache: "no-store" });
    if (!res.ok) return;
    const data = await res.json().catch(() => ({}));
    setItems(Array.isArray(data.notifications) ? data.notifications : []);
    setUnread(Number(data.unread || 0));
    setDmUnread(Number(data.dmUnread || 0));
    setMentionUnread(Number(data.mentionUnread || 0));
    setFriendRequestUnread(Number(data.friendRequestUnread || 0));
    setReportUnread(Number(data.reportUnread || 0));
  }

  async function markAllRead() {
    await fetch("/api/notifications", { method: "PATCH" });
    setUnread(0);
    setItems((current) => current.map((item) => ({ ...item, readAt: item.readAt || new Date().toISOString() })));
  }

  useEffect(() => {
    load();
    const socket = io({ withCredentials: true, transports: ["websocket", "polling"] });
    socketRef.current = socket;
    socket.on("friend:request:new", () => { void load(); toast({ type: "info", title: "Neue Freundschaftsanfrage" }); });
    socket.on("friend:request:updated", () => { void load(); });
    socket.on("friend:added", () => { void load(); });
    socket.on("friend:removed", () => { void load(); });
    socket.on("admin:report:new", () => { void load(); });
    socket.on("admin:report:updated", () => { void load(); });
    socket.on("notification:new", ({ notification }: { notification?: Notification }) => {
      if (!notification) return;
      setItems((current) => [notification, ...current.filter((item) => item.id !== notification.id)].slice(0, 50));
      setUnread((count) => count + 1);
      toast({ type: "info", title: notification.title, description: notification.body || undefined });
    });
    return () => { socket.disconnect(); };
  }, [toast]);

  return (
    <div className="relative">
      <button type="button" onClick={() => setOpen((value) => !value)} className="relative grid h-9 w-9 place-items-center rounded-xl border border-white/10 bg-white/[.04] transition hover:bg-white/[.08]" title="Benachrichtigungen">
        <Bell size={16} />
        {(unread + dmUnread + friendRequestUnread + reportUnread) > 0 && <span className="absolute -right-1 -top-1 min-w-5 rounded-full border border-black bg-white px-1 text-[10px] font-bold text-black">{(unread + dmUnread + friendRequestUnread + reportUnread) > 99 ? "99+" : unread + dmUnread + friendRequestUnread + reportUnread}</span>}
      </button>
      {open && (
        <>
          <button type="button" aria-label="Schließen" className="fixed inset-0 z-30 cursor-default bg-transparent" onClick={() => setOpen(false)} />
          <div className="absolute right-0 top-12 z-40 w-[min(380px,calc(100vw-24px))] overflow-hidden rounded-3xl border border-white/10 bg-[#070707] shadow-2xl shadow-black/50">
            <div className="flex items-center justify-between border-b border-white/10 p-4">
              <div>
                <p className="text-sm font-semibold">Notifications</p>
                <p className="text-xs text-zinc-500">{unread} neue · {dmUnread} DM · {mentionUnread} Mention · {friendRequestUnread} Freunde · {reportUnread} Reports</p>
              </div>
              <button type="button" onClick={markAllRead} className="soft-button inline-flex items-center gap-2 px-3 py-2 text-xs"><CheckCheck size={14} /> gelesen</button>
            </div>
            <div className="nexo-scrollbar max-h-[420px] overflow-y-auto p-2">
              {items.length === 0 && <div className="rounded-2xl border border-dashed border-white/10 p-6 text-center text-sm text-zinc-500">Noch keine Benachrichtigungen.</div>}
              {items.map((item) => {
                const inner = (
                  <div className="rounded-2xl border border-white/10 bg-white/[.035] p-3 transition hover:bg-white/[.06]">
                    <div className="flex items-start gap-2">
                      {!item.readAt && <span className="mt-1.5 size-2 rounded-full bg-white" />}
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium">{item.title}</p>
                        {item.body && <p className="mt-1 line-clamp-2 text-xs leading-5 text-zinc-500">{item.body}</p>}
                      </div>
                    </div>
                  </div>
                );
                return item.href ? <Link key={item.id} href={item.href} onClick={() => setOpen(false)} className="mb-2 block">{inner}</Link> : <div key={item.id} className="mb-2">{inner}</div>;
              })}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
