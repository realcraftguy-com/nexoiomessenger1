"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  FormEvent,
  ReactNode,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import {
  Ban,
  Bot,
  Command,
  Headphones,
  LifeBuoy,
  Loader2,
  LogOut,
  Menu,
  Plus,
  Search,
  Settings,
  Shield,
  Users,
} from "lucide-react";
import { Avatar } from "@/components/ui/Avatar";
import { NotificationBell } from "@/components/app/NotificationBell";
import { UserProfilePopover } from "@/components/app/UserProfilePopover";
import { Modal } from "@/components/ui/Modal";
import { Notice } from "@/components/ui/Notice";
import clsx from "clsx";
import { io, Socket } from "socket.io-client";

type Me = {
  id: string;
  email: string;
  username: string;
  displayName: string;
  avatarUrl?: string | null;
  avatarColor: string;
  isAdmin: boolean;
  onboarded?: boolean;
};
type ServerItem = {
  id: string;
  name: string;
  iconUrl?: string | null;
  channels: { id: string; name: string; type: string }[];
};
type CommandItem = {
  id: string;
  label: string;
  hint: string;
  href: string;
  adminOnly?: boolean;
};

export function MainShell({
  children,
  side,
  title = "Nexo",
}: {
  children: ReactNode;
  side?: ReactNode;
  title?: string;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const [me, setMe] = useState<Me | null>(null);
  const [servers, setServers] = useState<ServerItem[]>([]);
  const [creating, setCreating] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [sideOpen, setSideOpen] = useState(false);
  const [serverName, setServerName] = useState("");
  const [serverError, setServerError] = useState("");
  const [commandOpen, setCommandOpen] = useState(false);
  const [commandQuery, setCommandQuery] = useState("");
  const [commandIndex, setCommandIndex] = useState(0);
  const [banNotice, setBanNotice] = useState<{ reason: string } | null>(null);
  const banSocketRef = useRef<Socket | null>(null);

  async function load() {
    const [meRes, serverRes] = await Promise.all([
      fetch("/api/auth/me"),
      fetch("/api/servers"),
    ]);
    if (meRes.ok) {
      const current = (await meRes.json()).user;
      setMe(current);
      if (current && !current.onboarded) router.push("/onboarding");
    } else {
      router.push("/login");
      return;
    }
    if (serverRes.ok) setServers((await serverRes.json()).servers);
  }

  useEffect(() => {
    load();
  }, []);

  useEffect(() => {
    const socket = io({
      withCredentials: true,
      transports: ["websocket", "polling"],
    });
    banSocketRef.current = socket;
    socket.on("account:banned", ({ reason }: { reason?: string }) => {
      const message = reason?.trim() || "Kein Grund angegeben";
      setBanNotice({ reason: message });
      fetch("/api/auth/logout", { method: "POST" }).catch(() => undefined);
      window.setTimeout(() => {
        router.push(`/login?banned=1&reason=${encodeURIComponent(message)}`);
        router.refresh();
      }, 4500);
    });
    socket.on("account:session_revoked", ({ reason }: { reason?: string }) => {
      const message =
        reason?.trim() ||
        "Deine Sitzung wurde beendet. Bitte melde dich neu an.";
      fetch("/api/auth/logout", { method: "POST" }).catch(() => undefined);
      router.push(
        `/login?session=revoked&reason=${encodeURIComponent(message)}`,
      );
      router.refresh();
    });
    const refreshServers = () => load();
    socket.on("server:created", refreshServers);
    socket.on("server:updated", refreshServers);
    socket.on("server:changed", refreshServers);
    socket.on("server:channel:created", refreshServers);
    socket.on("server:channel:changed", refreshServers);
    socket.on("server:category:changed", refreshServers);
    socket.on("server:role:changed", refreshServers);
    socket.on("server:member:joined", refreshServers);
    socket.on("server:member:changed", refreshServers);
    socket.on("server:invite:changed", refreshServers);
    socket.on("admin:server:updated", refreshServers);
    socket.on("admin:server:changed", refreshServers);
    socket.on("server:deleted", ({ serverId }: { serverId: string }) => {
      setServers((items) => items.filter((server) => server.id !== serverId));
      if (window.location.pathname.includes(`/servers/${serverId}/`)) {
        router.push("/app/@me");
        router.refresh();
      }
    });
    return () => {
      socket.disconnect();
    };
  }, [router]);

  const commandItems = useMemo<CommandItem[]>(() => {
    const base: CommandItem[] = [
      {
        id: "friends",
        label: "Freunde",
        hint: "Freunde, Anfragen und Online-Status",
        href: "/app/@me/friends",
      },
      {
        id: "dms",
        label: "Direktnachrichten",
        hint: "Private Chats öffnen",
        href: "/app/@me",
      },
      {
        id: "settings",
        label: "Settings",
        hint: "Profil, Privatsphäre und Sicherheit",
        href: "/app/settings",
      },
      {
        id: "support",
        label: "Support",
        hint: "Tickets und Hilfe",
        href: "/app/support",
      },
      { id: "ai", label: "Nexo AI", hint: "AI Chat öffnen", href: "/app/ai" },
      {
        id: "admin",
        label: "Admin Panel",
        hint: "Kontrollzentrum",
        href: "/app/admin",
        adminOnly: true,
      },
    ];
    for (const server of servers) {
      const firstText =
        server.channels.find((channel) => channel.type === "TEXT") ||
        server.channels[0];
      if (firstText)
        base.push({
          id: `server-${server.id}`,
          label: server.name,
          hint: "Server öffnen",
          href: `/app/servers/${server.id}/channels/${firstText.id}`,
        });
      for (const channel of server.channels.slice(0, 20))
        base.push({
          id: `channel-${channel.id}`,
          label: `#${channel.name}`,
          hint: server.name,
          href: `/app/servers/${server.id}/channels/${channel.id}`,
        });
    }
    return base.filter((item) => !item.adminOnly || me?.isAdmin);
  }, [me?.isAdmin, servers]);

  const visibleCommands = useMemo(() => {
    const q = commandQuery.trim().toLowerCase();
    const filtered = q
      ? commandItems.filter((item) =>
          `${item.label} ${item.hint}`.toLowerCase().includes(q),
        )
      : commandItems;
    return filtered.slice(0, 12);
  }, [commandItems, commandQuery]);

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
        event.preventDefault();
        setCommandOpen(true);
        setCommandIndex(0);
      }
      if (!commandOpen) return;
      if (event.key === "Escape") setCommandOpen(false);
      if (event.key === "ArrowDown") {
        event.preventDefault();
        setCommandIndex((index) =>
          Math.min(index + 1, Math.max(visibleCommands.length - 1, 0)),
        );
      }
      if (event.key === "ArrowUp") {
        event.preventDefault();
        setCommandIndex((index) => Math.max(index - 1, 0));
      }
      if (event.key === "Enter" && visibleCommands[commandIndex]) {
        event.preventDefault();
        router.push(visibleCommands[commandIndex].href);
        setCommandOpen(false);
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [commandIndex, commandOpen, router, visibleCommands]);

  function openCommand(item: CommandItem) {
    router.push(item.href);
    setCommandOpen(false);
    setCommandQuery("");
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/login");
    router.refresh();
  }

  async function createServer(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const name = serverName.trim();
    if (name.length < 2)
      return setServerError("Der Servername braucht mindestens 2 Zeichen.");

    setCreating(true);
    setServerError("");
    const res = await fetch("/api/servers", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ name, isPrivate: true }),
    });
    setCreating(false);
    const data = await res.json().catch(() => ({}));
    if (!res.ok)
      return setServerError(
        data.error || "Server konnte nicht erstellt werden.",
      );

    setCreateOpen(false);
    setServerName("");
    const channel =
      data.server.channels.find((c: { type: string }) => c.type === "TEXT") ||
      data.server.channels[0];
    router.push(`/app/servers/${data.server.id}/channels/${channel.id}`);
    load();
  }

  return (
    <div className="flex h-screen overflow-hidden bg-surface-950 text-white">
      <aside className="flex w-[76px] shrink-0 flex-col items-center gap-3 border-r border-white/10 bg-black/40 px-3 py-4">
        <Link
          href="/app/@me"
          className={clsx(
            "grid h-12 w-12 place-items-center rounded-2xl border transition",
            pathname.includes("@me")
              ? "border-white bg-white text-black"
              : "border-white/10 bg-white/[.04] text-white hover:bg-white/[.08]",
          )}
        >
          <Users size={20} />
        </Link>
        <div className="h-px w-10 bg-white/10" />
        <div className="nexo-scrollbar flex min-h-0 flex-1 flex-col gap-3 overflow-y-auto">
          {servers.map((server) => {
            const firstText =
              server.channels.find((c) => c.type === "TEXT") ||
              server.channels[0];
            return (
              <Link
                key={server.id}
                href={
                  firstText
                    ? `/app/servers/${server.id}/channels/${firstText.id}`
                    : "/app/@me"
                }
                className={clsx(
                  "grid h-12 w-12 place-items-center overflow-hidden rounded-2xl border text-xs font-black transition",
                  pathname.includes(server.id)
                    ? "border-white bg-white text-black"
                    : "border-white/10 bg-white/[.04] text-white hover:bg-white/[.08]",
                )}
              >
                {server.iconUrl ? (
                  <img
                    src={server.iconUrl}
                    alt=""
                    className="h-full w-full object-cover"
                  />
                ) : (
                  server.name.slice(0, 2).toUpperCase()
                )}
              </Link>
            );
          })}
        </div>
        <button
          onClick={() => setCreateOpen(true)}
          disabled={creating}
          className="grid h-12 w-12 place-items-center rounded-2xl border border-white/10 bg-white/[.04] text-white transition hover:bg-white/[.09] disabled:opacity-50"
          title="Server erstellen"
        >
          <Plus size={20} />
        </button>
        <Link
          href="/app/ai"
          className="grid h-12 w-12 place-items-center rounded-2xl border border-white/10 bg-white/[.04] transition hover:bg-white/[.08]"
        >
          <Bot size={20} />
        </Link>
        <Link
          href="/app/support"
          className="grid h-12 w-12 place-items-center rounded-2xl border border-white/10 bg-white/[.04] transition hover:bg-white/[.08]"
        >
          <LifeBuoy size={20} />
        </Link>
        {me?.isAdmin && (
          <Link
            href="/app/admin"
            className="grid h-12 w-12 place-items-center rounded-2xl border border-white/10 bg-white/[.04] transition hover:bg-white/[.08]"
          >
            <Shield size={20} />
          </Link>
        )}
      </aside>

      {side && (
        <aside className="hidden w-72 shrink-0 border-r border-white/10 bg-surface-900/70 md:block">
          {side}
        </aside>
      )}
      {sideOpen && side && (
        <div className="fixed inset-0 z-50 md:hidden">
          <button
            aria-label="Menü schließen"
            className="absolute inset-0 bg-black/70 backdrop-blur-sm"
            onClick={() => setSideOpen(false)}
          />
          <aside className="relative h-full w-[86vw] max-w-80 border-r border-white/10 bg-surface-900 shadow-2xl">
            {side}
          </aside>
        </div>
      )}

      <section className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-16 shrink-0 items-center justify-between border-b border-white/10 bg-surface-950/75 px-3 sm:px-5 backdrop-blur-xl">
          <div className="flex min-w-0 items-center gap-3">
            {side && (
              <button
                type="button"
                onClick={() => setSideOpen(true)}
                className="grid h-9 w-9 place-items-center rounded-xl border border-white/10 bg-white/[.04] md:hidden"
              >
                <Menu size={16} />
              </button>
            )}
            <div>
              <h1 className="text-sm font-semibold">{title}</h1>
              <p className="text-xs text-zinc-500">Bereit für deine Chats</p>
            </div>
          </div>
          <div className="flex items-center gap-2 sm:gap-3">
            <button
              type="button"
              onClick={() => setCommandOpen(true)}
              className="soft-button hidden items-center gap-2 md:inline-flex"
            >
              <Command size={16} /> Ctrl K
            </button>
            <Link
              href="/app/settings"
              className="soft-button hidden items-center gap-2 sm:inline-flex"
            >
              <Settings size={16} /> Settings
            </Link>
            <Link
              href="/app/ai"
              className="soft-button hidden items-center gap-2 lg:inline-flex"
            >
              <Headphones size={16} /> Nexo AI
            </Link>
            <NotificationBell />
            {me && <UserProfilePopover user={me} compact />}
            <button
              onClick={logout}
              className="grid h-9 w-9 place-items-center rounded-xl border border-white/10 bg-white/[.04] transition hover:bg-white/[.08]"
              title="Logout"
            >
              <LogOut size={16} />
            </button>
          </div>
        </header>
        <div className="min-h-0 flex-1 overflow-hidden">{children}</div>
      </section>

      {commandOpen && (
        <div
          className="fixed inset-0 z-[90] grid place-items-start bg-black/70 px-4 pt-[12vh] backdrop-blur-xl"
          onMouseDown={() => setCommandOpen(false)}
        >
          <div
            className="mx-auto w-full max-w-2xl rounded-[2rem] border border-white/10 bg-surface-900 p-3 shadow-2xl shadow-black/60"
            onMouseDown={(event) => event.stopPropagation()}
          >
            <div className="flex items-center gap-3 rounded-2xl border border-white/10 bg-black/30 px-4 py-3">
              <Search size={17} className="text-zinc-500" />
              <input
                value={commandQuery}
                onChange={(event) => {
                  setCommandQuery(event.target.value);
                  setCommandIndex(0);
                }}
                autoFocus
                placeholder="Springe zu Servern, Channels, Freunden, Settings..."
                className="min-w-0 flex-1 bg-transparent text-sm outline-none placeholder:text-zinc-600"
              />
              <span className="rounded-lg border border-white/10 px-2 py-1 text-[10px] text-zinc-500">
                ESC
              </span>
            </div>
            <div className="mt-3 max-h-[52vh] overflow-y-auto pr-1 nexo-scrollbar">
              {visibleCommands.length === 0 && (
                <p className="rounded-2xl border border-dashed border-white/10 p-6 text-center text-sm text-zinc-500">
                  Nichts gefunden.
                </p>
              )}
              {visibleCommands.map((item, index) => (
                <button
                  key={item.id}
                  type="button"
                  onMouseEnter={() => setCommandIndex(index)}
                  onClick={() => openCommand(item)}
                  className={clsx(
                    "flex w-full items-center justify-between rounded-2xl px-4 py-3 text-left transition",
                    index === commandIndex
                      ? "bg-white text-black"
                      : "text-zinc-200 hover:bg-white/[.06]",
                  )}
                >
                  <span>
                    <b className="block text-sm">{item.label}</b>
                    <span
                      className={clsx(
                        "text-xs",
                        index === commandIndex
                          ? "text-black/60"
                          : "text-zinc-500",
                      )}
                    >
                      {item.hint}
                    </span>
                  </span>
                  <span
                    className={clsx(
                      "text-[11px]",
                      index === commandIndex
                        ? "text-black/50"
                        : "text-zinc-600",
                    )}
                  >
                    Enter
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {banNotice && (
        <div className="fixed inset-0 z-[100] grid place-items-center bg-black/80 px-4 backdrop-blur-xl">
          <div className="w-full max-w-lg rounded-[2rem] border border-red-400/25 bg-[#120809] p-8 text-center shadow-2xl shadow-red-950/30">
            <div className="mx-auto grid h-16 w-16 place-items-center rounded-3xl border border-red-400/30 bg-red-500/15 text-red-100">
              <Ban size={28} />
            </div>
            <h2 className="mt-6 text-2xl font-semibold tracking-[-.04em]">
              Du wurdest gesperrt
            </h2>
            <p className="mt-3 text-sm leading-6 text-red-100/80">
              Aufgrund von:
            </p>
            <div className="mt-4 rounded-3xl border border-red-400/20 bg-red-500/10 px-4 py-3 text-sm text-red-50">
              {banNotice.reason}
            </div>
            <p className="mt-5 text-xs leading-5 text-zinc-400">
              Du wirst automatisch ausgeloggt. Falls das ein Fehler ist,
              kontaktiere den Support oder einen Admin.
            </p>
          </div>
        </div>
      )}

      <Modal
        open={createOpen}
        onClose={() => !creating && setCreateOpen(false)}
        title="Server erstellen"
        description="Erstelle einen privaten Space für Freunde, Klasse oder Projektteam."
      >
        <form onSubmit={createServer} className="space-y-4">
          <label className="space-y-2">
            <span className="label">Servername</span>
            <input
              value={serverName}
              onChange={(event) => setServerName(event.target.value)}
              className="field"
              placeholder="z.B. Klasse 8b, Freunde, Nexo Team"
              autoFocus
              minLength={2}
              maxLength={40}
              required
            />
          </label>
          <div className="rounded-3xl border border-white/10 bg-white/[.035] p-4">
            <p className="text-sm font-medium text-white">Privater Server</p>
            <p className="mt-1 text-xs leading-5 text-zinc-500">
              Neue Server sind erstmal privat. Du kannst später Einladungen
              erstellen.
            </p>
          </div>
          <Notice type="error">{serverError}</Notice>
          <div className="flex justify-end gap-3 pt-1">
            <button
              type="button"
              onClick={() => setCreateOpen(false)}
              disabled={creating}
              className="soft-button"
            >
              Abbrechen
            </button>
            <button
              disabled={creating}
              className="primary-button inline-flex items-center gap-2"
            >
              {creating && <Loader2 size={16} className="animate-spin" />}
              Server erstellen
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
