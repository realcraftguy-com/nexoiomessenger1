"use client";

import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { FormEvent, useEffect, useRef, useState } from "react";
import { Check, Hash, Link as LinkIcon, Loader2, Mic, Plus, Settings, Trash2 } from "lucide-react";
import { io, Socket } from "socket.io-client";
import { Modal } from "@/components/ui/Modal";
import { Notice } from "@/components/ui/Notice";
import clsx from "clsx";

type ChannelKind = "TEXT" | "VOICE";

export function ChannelSidebar({ serverId }: { serverId: string }) {
  const params = useParams();
  const router = useRouter();
  const channelId = String(params.channelId || "");
  const [server, setServer] = useState<any>(null);
  const [membership, setMembership] = useState<any>(null);
  const [channelModal, setChannelModal] = useState<ChannelKind | null>(null);
  const [channelName, setChannelName] = useState("");
  const [channelTopic, setChannelTopic] = useState("");
  const [channelCategoryId, setChannelCategoryId] = useState<string>("");
  const [channelError, setChannelError] = useState("");
  const [creatingChannel, setCreatingChannel] = useState(false);
  const [inviteUrl, setInviteUrl] = useState("");
  const [inviteMessage, setInviteMessage] = useState("");
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [generalError, setGeneralError] = useState("");
  const [deleting, setDeleting] = useState(false);
  const socketRef = useRef<Socket | null>(null);

  async function load() {
    const res = await fetch(`/api/servers/${serverId}`);
    if (res.ok) {
      const data = await res.json();
      setServer(data.server);
      setMembership(data.membership);
    }
  }

  useEffect(() => { load(); }, [serverId]);

  useEffect(() => {
    const socket = io({ withCredentials: true, transports: ["websocket", "polling"] });
    socketRef.current = socket;
    const refresh = (payload: any = {}) => {
      if (!payload.serverId || payload.serverId === serverId) load();
    };
    socket.on("server:updated", refresh);
    socket.on("server:changed", refresh);
    socket.on("server:channel:created", refresh);
    socket.on("server:channel:changed", (payload: any = {}) => {
      refresh(payload);
      if (payload.serverId === serverId && payload.action === "deleted" && window.location.pathname.includes(`/channels/${payload.channelId}`)) {
        window.setTimeout(async () => {
          const res = await fetch(`/api/servers/${serverId}`, { cache: "no-store" }).catch(() => null);
          if (!res?.ok) return window.location.assign("/app/@me");
          const data = await res.json();
          const nextChannel = data.server?.channels?.find((channel: any) => channel.type === "TEXT") || data.server?.channels?.[0];
          window.location.assign(nextChannel ? `/app/servers/${serverId}/channels/${nextChannel.id}` : "/app/@me");
        }, 80);
      }
    });
    socket.on("server:category:changed", refresh);
    socket.on("server:role:changed", refresh);
    socket.on("server:member:joined", refresh);
    socket.on("server:member:changed", refresh);
    socket.on("server:invite:changed", refresh);
    socket.on("admin:server:changed", refresh);
    socket.on("server:deleted", ({ serverId: deletedId }: { serverId: string }) => {
      if (deletedId === serverId) router.push("/app/@me");
    });
    return () => { socket.disconnect(); };
  }, [serverId, router]);

  function openChannelModal(type: ChannelKind) {
    setChannelModal(type);
    setChannelName("");
    setChannelTopic("");
    setChannelCategoryId("");
    setChannelError("");
  }

  async function createChannel(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!channelModal) return;
    const name = channelName.toLowerCase().trim().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "");
    if (name.length < 2) return setChannelError("Der Channelname braucht mindestens 2 gültige Zeichen.");

    setCreatingChannel(true);
    setChannelError("");
    const res = await fetch(`/api/servers/${serverId}/channels`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ name, type: channelModal, topic: channelTopic, categoryId: channelCategoryId || null })
    });
    setCreatingChannel(false);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return setChannelError(data.error || "Channel konnte nicht erstellt werden.");

    const createdType = channelModal;
    setChannelModal(null);
    setChannelName("");
    if (createdType === "TEXT") router.push(`/app/servers/${serverId}/channels/${data.channel.id}`);
    load();
  }

  async function createInvite() {
    setGeneralError("");
    const res = await fetch(`/api/servers/${serverId}/invites`, { method: "POST" });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return setGeneralError(data.error || "Einladung konnte nicht erstellt werden.");

    setInviteUrl(data.url);
    const copied = await navigator.clipboard?.writeText(data.url).then(() => true).catch(() => false);
    setInviteMessage(copied ? "Link wurde kopiert." : "Link ist bereit. Du kannst ihn manuell kopieren.");
  }

  async function deleteServer() {
    setDeleting(true);
    setGeneralError("");
    const socket = socketRef.current;
    if (socket?.connected) {
      socket.emit("server:delete", { serverId }, async (result: any) => {
        setDeleting(false);
        if (result?.error || !result?.ok) {
          setGeneralError(result?.error || "Server konnte nicht gelöscht werden.");
          return;
        }
        setDeleteOpen(false);
        router.push("/app/@me");
      });
      return;
    }
    const res = await fetch(`/api/servers/${serverId}`, { method: "DELETE" });
    setDeleting(false);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return setGeneralError(data.error || "Server konnte nicht gelöscht werden.");
    setDeleteOpen(false);
    router.push("/app/@me");
  }

  if (!server) return <div className="p-4 text-sm text-zinc-500">Lade Server...</div>;

  const categories = server.categories || [];
  const uncategorized = server.channels.filter((c: any) => !c.categoryId);
  const canManage = membership?.isAdmin || membership?.isOwner;

  function renderChannel(channel: any) {
    if (channel.type === "VOICE") {
      return <div key={channel.id} className="flex items-center gap-2 rounded-2xl px-3 py-2 text-sm text-zinc-500"><Mic size={15} /> {channel.name}</div>;
    }
    return (
      <Link key={channel.id} href={`/app/servers/${serverId}/channels/${channel.id}`} className={clsx("flex items-center gap-2 rounded-2xl px-3 py-2 text-sm transition", channelId === channel.id ? "bg-white text-black" : "text-zinc-400 hover:bg-white/[.06] hover:text-white")}>
        <Hash size={15} /> {channel.name}
      </Link>
    );
  }

  return (
    <div className="flex h-full flex-col">
      <div className="border-b border-white/10 p-4">
        <div className="flex items-center justify-between gap-3">
          <div>
            <h2 className="font-semibold tracking-[-.02em]">{server.name}</h2>
            <p className="text-xs text-zinc-500">{server.members.length} Mitglieder</p>
          </div>
          <div className="flex gap-2">
            {canManage && <Link href={`/app/servers/${serverId}/settings`} className="rounded-xl border border-white/10 bg-white/[.04] p-2 text-zinc-300 transition hover:bg-white/[.08]" title="Server Einstellungen"><Settings size={15} /></Link>}
            {canManage && <button onClick={createInvite} className="rounded-xl border border-white/10 bg-white/[.04] p-2 text-zinc-300 transition hover:bg-white/[.08]" title="Invite erstellen"><LinkIcon size={15} /></button>}
            {membership?.isOwner && <button onClick={() => setDeleteOpen(true)} className="rounded-xl border border-red-500/20 bg-red-500/10 p-2 text-red-200 transition hover:bg-red-500/20" title="Server löschen"><Trash2 size={15} /></button>}
          </div>
        </div>
        {generalError && <div className="mt-3"><Notice type="error">{generalError}</Notice></div>}
      </div>
      <div className="nexo-scrollbar min-h-0 flex-1 space-y-6 overflow-y-auto p-3">
        {categories.map((category: any) => {
          const channels = server.channels.filter((c: any) => c.categoryId === category.id);
          return (
            <section key={category.id}>
              <div className="mb-2 flex items-center justify-between px-2 text-xs font-semibold uppercase tracking-[.14em] text-zinc-500">
                {category.name} {canManage && <button onClick={() => { openChannelModal("TEXT"); setChannelCategoryId(category.id); }} className="rounded-lg p-1 transition hover:bg-white/[.08] hover:text-white"><Plus size={14} /></button>}
              </div>
              <div className="space-y-1">{channels.map(renderChannel)}{channels.length === 0 && <p className="px-2 text-xs text-zinc-600">Keine Channels.</p>}</div>
            </section>
          );
        })}
        <section>
          <div className="mb-2 flex items-center justify-between px-2 text-xs font-semibold uppercase tracking-[.14em] text-zinc-500">
            Ohne Kategorie {canManage && <button onClick={() => openChannelModal("TEXT")} className="rounded-lg p-1 transition hover:bg-white/[.08] hover:text-white"><Plus size={14} /></button>}
          </div>
          <div className="space-y-1">{uncategorized.map(renderChannel)}</div>
          {canManage && <button onClick={() => openChannelModal("VOICE")} className="soft-button mt-3 w-full justify-center text-xs">Voice UI hinzufügen</button>}
        </section>
      </div>
      <div className="border-t border-white/10 p-4">
        <p className="mb-2 text-xs font-semibold uppercase tracking-[.14em] text-zinc-500">Mitglieder</p>
        <div className="space-y-2">
          {server.members.slice(0, 8).map((member: any) => (
            <div key={member.id} className="flex items-center justify-between rounded-2xl bg-white/[.03] px-3 py-2 text-sm text-zinc-300">
              <span>{member.user.displayName}</span>
              {member.isOwner && <span className="text-[10px] text-zinc-500">Owner</span>}
            </div>
          ))}
        </div>
      </div>

      <Modal open={Boolean(channelModal)} onClose={() => !creatingChannel && setChannelModal(null)} title={channelModal === "VOICE" ? "Voice-Channel erstellen" : "Textchannel erstellen"} description={channelModal === "VOICE" ? "Voice ist aktuell als UI vorbereitet." : "Erstelle einen neuen Chatbereich für deinen Server."}>
        <form onSubmit={createChannel} className="space-y-4">
          <label className="space-y-2"><span className="label">Channelname</span><input value={channelName} onChange={(event) => setChannelName(event.target.value)} className="field" placeholder="z.B. ankündigungen" autoFocus required /></label>
          <label className="space-y-2"><span className="label">Thema / Beschreibung</span><input value={channelTopic} onChange={(event) => setChannelTopic(event.target.value)} className="field" placeholder="Worum geht es hier?" /></label>
          <div className="space-y-2"><span className="label">Kategorie</span><div className="grid gap-2"> <button type="button" onClick={() => setChannelCategoryId("")} className={clsx("rounded-2xl border px-3 py-2 text-left text-sm", !channelCategoryId ? "border-white/30 bg-white text-black" : "border-white/10 bg-white/[.03] text-zinc-300")}>Ohne Kategorie</button>{categories.map((cat: any) => <button key={cat.id} type="button" onClick={() => setChannelCategoryId(cat.id)} className={clsx("rounded-2xl border px-3 py-2 text-left text-sm", channelCategoryId === cat.id ? "border-white/30 bg-white text-black" : "border-white/10 bg-white/[.03] text-zinc-300")}>{cat.name}</button>)}</div></div>
          <Notice type="error">{channelError}</Notice>
          <div className="flex justify-end gap-3"><button type="button" onClick={() => setChannelModal(null)} disabled={creatingChannel} className="soft-button">Abbrechen</button><button disabled={creatingChannel} className="primary-button inline-flex items-center gap-2">{creatingChannel && <Loader2 size={16} className="animate-spin" />} Erstellen</button></div>
        </form>
      </Modal>

      <Modal open={Boolean(inviteUrl)} onClose={() => { setInviteUrl(""); setInviteMessage(""); }} title="Einladung" description="Sende diesen Link an Leute, die deinem Server beitreten sollen." size="sm">
        <div className="space-y-4"><div className="rounded-2xl border border-white/10 bg-black/30 p-3 text-sm text-zinc-300 break-all">{inviteUrl}</div>{inviteMessage && <Notice type="success">{inviteMessage}</Notice>}<button className="primary-button w-full" onClick={() => navigator.clipboard?.writeText(inviteUrl)}>Kopieren</button></div>
      </Modal>

      <Modal open={deleteOpen} onClose={() => !deleting && setDeleteOpen(false)} title="Server löschen?" description="Der Server, Channels und Nachrichten werden entfernt. Alle Mitglieder werden sofort zurückgeleitet." size="sm">
        <div className="space-y-4"><div className="rounded-3xl border border-red-500/20 bg-red-500/10 p-4 text-sm leading-6 text-red-100">Diese Aktion kann nicht rückgängig gemacht werden.</div><div className="flex justify-end gap-3"><button onClick={() => setDeleteOpen(false)} disabled={deleting} className="soft-button">Abbrechen</button><button onClick={deleteServer} disabled={deleting} className="primary-button inline-flex items-center gap-2 bg-red-100 text-red-950 hover:bg-red-200">{deleting && <Loader2 size={16} className="animate-spin" />} Löschen</button></div></div>
      </Modal>
    </div>
  );
}
