"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { io, Socket } from "socket.io-client";
import { ChatPanel } from "@/components/chat/ChatPanel";

export function ServerChatClient({ serverId, channelId }: { serverId: string; channelId: string }) {
  const router = useRouter();
  const [server, setServer] = useState<any>(null);
  const [missingChannel, setMissingChannel] = useState(false);
  const socketRef = useRef<Socket | null>(null);
  const channel = server?.channels.find((c: any) => c.id === channelId);

  const load = useCallback(async (redirectIfMissing = false) => {
    const res = await fetch(`/api/servers/${serverId}`, { cache: "no-store" }).catch(() => null);
    if (!res?.ok) {
      router.push("/app/@me");
      router.refresh();
      return;
    }
    const data = await res.json();
    const nextServer = data.server;
    setServer(nextServer);
    const exists = nextServer?.channels?.some((item: any) => item.id === channelId);
    setMissingChannel(!exists);
    if (redirectIfMissing && !exists) {
      const nextChannel = nextServer?.channels?.find((item: any) => item.type === "TEXT") || nextServer?.channels?.[0];
      router.push(nextChannel ? `/app/servers/${serverId}/channels/${nextChannel.id}` : "/app/@me");
      router.refresh();
    }
  }, [serverId, channelId, router]);

  useEffect(() => { load(true); }, [load]);

  useEffect(() => {
    const socket = io({ withCredentials: true, transports: ["websocket", "polling"] });
    socketRef.current = socket;
    const refresh = (payload: any = {}) => {
      if (!payload.serverId || payload.serverId === serverId) load(true);
    };
    socket.on("server:updated", refresh);
    socket.on("server:changed", refresh);
    socket.on("server:channel:created", refresh);
    socket.on("server:channel:changed", refresh);
    socket.on("server:category:changed", refresh);
    socket.on("server:role:changed", refresh);
    socket.on("server:member:joined", refresh);
    socket.on("server:member:changed", refresh);
    socket.on("server:invite:changed", refresh);
    socket.on("server:deleted", ({ serverId: deletedId }: { serverId: string }) => {
      if (deletedId === serverId) {
        router.push("/app/@me");
        router.refresh();
      }
    });
    return () => { socket.disconnect(); };
  }, [serverId, load, router]);

  if (!server) return <div className="p-6 text-sm text-zinc-500">Lade Channel...</div>;
  if (missingChannel || !channel) return <div className="grid h-full place-items-center p-8 text-center text-zinc-500">Dieser Channel wurde entfernt. Du wirst gleich weitergeleitet...</div>;

  if (channel.type === "VOICE") {
    return <div className="grid h-full place-items-center p-8 text-center text-zinc-500">Voice-Channels sind als UI vorbereitet. Audio/WebRTC kommt in einer späteren Phase.</div>;
  }

  return <ChatPanel mode="channel" id={channelId} title={`# ${channel.name}`} subtitle={server.name} members={server.members} />;
}
