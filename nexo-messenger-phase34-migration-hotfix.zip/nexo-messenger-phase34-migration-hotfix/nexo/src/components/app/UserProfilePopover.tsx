"use client";

import { useEffect, useState } from "react";
import { io } from "socket.io-client";
import { useRouter } from "next/navigation";
import { Ban, Check, Flag, Loader2, MessageCircle, ShieldCheck, UserCheck, UserPlus, X } from "lucide-react";
import { Avatar } from "@/components/ui/Avatar";
import { Modal } from "@/components/ui/Modal";
import { useToast } from "@/hooks/use-toast";

type User = {
  id: string;
  username: string;
  displayName: string;
  avatarUrl?: string | null;
  avatarColor: string;
  bio?: string;
  status?: string;
  isAdmin?: boolean;
};

type Relationship = {
  self: boolean;
  friend: boolean;
  outgoingRequest?: { id: string } | null;
  incomingRequest?: { id: string } | null;
  blockedByMe: boolean;
  blockedMe: boolean;
};

export function UserProfilePopover({ user, compact = false }: { user: User; compact?: boolean }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [reportOpen, setReportOpen] = useState(false);
  const [reportReason, setReportReason] = useState("");
  const [reporting, setReporting] = useState(false);
  const [relationship, setRelationship] = useState<Relationship | null>(null);
  const [busy, setBusy] = useState<"dm" | "friend" | "block" | null>(null);
  const { toast } = useToast();

  async function loadRelationship() {
    const res = await fetch(`/api/users/${user.id}/relationship`, { cache: "no-store" });
    if (res.ok) setRelationship(await res.json());
  }

  useEffect(() => { if (open) void loadRelationship(); }, [open, user.id]);
  useEffect(() => {
    if (!open) return;
    const socket = io({ withCredentials: true, transports: ["websocket", "polling"] });
    const refresh = () => { void loadRelationship(); };
    socket.on("friend:request:new", refresh);
    socket.on("friend:request:updated", refresh);
    socket.on("friend:added", refresh);
    socket.on("friend:removed", refresh);
    socket.on("user:block:changed", refresh);
    return () => { socket.disconnect(); };
  }, [open, user.id]);

  async function openDm() {
    if (relationship?.self) return;
    setBusy("dm");
    const res = await fetch("/api/dms", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ userId: user.id }) });
    const result = await res.json().catch(() => ({}));
    setBusy(null);
    if (!res.ok) return toast({ type: "error", title: result.error || "DM konnte nicht geöffnet werden" });
    setOpen(false);
    if (result.state === "accepted" && result.thread?.id) router.push(`/app/@me?thread=${result.thread.id}`);
    else toast({ type: "info", title: "DM-Anfrage gesendet", description: "Der Chat öffnet sich, sobald die andere Person annimmt." });
  }

  async function toggleBlock() {
    setBusy("block");
    const method = relationship?.blockedByMe ? "DELETE" : "POST";
    const res = await fetch(`/api/users/${user.id}/block`, { method });
    const result = await res.json().catch(() => ({}));
    setBusy(null);
    if (!res.ok) return toast({ type: "error", title: result.error || "Blockieren fehlgeschlagen" });
    await loadRelationship();
    toast({ type: "success", title: method === "POST" ? "User blockiert" : "User entblockt" });
  }

  async function addFriend() {
    setBusy("friend");
    const res = await fetch("/api/friends/requests", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ userId: user.id }) });
    const result = await res.json().catch(() => ({}));
    setBusy(null);
    if (!res.ok) return toast({ type: "error", title: result.error || "Anfrage fehlgeschlagen" });
    await loadRelationship();
    toast({ type: "success", title: result.alreadyFriends ? "Ihr seid schon Freunde" : result.incomingPending ? "Anfrage von dieser Person vorhanden" : "Freundschaftsanfrage gesendet" });
  }

  async function acceptFriend() {
    if (!relationship?.incomingRequest?.id) return;
    setBusy("friend");
    const res = await fetch(`/api/friends/requests/${relationship.incomingRequest.id}`, { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ action: "accept" }) });
    const result = await res.json().catch(() => ({}));
    setBusy(null);
    if (!res.ok) return toast({ type: "error", title: result.error || "Anfrage konnte nicht angenommen werden" });
    await loadRelationship();
    toast({ type: "success", title: "Freundschaftsanfrage angenommen" });
  }

  async function sendReport() {
    const reason = reportReason.trim();
    if (!reason) return toast({ type: "warning", title: "Bitte gib einen Grund an." });
    setReporting(true);
    try {
      const res = await fetch("/api/reports", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ targetUserId: user.id, reason }) });
      toast({ type: res.ok ? "success" : "error", title: res.ok ? "Report gesendet" : "Report fehlgeschlagen" });
      if (res.ok) { setReportReason(""); setReportOpen(false); }
    } finally { setReporting(false); }
  }

  const isSelf = Boolean(relationship?.self);
  const friendLabel = relationship?.friend ? "Freunde" : relationship?.incomingRequest ? "Annehmen" : relationship?.outgoingRequest ? "Anfrage gesendet" : "Freund";
  const FriendIcon = relationship?.friend ? UserCheck : relationship?.incomingRequest ? Check : UserPlus;

  return (
    <div className="relative inline-flex">
      <button type="button" onClick={() => setOpen((value) => !value)} className="rounded-2xl focus:outline-none focus:ring-2 focus:ring-white/30"><Avatar user={user} size={compact ? "sm" : "md"} /></button>
      {open && (<><button type="button" aria-label="Profil schließen" className="fixed inset-0 z-30 cursor-default bg-transparent" onClick={() => setOpen(false)} /><div className="absolute right-0 top-12 z-40 w-80 overflow-hidden rounded-[2rem] border border-white/10 bg-[#070707] shadow-2xl shadow-black/50"><div className="h-20 bg-gradient-to-br from-white/20 to-transparent" /><div className="px-5 pb-5"><div className="-mt-8 mb-3 inline-flex rounded-3xl border border-white/10 bg-black p-1"><Avatar user={user} /></div><div className="flex items-start justify-between gap-3"><div className="min-w-0"><p className="truncate text-lg font-semibold tracking-[-.03em]">{user.displayName}</p><p className="text-sm text-zinc-500">@{user.username}</p></div>{user.isAdmin && <span className="inline-flex items-center gap-1 rounded-full border border-cyan-300/20 bg-cyan-400/10 px-2 py-1 text-[11px] text-cyan-100"><ShieldCheck size={12} /> Admin</span>}</div>{user.bio && <p className="mt-4 rounded-2xl border border-white/10 bg-white/[.035] p-3 text-sm leading-6 text-zinc-300">{user.bio}</p>}<p className="mt-3 text-xs text-zinc-500">Status: {(user.status || "online").toLowerCase().replaceAll("_", " ")}</p>{relationship?.blockedMe && <p className="mt-3 rounded-2xl border border-red-400/20 bg-red-500/10 px-3 py-2 text-xs text-red-100">Diese Person hat dich blockiert.</p>}<div className="mt-5 grid grid-cols-2 gap-2">{!isSelf && <button type="button" disabled={busy === "dm" || relationship?.blockedByMe || relationship?.blockedMe} onClick={openDm} className="soft-button inline-flex items-center justify-center gap-2 text-xs disabled:cursor-not-allowed disabled:opacity-50">{busy === "dm" ? <Loader2 size={14} className="animate-spin" /> : <MessageCircle size={14} />} DM</button>} {!isSelf && <button type="button" disabled={busy === "friend" || relationship?.friend || Boolean(relationship?.outgoingRequest)} onClick={() => relationship?.incomingRequest ? acceptFriend() : addFriend()} className="soft-button inline-flex items-center justify-center gap-2 text-xs disabled:cursor-not-allowed disabled:opacity-50">{busy === "friend" ? <Loader2 size={14} className="animate-spin" /> : <FriendIcon size={14} />} {friendLabel}</button>} {!isSelf && <button type="button" onClick={toggleBlock} disabled={busy === "block"} className="soft-button inline-flex items-center justify-center gap-2 text-xs text-red-100 disabled:opacity-50">{busy === "block" ? <Loader2 size={14} className="animate-spin" /> : relationship?.blockedByMe ? <X size={14} /> : <Ban size={14} />} {relationship?.blockedByMe ? "Entblocken" : "Blockieren"}</button>}<button type="button" disabled={isSelf} onClick={() => setReportOpen(true)} className="soft-button inline-flex items-center justify-center gap-2 text-xs disabled:opacity-50"><Flag size={14} /> Melden</button></div>{isSelf && <p className="mt-3 text-[11px] text-zinc-600">Das ist dein eigenes Profil.</p>}</div></div></>)}
      <Modal open={reportOpen} title="User melden" description="Beschreibe kurz, was passiert ist. Der Report landet im Admin-Panel." onClose={() => setReportOpen(false)} size="sm"><div className="space-y-4"><textarea value={reportReason} onChange={(event) => setReportReason(event.target.value)} className="field min-h-28 resize-none" maxLength={500} placeholder="Grund für die Meldung..." /><div className="flex justify-end gap-2"><button type="button" className="soft-button" onClick={() => setReportOpen(false)}>Abbrechen</button><button type="button" className="primary-button disabled:opacity-50" disabled={reporting || !reportReason.trim()} onClick={sendReport}>{reporting ? "Sende..." : "Report senden"}</button></div></div></Modal>
    </div>
  );
}
