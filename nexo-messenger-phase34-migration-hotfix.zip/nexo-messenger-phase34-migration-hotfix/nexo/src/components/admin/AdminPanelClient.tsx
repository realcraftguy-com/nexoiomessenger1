"use client";

import Link from "next/link";
import { FormEvent, useEffect, useRef, useState } from "react";
import { io, Socket } from "socket.io-client";
import {
  Activity,
  Archive,
  ArchiveRestore,
  Ban,
  ExternalLink,
  Loader2,
  Server,
  Shield,
  Sparkles,
  Ticket,
  Trash2,
  Users,
  XCircle,
} from "lucide-react";
import { Modal } from "@/components/ui/Modal";
import { Notice } from "@/components/ui/Notice";

type TicketTab = "active" | "open" | "answered" | "closed" | "archived" | "all";
type ReportStatus = "open" | "reviewing" | "resolved" | "rejected";

function isArchived(ticket: any) {
  return Boolean(ticket?.archivedAt);
}

function sortTickets(tickets: any[]) {
  return [...tickets].sort(
    (a, b) =>
      new Date(b.updatedAt || b.createdAt).getTime() -
      new Date(a.updatedAt || a.createdAt).getTime(),
  );
}

export function AdminPanelClient() {
  const [data, setData] = useState<any>(null);
  const [query, setQuery] = useState("");
  const [ticketTab, setTicketTab] = useState<TicketTab>("active");
  const [ticketSort, setTicketSort] = useState<
    "newest" | "oldest" | "priority"
  >("newest");
  const [logSort, setLogSort] = useState<"newest" | "oldest" | "action">(
    "newest",
  );
  const [reportFilter, setReportFilter] = useState<ReportStatus | "all">(
    "open",
  );
  const [selectedReport, setSelectedReport] = useState<any | null>(null);
  const [reportNote, setReportNote] = useState("");
  const [replyText, setReplyText] = useState<Record<string, string>>({});
  const [notice, setNotice] = useState<{
    type: "success" | "error";
    text: string;
  } | null>(null);
  const [passwordUser, setPasswordUser] = useState<any | null>(null);
  const [newPassword, setNewPassword] = useState("");
  const [savingPassword, setSavingPassword] = useState(false);
  const [banUser, setBanUser] = useState<any | null>(null);
  const [banReason, setBanReason] = useState("");
  const [savingBan, setSavingBan] = useState(false);
  const [closingTicket, setClosingTicket] = useState<any | null>(null);
  const [closeReason, setCloseReason] = useState("");
  const [savingClose, setSavingClose] = useState(false);
  const [cleanupOpen, setCleanupOpen] = useState(false);
  const [cleaning, setCleaning] = useState(false);
  const [archivingId, setArchivingId] = useState<string | null>(null);
  const [clearAction, setClearAction] = useState<
    null | "archived" | "closed" | "all" | "logs"
  >(null);
  const [health, setHealth] = useState<any>(null);
  const socketRef = useRef<Socket | null>(null);

  async function load(q = query) {
    const [res, healthRes] = await Promise.all([
      fetch(`/api/admin/overview?q=${encodeURIComponent(q)}`),
      fetch("/api/health", { cache: "no-store" }).catch(() => null),
    ]);
    if (res.ok) setData(await res.json());
    if (healthRes?.ok) setHealth(await healthRes.json());
    else
      setHealth({
        ok: false,
        database: "error",
        redis: "error",
        storage: "error",
      });
  }

  function mergeUser(updated: any) {
    setData((current: any) =>
      current
        ? {
            ...current,
            users: current.users.map((item: any) =>
              item.id === updated.id ? { ...item, ...updated } : item,
            ),
          }
        : current,
    );
  }

  function mergeTicket(updated: any) {
    setData((current: any) => {
      if (!current || !updated) return current;
      const exists = current.tickets.some(
        (item: any) => item.id === updated.id,
      );
      const tickets = exists
        ? current.tickets.map((item: any) =>
            item.id === updated.id ? updated : item,
          )
        : [updated, ...current.tickets];
      const sorted = sortTickets(tickets);
      return {
        ...current,
        tickets: sorted,
        stats: {
          ...current.stats,
          openTickets: sorted.filter(
            (ticket: any) => ticket.status !== "CLOSED" && !ticket.archivedAt,
          ).length,
        },
      };
    });
    socketRef.current?.emit("ticket:join", { ticketId: updated.id });
  }

  useEffect(() => {
    const socket = io({
      withCredentials: true,
      transports: ["websocket", "polling"],
    });
    socketRef.current = socket;
    socket.on("ticket:message", ({ ticketId, message }) => {
      setData((current: any) =>
        current
          ? {
              ...current,
              tickets: current.tickets.map((ticket: any) => {
                if (
                  ticket.id !== ticketId ||
                  ticket.messages.some((item: any) => item.id === message.id)
                )
                  return ticket;
                return {
                  ...ticket,
                  messages: [...ticket.messages, message],
                  status: message.isStaff ? "ANSWERED" : "OPEN",
                  updatedAt: new Date().toISOString(),
                };
              }),
            }
          : current,
      );
    });
    socket.on("ticket:created", ({ ticket }) => mergeTicket(ticket));
    socket.on("ticket:updated", ({ ticket }) => mergeTicket(ticket));
    socket.on("ticket:closed", ({ ticket }) => mergeTicket(ticket));
    socket.on("admin:ticket:archived", ({ ticket }) => mergeTicket(ticket));
    socket.on("admin:tickets:cleanup", ({ tickets }) => {
      if (Array.isArray(tickets))
        tickets.forEach((ticket: any) => mergeTicket(ticket));
    });
    socket.on("admin:tickets:archived", () => {
      void load();
    });
    socket.on("admin:audit:archived", () => {
      setData((current: any) => (current ? { ...current, logs: [] } : current));
    });
    socket.on("admin:user:updated", ({ user }) => mergeUser(user));
    socket.on("admin:server:created", () => load(query));
    socket.on("admin:server:updated", () => load(query));
    socket.on("admin:server:deleted", () => load(query));
    socket.on("admin:report:new", () => load(query));
    socket.on("admin:report:updated", ({ report }) => {
      setData((current: any) =>
        current
          ? {
              ...current,
              reports: current.reports.map((item: any) =>
                item.id === report.id ? report : item,
              ),
            }
          : current,
      );
    });
    socket.on("admin:overview:refresh", () => load(query));
    return () => {
      socket.disconnect();
    };
  }, [query]);

  useEffect(() => {
    load("");
  }, []);

  useEffect(() => {
    data?.tickets?.forEach((ticket: any) =>
      socketRef.current?.emit("ticket:join", { ticketId: ticket.id }),
    );
  }, [data?.tickets?.length]);

  async function updateReport(
    reportId: string,
    status: ReportStatus,
    note?: string,
  ) {
    const res = await fetch(`/api/reports/${reportId}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ status, note }),
    });
    if (!res.ok) {
      setNotice({
        type: "error",
        text: "Report konnte nicht aktualisiert werden.",
      });
      return;
    }
    const result = await res.json().catch(() => ({}));
    setData((current: any) =>
      current
        ? {
            ...current,
            reports: current.reports.map((item: any) =>
              item.id === reportId ? { ...item, ...result.report } : item,
            ),
          }
        : current,
    );
    if (selectedReport?.id === reportId)
      setSelectedReport((current: any) =>
        current ? { ...current, ...result.report } : current,
      );
    setReportNote("");
    setNotice({ type: "success", text: "Report aktualisiert." });
  }

  async function moderateReportedMessage(reportId: string) {
    if (!window.confirm("Gemeldete Nachricht wirklich löschen/moderieren?"))
      return;
    const res = await fetch(`/api/reports/${reportId}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        action: "delete_message",
        status: "resolved",
        note: reportNote || "Nachricht aus Report heraus moderiert.",
      }),
    });
    const result = await res.json().catch(() => ({}));
    if (!res.ok)
      return setNotice({
        type: "error",
        text: result.error || "Nachricht konnte nicht moderiert werden.",
      });
    setData((current: any) =>
      current
        ? {
            ...current,
            reports: current.reports.map((item: any) =>
              item.id === reportId ? { ...item, ...result.report } : item,
            ),
          }
        : current,
    );
    setSelectedReport((current: any) =>
      current ? { ...current, ...result.report } : current,
    );
    setReportNote("");
    setNotice({
      type: "success",
      text: "Nachricht wurde moderiert und Report gelöst.",
    });
  }

  async function search(event: FormEvent) {
    event.preventDefault();
    load(query);
  }

  async function updateUser(userId: string, body: any) {
    setNotice(null);
    const res = await fetch(`/api/admin/users/${userId}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    const result = await res.json().catch(() => ({}));
    if (!res.ok) {
      setNotice({
        type: "error",
        text: result.error || "Aktion fehlgeschlagen.",
      });
      return false;
    }
    setNotice({ type: "success", text: "Änderung gespeichert." });
    load();
    return true;
  }

  function openPasswordReset(user: any) {
    setPasswordUser(user);
    setNewPassword("");
    setNotice(null);
  }

  function openBanModal(user: any) {
    setBanUser(user);
    setBanReason(user.banReason || "");
    setNotice(null);
  }

  async function resetPassword(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!passwordUser) return;
    if (newPassword.length < 8)
      return setNotice({
        type: "error",
        text: "Das neue Passwort braucht mindestens 8 Zeichen.",
      });
    setSavingPassword(true);
    setNotice(null);

    const socket = socketRef.current;
    if (!socket?.connected) {
      const ok = await updateUser(passwordUser.id, { newPassword });
      setSavingPassword(false);
      if (ok) {
        setPasswordUser(null);
        setNotice({
          type: "success",
          text: "Passwort geändert. Alte Sitzungen sind ungültig.",
        });
      }
      return;
    }

    socket.emit(
      "admin:user:password-reset",
      { userId: passwordUser.id, newPassword },
      async (result: any) => {
        setSavingPassword(false);
        if (result?.error || !result?.ok) {
          setNotice({
            type: "error",
            text:
              result?.error || "Passwort konnte nicht zurückgesetzt werden.",
          });
          return;
        }
        mergeUser(result.user);
        setPasswordUser(null);
        setNewPassword("");
        setNotice({
          type: "success",
          text: "Passwort geändert. Der User wurde überall automatisch ausgeloggt.",
        });
      },
    );
  }

  async function banSelectedUser(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!banUser) return;
    const reason = banReason.trim();
    if (reason.length < 3)
      return setNotice({
        type: "error",
        text: "Bitte gib einen echten Sperrgrund ein.",
      });
    setSavingBan(true);
    setNotice(null);

    const socket = socketRef.current;
    if (!socket?.connected) {
      setSavingBan(false);
      const ok = await updateUser(banUser.id, {
        isBanned: true,
        banReason: reason,
      });
      if (ok) setBanUser(null);
      return;
    }

    socket.emit(
      "admin:user:ban",
      { userId: banUser.id, reason },
      async (result: any) => {
        setSavingBan(false);
        if (result?.error || !result?.ok) {
          const ok = await updateUser(banUser.id, {
            isBanned: true,
            banReason: reason,
          });
          if (ok) setBanUser(null);
          return;
        }
        mergeUser(result.user);
        setBanUser(null);
        setNotice({ type: "success", text: "User wurde gesperrt." });
      },
    );
  }

  async function unbanUser(target: any) {
    setNotice(null);
    const socket = socketRef.current;
    if (!socket?.connected) {
      await updateUser(target.id, { isBanned: false });
      return;
    }
    socket.emit(
      "admin:user:unban",
      { userId: target.id },
      async (result: any) => {
        if (result?.error || !result?.ok) {
          await updateUser(target.id, { isBanned: false });
          return;
        }
        mergeUser(result.user);
        setNotice({ type: "success", text: "User wurde entsperrt." });
      },
    );
  }

  async function reply(ticketId: string) {
    const content = replyText[ticketId]?.trim();
    if (!content) return;
    setNotice(null);
    setReplyText((items) => ({ ...items, [ticketId]: "" }));
    socketRef.current?.emit(
      "ticket:message",
      { ticketId, content },
      (result: any) => {
        if (result?.error) {
          setReplyText((items) => ({ ...items, [ticketId]: content }));
          setNotice({
            type: "error",
            text: result.error || "Antwort fehlgeschlagen.",
          });
          return;
        }
        setNotice({ type: "success", text: "Antwort gesendet." });
      },
    );
  }

  function openCloseTicket(ticket: any) {
    setClosingTicket(ticket);
    setCloseReason("");
    setNotice(null);
  }

  async function closeTicketWithReason(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!closingTicket) return;
    const reason = closeReason.trim();
    if (reason.length < 3)
      return setNotice({
        type: "error",
        text: "Bitte gib einen Grund fürs Schließen an.",
      });
    setSavingClose(true);
    const socket = socketRef.current;

    if (socket?.connected) {
      socket.emit(
        "ticket:close",
        { ticketId: closingTicket.id, reason },
        async (result: any) => {
          setSavingClose(false);
          if (result?.error || !result?.ok) {
            setNotice({
              type: "error",
              text: result?.error || "Schließen fehlgeschlagen.",
            });
            return;
          }
          setClosingTicket(null);
          setNotice({
            type: "success",
            text: "Ticket wurde mit Grund geschlossen.",
          });
          mergeTicket(result.ticket);
        },
      );
      return;
    }

    const res = await fetch(`/api/tickets/${closingTicket.id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ reason }),
    });
    const result = await res.json().catch(() => ({}));
    setSavingClose(false);
    if (!res.ok)
      return setNotice({
        type: "error",
        text: result.error || "Schließen fehlgeschlagen.",
      });
    setClosingTicket(null);
    setNotice({ type: "success", text: "Ticket wurde mit Grund geschlossen." });
    mergeTicket(result.ticket);
  }

  async function archiveTicket(ticket: any, archive: boolean) {
    setArchivingId(ticket.id);
    setNotice(null);
    const res = await fetch(`/api/admin/tickets/${ticket.id}/archive`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ archive }),
    });
    const result = await res.json().catch(() => ({}));
    setArchivingId(null);
    if (!res.ok)
      return setNotice({
        type: "error",
        text: result.error || "Ticket konnte nicht verschoben werden.",
      });
    mergeTicket(result.ticket);
    socketRef.current?.emit("ticket:sync", { ticketId: result.ticket.id });
    setNotice({
      type: "success",
      text: archive
        ? "Ticket wurde ins Archiv verschoben."
        : "Ticket wurde wiederhergestellt.",
    });
  }

  async function cleanupClosedTickets(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setCleaning(true);
    setNotice(null);
    const res = await fetch("/api/admin/tickets/cleanup", { method: "PATCH" });
    const result = await res.json().catch(() => ({}));
    setCleaning(false);
    if (!res.ok)
      return setNotice({
        type: "error",
        text: result.error || "Aufräumen fehlgeschlagen.",
      });
    setCleanupOpen(false);
    setTicketTab("archived");
    await load();
    setNotice({
      type: "success",
      text: `${result.archivedCount || 0} geschlossene Tickets wurden ins Archiv verschoben.`,
    });
  }

  async function clearTickets(mode: "archived" | "closed" | "all") {
    const res = await fetch(`/api/admin/tickets/clear?mode=${mode}`, {
      method: "DELETE",
    });
    const result = await res.json().catch(() => ({}));
    if (!res.ok)
      return setNotice({
        type: "error",
        text: result.error || "Tickets konnten nicht gelöscht werden.",
      });
    setNotice({
      type: "success",
      text: `${result.count || 0} Ticket(s) gelöscht.`,
    });
    setClearAction(null);
    load();
  }

  async function clearLogs() {
    const res = await fetch(`/api/admin/logs/clear`, { method: "DELETE" });
    const result = await res.json().catch(() => ({}));
    if (!res.ok)
      return setNotice({
        type: "error",
        text: result.error || "Audit Log konnte nicht archiviert werden.",
      });
    setNotice({
      type: "success",
      text: `${result.count || 0} Log-Einträge gelöscht.`,
    });
    setClearAction(null);
    load();
  }

  if (!data)
    return (
      <div className="p-6 text-sm text-zinc-500">Lade Admin-Dashboard...</div>
    );

  const allTickets = data.tickets || [];
  const counts = {
    active: allTickets.filter(
      (ticket: any) => !isArchived(ticket) && ticket.status !== "CLOSED",
    ).length,
    open: allTickets.filter(
      (ticket: any) => !isArchived(ticket) && ticket.status === "OPEN",
    ).length,
    answered: allTickets.filter(
      (ticket: any) => !isArchived(ticket) && ticket.status === "ANSWERED",
    ).length,
    closed: allTickets.filter(
      (ticket: any) => !isArchived(ticket) && ticket.status === "CLOSED",
    ).length,
    archived: allTickets.filter((ticket: any) => isArchived(ticket)).length,
    all: allTickets.length,
  };
  const ticketTabs: { id: TicketTab; label: string; count: number }[] = [
    { id: "active", label: "Aktiv", count: counts.active },
    { id: "open", label: "Offen", count: counts.open },
    { id: "answered", label: "Beantwortet", count: counts.answered },
    { id: "closed", label: "Geschlossen", count: counts.closed },
    { id: "archived", label: "Archiv", count: counts.archived },
    { id: "all", label: "Alle", count: counts.all },
  ];
  const sortedForView = [...allTickets].sort((a: any, b: any) => {
    if (ticketSort === "oldest")
      return (
        new Date(a.updatedAt || a.createdAt).getTime() -
        new Date(b.updatedAt || b.createdAt).getTime()
      );
    if (ticketSort === "priority") {
      const rank: Record<string, number> = {
        URGENT: 4,
        HIGH: 3,
        NORMAL: 2,
        LOW: 1,
      };
      return (rank[b.priority] || 0) - (rank[a.priority] || 0);
    }
    return (
      new Date(b.updatedAt || b.createdAt).getTime() -
      new Date(a.updatedAt || a.createdAt).getTime()
    );
  });

  const visibleTickets = sortedForView.filter((ticket: any) => {
    if (ticketTab === "active")
      return !isArchived(ticket) && ticket.status !== "CLOSED";
    if (ticketTab === "open")
      return !isArchived(ticket) && ticket.status === "OPEN";
    if (ticketTab === "answered")
      return !isArchived(ticket) && ticket.status === "ANSWERED";
    if (ticketTab === "closed")
      return !isArchived(ticket) && ticket.status === "CLOSED";
    if (ticketTab === "archived") return isArchived(ticket);
    return true;
  });

  const sortedLogs = [...(data.logs || [])].sort((a: any, b: any) => {
    if (logSort === "oldest")
      return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
    if (logSort === "action")
      return String(a.action).localeCompare(String(b.action));
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
  });

  const allReports = data.reports || [];
  const reportStatuses: { id: ReportStatus | "all"; label: string }[] = [
    { id: "open", label: "Offen" },
    { id: "reviewing", label: "In Prüfung" },
    { id: "resolved", label: "Gelöst" },
    { id: "rejected", label: "Abgelehnt" },
    { id: "all", label: "Alle" },
  ];
  const reportCounts = Object.fromEntries(
    reportStatuses.map((status) => [
      status.id,
      status.id === "all"
        ? allReports.length
        : allReports.filter((report: any) => report.status === status.id)
            .length,
    ]),
  );
  const visibleReports = allReports.filter(
    (report: any) => reportFilter === "all" || report.status === reportFilter,
  );

  const statCards = [
    { icon: Users, label: "User", value: data.stats.users },
    { icon: Server, label: "Server", value: data.stats.servers },
    { icon: Activity, label: "Messages", value: data.stats.messages },
    { icon: Ticket, label: "Aktive Tickets", value: counts.active },
    {
      icon: Sparkles,
      label: "Offene Reports",
      value: data.stats.openReports || 0,
    },
  ];

  return (
    <div className="nexo-scrollbar h-full overflow-y-auto p-6">
      <div className="mb-6 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Shield />
          <div>
            <h2 className="text-2xl font-semibold tracking-[-.04em]">
              Admin Panel
            </h2>
            <p className="text-sm text-zinc-500">
              Sichere Verwaltung für berechtigte Accounts.
            </p>
          </div>
        </div>
        {notice && (
          <div className="max-w-sm">
            <Notice type={notice.type}>{notice.text}</Notice>
          </div>
        )}
      </div>
      <div className="mb-6 grid gap-3 md:grid-cols-5">
        {statCards.map((card) => (
          <div
            key={card.label}
            className="rounded-3xl border border-white/10 bg-white/[.035] p-5"
          >
            <card.icon size={18} />
            <p className="mt-4 text-2xl font-semibold">{card.value}</p>
            <p className="text-xs text-zinc-500">{card.label}</p>
          </div>
        ))}
      </div>
      <section className="panel mb-6 p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="font-semibold">System Health</h3>
            <p className="text-xs text-zinc-500">
              Datenbank, Redis und privater Storage werden direkt geprüft.
            </p>
          </div>
          <button
            type="button"
            onClick={() => load()}
            className="soft-button px-3 py-2 text-xs"
          >
            Neu prüfen
          </button>
        </div>
        <div className="mt-4 grid gap-2 sm:grid-cols-4">
          {["database", "redis", "storage", "version"].map((key) => (
            <div
              key={key}
              className="rounded-2xl border border-white/10 bg-black/20 p-3"
            >
              <p className="text-[11px] uppercase tracking-[.2em] text-zinc-600">
                {key}
              </p>
              <p
                className={
                  health?.[key] === "ok" || key === "version"
                    ? "text-sm text-emerald-200"
                    : "text-sm text-red-200"
                }
              >
                {health?.[key] || "lädt"}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section className="panel mb-6 p-5">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Sparkles size={18} />
            <div>
              <h3 className="font-semibold">Reports / Meldungen</h3>
              <p className="text-xs text-zinc-500">
                Meldungen prüfen, Kontext sehen und Status mit Audit-Log ändern.
              </p>
            </div>
          </div>
          <div className="flex gap-2 overflow-x-auto pb-1">
            {reportStatuses.map((status) => (
              <button
                key={status.id}
                type="button"
                onClick={() => setReportFilter(status.id)}
                className={`shrink-0 rounded-2xl border px-3 py-2 text-xs transition ${reportFilter === status.id ? "border-white/30 bg-white text-black" : "border-white/10 bg-white/[.03] text-zinc-400 hover:text-white"}`}
              >
                {status.label}{" "}
                <span className="opacity-60">
                  {reportCounts[status.id] || 0}
                </span>
              </button>
            ))}
          </div>
        </div>
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {visibleReports.length === 0 && (
            <div className="rounded-3xl border border-dashed border-white/10 bg-black/20 p-6 text-sm text-zinc-500">
              Keine Reports in diesem Filter.
            </div>
          )}
          {visibleReports.map((report: any) => {
            const reportedMessage = report.message || report.dmMessage;
            return (
              <div
                key={report.id}
                className="rounded-3xl border border-white/10 bg-black/20 p-4"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold text-white">
                      {report.reason}
                    </p>
                    <p className="mt-1 text-xs text-zinc-500">
                      {report.status} ·{" "}
                      {new Date(report.createdAt).toLocaleString("de-DE")}
                    </p>
                  </div>
                  <span className="rounded-full border border-white/10 bg-white/[.04] px-2 py-1 text-[10px] uppercase tracking-[.12em] text-zinc-400">
                    {report.status}
                  </span>
                </div>
                <div className="mt-3 space-y-1 text-xs text-zinc-500">
                  <p>
                    Reporter:{" "}
                    <span className="text-zinc-300">
                      {report.reporter?.displayName || report.reporterId}
                    </span>
                  </p>
                  <p>
                    Ziel:{" "}
                    <span className="text-zinc-300">
                      {report.targetUser?.displayName ||
                        report.targetUserId ||
                        "Nachricht"}
                    </span>
                  </p>
                  {reportedMessage && (
                    <p className="line-clamp-2 rounded-2xl border border-white/10 bg-white/[.03] px-3 py-2 text-zinc-400">
                      {reportedMessage.deletedAt
                        ? "Nachricht wurde gelöscht"
                        : reportedMessage.content ||
                          "Leere Nachricht/Attachment"}
                    </p>
                  )}
                  {report.message?.channel && (
                    <p>
                      Kontext: #{report.message.channel.name} ·{" "}
                      {report.message.channel.server?.name ||
                        report.server?.name ||
                        "Server"}
                      {report.message.channel.isPrivate ? " · privat" : ""}
                    </p>
                  )}
                  {report.dmMessage && <p>Kontext: Direktnachricht</p>}
                </div>
                <div className="mt-3 flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedReport(report);
                      setReportNote("");
                    }}
                    className="soft-button px-3 py-1.5 text-[11px]"
                  >
                    Details
                  </button>
                  {(
                    ["reviewing", "resolved", "rejected"] as ReportStatus[]
                  ).map((status) => (
                    <button
                      key={status}
                      type="button"
                      onClick={() => updateReport(report.id, status)}
                      className="soft-button px-3 py-1.5 text-[11px]"
                    >
                      {status}
                    </button>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </section>
      <div className="grid gap-6 xl:grid-cols-[1fr_1.2fr]">
        <section className="panel p-5">
          <div className="mb-4 flex items-center justify-between gap-3">
            <h3 className="font-semibold">User verwalten</h3>
            <form onSubmit={search} className="flex gap-2">
              <input
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                className="field py-2"
                placeholder="Suchen"
              />
              <button className="soft-button">Suchen</button>
            </form>
          </div>
          <div className="space-y-2">
            {data.users.map((user: any) => (
              <div
                key={user.id}
                className="rounded-3xl border border-white/10 bg-black/20 p-4"
              >
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <p className="font-medium">
                      {user.displayName}{" "}
                      <span className="text-zinc-500">@{user.username}</span>
                    </p>
                    <p className="text-xs text-zinc-500">
                      {user.email} · {user.status}
                    </p>
                    {user.isBanned && (
                      <p className="mt-2 rounded-2xl border border-red-500/20 bg-red-500/10 px-3 py-2 text-xs text-red-100">
                        Gesperrt: {user.banReason || "Kein Grund angegeben"}
                      </p>
                    )}
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {user.isBanned ? (
                      <button
                        onClick={() => unbanUser(user)}
                        className="soft-button"
                      >
                        Entsperren
                      </button>
                    ) : (
                      <button
                        onClick={() => openBanModal(user)}
                        className="soft-button text-red-100 hover:border-red-400/30 hover:bg-red-500/10"
                      >
                        <Ban size={15} /> Sperren
                      </button>
                    )}
                    <button
                      onClick={() => openPasswordReset(user)}
                      className="soft-button"
                    >
                      Passwort reset
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
        <section className="panel overflow-hidden p-5">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="font-semibold">Tickets</h3>
              <p className="text-xs text-zinc-500">
                Sortiert nach Status, damit alte Sachen nicht alles zumüllen.
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              {[
                { id: "newest", label: "Neueste" },
                { id: "oldest", label: "Älteste" },
                { id: "priority", label: "Priorität" },
              ].map((sort: any) => (
                <button
                  key={sort.id}
                  onClick={() => setTicketSort(sort.id)}
                  className={`rounded-2xl border px-3 py-2 text-xs transition ${ticketSort === sort.id ? "border-white/30 bg-white text-black" : "border-white/10 bg-white/[.03] text-zinc-400 hover:text-white"}`}
                >
                  {sort.label}
                </button>
              ))}
              <button
                onClick={() => setClearAction("all")}
                className="soft-button text-xs"
              >
                <Trash2 size={14} /> Alle archivieren
              </button>
              <button
                onClick={() => setClearAction("closed")}
                className="soft-button text-xs"
              >
                <Trash2 size={14} /> Geschlossene löschen
              </button>
              <button
                onClick={() => setClearAction("all")}
                className="soft-button text-xs text-red-100"
              >
                <Trash2 size={14} /> Alle löschen
              </button>
            </div>
            <button
              onClick={() => setCleanupOpen(true)}
              className="soft-button text-zinc-200 hover:border-white/20 hover:bg-white/[.08]"
            >
              <Sparkles size={15} /> Aufräumen
            </button>
          </div>
          <div className="mb-4 flex gap-2 overflow-x-auto pb-1">
            {ticketTabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setTicketTab(tab.id)}
                className={`shrink-0 rounded-2xl border px-3 py-2 text-xs transition ${ticketTab === tab.id ? "border-white/30 bg-white text-black" : "border-white/10 bg-white/[.03] text-zinc-400 hover:bg-white/[.07] hover:text-white"}`}
              >
                {tab.label} <span className="ml-1 opacity-60">{tab.count}</span>
              </button>
            ))}
          </div>
          <div className="nexo-scrollbar max-h-[720px] space-y-3 overflow-y-auto pr-1">
            {visibleTickets.length === 0 && (
              <div className="rounded-3xl border border-dashed border-white/10 bg-black/20 p-8 text-center text-sm text-zinc-500">
                In diesem Tab ist alles sauber. Keine Tickets gefunden.
              </div>
            )}
            {visibleTickets.map((ticket: any) => (
              <div
                key={ticket.id}
                className={`rounded-3xl border p-4 ${isArchived(ticket) ? "border-white/5 bg-white/[.015] opacity-75" : "border-white/10 bg-black/20"}`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="truncate font-medium">{ticket.title}</p>
                      {isArchived(ticket) && (
                        <span className="rounded-full border border-white/10 px-2 py-1 text-[10px] text-zinc-500">
                          Archiviert
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-zinc-500">
                      von {ticket.user.displayName} · {ticket.status} ·{" "}
                      {ticket.priority}
                    </p>
                    {ticket.closeReason && (
                      <p className="mt-2 rounded-2xl border border-red-400/20 bg-red-500/10 px-3 py-2 text-xs text-red-100">
                        Grund: {ticket.closeReason}
                      </p>
                    )}
                  </div>
                  <div className="flex shrink-0 flex-wrap justify-end gap-2">
                    <Link
                      href={`/admin/ticket/${ticket.id}`}
                      className="soft-button"
                    >
                      <ExternalLink size={15} /> Öffnen
                    </Link>
                    {ticket.status !== "CLOSED" && !isArchived(ticket) && (
                      <button
                        onClick={() => openCloseTicket(ticket)}
                        className="soft-button text-red-100"
                      >
                        <XCircle size={15} /> Schließen
                      </button>
                    )}
                    {ticket.status === "CLOSED" && !isArchived(ticket) && (
                      <button
                        disabled={archivingId === ticket.id}
                        onClick={() => archiveTicket(ticket, true)}
                        className="soft-button"
                      >
                        <Archive size={15} /> Archivieren
                      </button>
                    )}
                    {isArchived(ticket) && (
                      <button
                        disabled={archivingId === ticket.id}
                        onClick={() => archiveTicket(ticket, false)}
                        className="soft-button"
                      >
                        <ArchiveRestore size={15} /> Wiederherstellen
                      </button>
                    )}
                  </div>
                </div>
                {ticketTab !== "archived" && (
                  <div className="mt-3 max-h-48 space-y-2 overflow-y-auto pr-2">
                    {ticket.messages.slice(-4).map((message: any) => (
                      <div
                        key={message.id}
                        className="rounded-2xl bg-white/[.04] px-3 py-2 text-sm text-zinc-300"
                      >
                        <b>{message.author?.displayName || "User"}:</b>{" "}
                        {message.content}
                        {message.attachments?.length ? (
                          <p className="mt-1 text-xs text-zinc-500">
                            {message.attachments.length} Datei(en) angehängt
                          </p>
                        ) : null}
                      </div>
                    ))}
                  </div>
                )}
                {ticket.status !== "CLOSED" && !isArchived(ticket) && (
                  <div className="mt-3 flex gap-2">
                    <input
                      className="field py-2"
                      value={replyText[ticket.id] || ""}
                      onChange={(event) =>
                        setReplyText((items) => ({
                          ...items,
                          [ticket.id]: event.target.value,
                        }))
                      }
                      placeholder="Admin-Antwort..."
                    />
                    <button
                      onClick={() => reply(ticket.id)}
                      className="primary-button"
                    >
                      Senden
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>
      </div>
      <section className="panel mt-6 p-5">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <h3 className="font-semibold">Server & Audit Logs</h3>
          <div className="flex flex-wrap gap-2">
            {[
              { id: "newest", label: "Logs neu" },
              { id: "oldest", label: "Logs alt" },
              { id: "action", label: "Aktion" },
            ].map((sort: any) => (
              <button
                key={sort.id}
                onClick={() => setLogSort(sort.id)}
                className={`rounded-2xl border px-3 py-2 text-xs transition ${logSort === sort.id ? "border-white/30 bg-white text-black" : "border-white/10 bg-white/[.03] text-zinc-400 hover:text-white"}`}
              >
                {sort.label}
              </button>
            ))}
            <button
              onClick={() => setClearAction("logs")}
              className="soft-button text-xs"
            >
              <Trash2 size={14} /> Audit Log archivieren
            </button>
          </div>
        </div>
        <div className="grid gap-4 lg:grid-cols-2">
          <div className="space-y-2">
            {data.servers.map((server: any) => (
              <div
                key={server.id}
                className="rounded-2xl border border-white/10 bg-white/[.03] p-3 text-sm"
              >
                <b>{server.name}</b>
                <p className="text-xs text-zinc-500">
                  {server._count.members} Mitglieder · {server._count.channels}{" "}
                  Channels
                </p>
              </div>
            ))}
          </div>
          <div className="space-y-2">
            {sortedLogs.map((log: any) => (
              <div
                key={log.id}
                className="rounded-2xl border border-white/10 bg-white/[.03] p-3 text-sm"
              >
                <b>{log.action}</b>
                <p className="text-xs text-zinc-500">
                  {log.actor?.displayName || "System"} ·{" "}
                  {new Date(log.createdAt).toLocaleString("de-DE")}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <Modal
        open={Boolean(selectedReport)}
        onClose={() => setSelectedReport(null)}
        title="Report Details"
        description={
          selectedReport ? `Status: ${selectedReport.status}` : undefined
        }
      >
        {selectedReport && (
          <div className="space-y-4">
            <div className="rounded-3xl border border-white/10 bg-white/[.035] p-4 text-sm leading-6 text-zinc-300">
              <p>
                <b>Grund:</b> {selectedReport.reason}
              </p>
              <p>
                <b>Reporter:</b>{" "}
                {selectedReport.reporter?.displayName ||
                  selectedReport.reporterId}
              </p>
              <p>
                <b>Zieluser:</b>{" "}
                {selectedReport.targetUser?.displayName ||
                  selectedReport.targetUserId ||
                  "-"}
              </p>
              {selectedReport.message?.channel && (
                <p>
                  <b>Channel:</b> #{selectedReport.message.channel.name} ·{" "}
                  {selectedReport.message.channel.server?.name}
                  {selectedReport.message.channel.isPrivate ? " · privat" : ""}
                </p>
              )}
              {selectedReport.dmMessage && (
                <p>
                  <b>Kontext:</b> Direktnachricht
                </p>
              )}
            </div>
            {(selectedReport.message || selectedReport.dmMessage) && (
              <div className="rounded-3xl border border-white/10 bg-black/30 p-4">
                <p className="text-xs uppercase tracking-[.18em] text-zinc-600">
                  Gemeldete Nachricht
                </p>
                <p className="mt-2 whitespace-pre-wrap break-words text-sm text-zinc-300">
                  {(selectedReport.message || selectedReport.dmMessage)
                    .deletedAt
                    ? "Diese Nachricht wurde bereits gelöscht."
                    : (selectedReport.message || selectedReport.dmMessage)
                        .content || "Nur Attachment/kein Text"}
                </p>
              </div>
            )}
            <div className="rounded-3xl border border-white/10 bg-black/30 p-4">
              <div className="mb-3 flex items-center justify-between gap-3">
                <p className="text-xs uppercase tracking-[.18em] text-zinc-600">
                  Interne Admin-Notizen
                </p>
                <span className="text-xs text-zinc-600">nur Admins</span>
              </div>
              {(!selectedReport.notes || selectedReport.notes.length === 0) && (
                <p className="text-sm text-zinc-500">Noch keine Notizen.</p>
              )}
              <div className="space-y-2">
                {(selectedReport.notes || []).map((note: any) => (
                  <div
                    key={note.id}
                    className="rounded-2xl border border-white/10 bg-white/[.03] p-3 text-sm"
                  >
                    <p className="whitespace-pre-wrap break-words text-zinc-300">
                      {note.note}
                    </p>
                    <p className="mt-2 text-xs text-zinc-600">
                      {note.admin?.displayName || "Admin"} ·{" "}
                      {new Date(note.createdAt).toLocaleString("de-DE")}
                    </p>
                  </div>
                ))}
              </div>
            </div>
            <label className="space-y-2 block">
              <span className="label">Neue interne Notiz</span>
              <textarea
                value={reportNote}
                onChange={(event) => setReportNote(event.target.value)}
                className="field min-h-24 resize-none"
                maxLength={1000}
                placeholder="Kurz notieren, was geprüft/geändert wurde..."
              />
            </label>
            <div className="flex flex-wrap justify-between gap-3">
              <div className="flex flex-wrap gap-2">
                {(
                  [
                    "open",
                    "reviewing",
                    "resolved",
                    "rejected",
                  ] as ReportStatus[]
                ).map((status) => (
                  <button
                    key={status}
                    type="button"
                    onClick={() =>
                      updateReport(selectedReport.id, status, reportNote)
                    }
                    className="soft-button px-3 py-2 text-xs"
                  >
                    {status}
                  </button>
                ))}
              </div>
              {(selectedReport.message || selectedReport.dmMessage) && (
                <button
                  type="button"
                  onClick={() => moderateReportedMessage(selectedReport.id)}
                  className="soft-button border-red-400/20 text-red-100"
                >
                  <Trash2 size={14} /> Nachricht löschen
                </button>
              )}
              {selectedReport.targetUser && (
                <button
                  type="button"
                  onClick={() => openBanModal(selectedReport.targetUser)}
                  className="soft-button border-red-400/20 text-red-100"
                >
                  <Ban size={14} /> Zieluser sperren
                </button>
              )}
            </div>
          </div>
        )}
      </Modal>

      <Modal
        open={Boolean(clearAction)}
        onClose={() => setClearAction(null)}
        title="Tickets archivieren?"
        description="Diese Aktion verschiebt Tickets ins Archiv statt sie hart aus der Datenbank zu löschen."
        size="sm"
      >
        <div className="space-y-4">
          <div className="rounded-3xl border border-red-500/20 bg-red-500/10 p-4 text-sm leading-6 text-red-100">
            {clearAction === "logs"
              ? "Der Audit Log wird archiviert und verschwindet aus der Standardansicht."
              : clearAction === "closed"
                ? "Alle geschlossenen Tickets werden archiviert."
                : clearAction === "all"
                  ? "Alle nicht archivierten Tickets werden archiviert."
                  : "Alle nicht archivierten Tickets werden archiviert."}
          </div>
          <div className="flex justify-end gap-3">
            <button
              type="button"
              onClick={() => setClearAction(null)}
              className="soft-button"
            >
              Abbrechen
            </button>
            <button
              type="button"
              onClick={() => {
                if (clearAction === "logs") clearLogs();
                else if (clearAction) clearTickets(clearAction);
              }}
              className="primary-button bg-red-100 text-red-950 hover:bg-red-200"
            >
              Archivieren
            </button>
          </div>
        </div>
      </Modal>
      <Modal
        open={cleanupOpen}
        onClose={() => !cleaning && setCleanupOpen(false)}
        title="Tickets aufräumen"
        description="Geschlossene Tickets werden aus der normalen Liste entfernt und landen im Archiv. Sie bleiben gespeichert und können wiederhergestellt werden."
      >
        <form onSubmit={cleanupClosedTickets} className="space-y-4">
          <div className="rounded-3xl border border-white/10 bg-white/[.04] p-4 text-sm leading-6 text-zinc-300">
            Das ist perfekt für alte erledigte Tickets. Offene und beantwortete
            Tickets werden nicht angefasst.
          </div>
          <div className="flex justify-end gap-3">
            <button
              type="button"
              onClick={() => setCleanupOpen(false)}
              disabled={cleaning}
              className="soft-button"
            >
              Abbrechen
            </button>
            <button
              disabled={cleaning}
              className="primary-button inline-flex items-center gap-2"
            >
              {cleaning && <Loader2 size={16} className="animate-spin" />}
              Geschlossene archivieren
            </button>
          </div>
        </form>
      </Modal>

      <Modal
        open={Boolean(banUser)}
        onClose={() => !savingBan && setBanUser(null)}
        title="User sperren"
        description={
          banUser
            ? `${banUser.displayName} wird sofort ausgeloggt und sieht den Grund.`
            : undefined
        }
      >
        <form onSubmit={banSelectedUser} className="space-y-4">
          <div className="rounded-3xl border border-red-500/20 bg-red-500/10 p-4 text-sm leading-6 text-red-100">
            Warnung: Der User verliert sofort Zugriff auf Nexo. Chats bleiben
            gespeichert, aber der Account kann nichts mehr senden, bis du ihn
            entsperrst.
          </div>
          <label className="space-y-2">
            <span className="label">Sperrgrund</span>
            <textarea
              value={banReason}
              onChange={(event) => setBanReason(event.target.value)}
              className="field min-h-28 resize-none"
              maxLength={300}
              placeholder="z.B. Spam, Beleidigung, Regelverstoß..."
              required
              autoFocus
            />
          </label>
          <div className="flex justify-end gap-3">
            <button
              type="button"
              onClick={() => setBanUser(null)}
              disabled={savingBan}
              className="soft-button"
            >
              Abbrechen
            </button>
            <button
              disabled={savingBan}
              className="primary-button inline-flex items-center gap-2 bg-red-100 text-red-950 hover:bg-red-200"
            >
              {savingBan && <Loader2 size={16} className="animate-spin" />}
              Sperren
            </button>
          </div>
        </form>
      </Modal>

      <Modal
        open={Boolean(closingTicket)}
        onClose={() => !savingClose && setClosingTicket(null)}
        title="Ticket schließen"
        description={
          closingTicket ? `Ticket: ${closingTicket.title}` : undefined
        }
      >
        <form onSubmit={closeTicketWithReason} className="space-y-4">
          <div className="rounded-3xl border border-red-500/20 bg-red-500/10 p-4 text-sm leading-6 text-red-100">
            Warnung: Das Ticket wird geschlossen und der Grund bleibt im Verlauf
            sichtbar.
          </div>
          <label className="space-y-2">
            <span className="label">Schließgrund</span>
            <textarea
              value={closeReason}
              onChange={(event) => setCloseReason(event.target.value)}
              className="field min-h-28 resize-none"
              maxLength={500}
              placeholder="z.B. Problem gelöst, doppelte Anfrage, Regelverstoß..."
              required
              autoFocus
            />
          </label>
          <div className="flex justify-end gap-3">
            <button
              type="button"
              onClick={() => setClosingTicket(null)}
              disabled={savingClose}
              className="soft-button"
            >
              Abbrechen
            </button>
            <button
              disabled={savingClose}
              className="primary-button inline-flex items-center gap-2 bg-red-100 text-red-950 hover:bg-red-200"
            >
              {savingClose && <Loader2 size={16} className="animate-spin" />}
              Ticket schließen
            </button>
          </div>
        </form>
      </Modal>

      <Modal
        open={Boolean(passwordUser)}
        onClose={() => !savingPassword && setPasswordUser(null)}
        title="Passwort zurücksetzen"
        description={
          passwordUser
            ? `Neues Passwort für ${passwordUser.displayName} setzen.`
            : undefined
        }
      >
        <form onSubmit={resetPassword} className="space-y-4">
          <label className="space-y-2">
            <span className="label">Neues Passwort</span>
            <input
              value={newPassword}
              onChange={(event) => setNewPassword(event.target.value)}
              className="field"
              type="password"
              minLength={8}
              required
              autoFocus
            />
          </label>
          <p className="text-xs leading-5 text-zinc-500">
            Das Passwort wird sicher gespeichert. Nach dem Speichern wird der
            User auf allen Geräten automatisch ausgeloggt und muss sich mit dem
            neuen Passwort neu anmelden.
          </p>
          <div className="flex justify-end gap-3">
            <button
              type="button"
              onClick={() => setPasswordUser(null)}
              disabled={savingPassword}
              className="soft-button"
            >
              Abbrechen
            </button>
            <button
              disabled={savingPassword}
              className="primary-button inline-flex items-center gap-2"
            >
              {savingPassword && <Loader2 size={16} className="animate-spin" />}
              Passwort ändern & überall ausloggen
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
