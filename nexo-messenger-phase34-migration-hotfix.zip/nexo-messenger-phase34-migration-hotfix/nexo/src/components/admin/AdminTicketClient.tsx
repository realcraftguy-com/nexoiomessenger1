"use client";

import Link from "next/link";
import { FormEvent, useEffect, useRef, useState } from "react";
import { io, Socket } from "socket.io-client";
import { Archive, ArchiveRestore, ArrowLeft, Loader2, Send, XCircle } from "lucide-react";
import { Modal } from "@/components/ui/Modal";
import { Notice } from "@/components/ui/Notice";
import { FilePicker } from "@/components/support/FilePicker";
import { TicketAttachments } from "@/components/support/TicketAttachments";

function mergeMessage(ticket: any, message: any) {
  if (!ticket) return ticket;
  if (ticket.messages.some((item: any) => item.id === message.id)) return ticket;
  return { ...ticket, messages: [...ticket.messages, message], status: message.isStaff ? "ANSWERED" : "OPEN" };
}

export function AdminTicketClient({ ticketId }: { ticketId: string }) {
  const [ticket, setTicket] = useState<any | null>(null);
  const [reply, setReply] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [notice, setNotice] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [sending, setSending] = useState(false);
  const [closeOpen, setCloseOpen] = useState(false);
  const [closeReason, setCloseReason] = useState("");
  const [closing, setClosing] = useState(false);
  const [archiving, setArchiving] = useState(false);
  const socketRef = useRef<Socket | null>(null);
  const replyInputRef = useRef<HTMLInputElement | null>(null);

  async function load() {
    const res = await fetch(`/api/tickets/${ticketId}`);
    const data = await res.json().catch(() => ({}));
    if (res.ok) setTicket(data.ticket);
    else setNotice({ type: "error", text: data.error || "Ticket konnte nicht geladen werden." });
  }

  useEffect(() => { load(); }, [ticketId]);
  useEffect(() => {
    const interval = window.setInterval(() => load(), 15000);
    return () => window.clearInterval(interval);
  }, [ticketId]);
  useEffect(() => {
    const socket = io({ withCredentials: true, transports: ["websocket", "polling"] });
    socketRef.current = socket;
    socket.emit("ticket:join", { ticketId });
    socket.on("ticket:message", (payload) => {
      if (payload.ticketId === ticketId) setTicket((current: any) => mergeMessage(current, payload.message));
    });
    socket.on("ticket:updated", (payload) => {
      if (payload.ticketId === ticketId) setTicket(payload.ticket);
    });
    socket.on("ticket:closed", (payload) => {
      if (payload.ticketId === ticketId) setTicket(payload.ticket);
    });
    socket.on("ticket:deleted", (payload) => {
      if (payload.ticketId === ticketId) {
        setTicket(null);
        setNotice({ type: "error", text: "Dieses Ticket wurde gelöscht." });
      }
    });
    return () => { socket.disconnect(); };
  }, [ticketId]);

  function focusReplyInput() {
    window.requestAnimationFrame(() => replyInputRef.current?.focus());
  }

  async function sendReply(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!ticket || !reply.trim()) return;
    const content = reply.trim();
    setNotice(null);
    setSending(true);
    setReply("");
    focusReplyInput();

    if (files.length === 0) {
      socketRef.current?.emit("ticket:message", { ticketId, content }, (result: any) => {
        setSending(false);
        if (result?.error) {
          setReply(content);
          setNotice({ type: "error", text: result.error });
        }
        focusReplyInput();
      });
      return;
    }

    const formData = new FormData();
    formData.append("content", content);
    files.forEach((file) => formData.append("files", file));
    const res = await fetch(`/api/tickets/${ticketId}/messages`, { method: "POST", body: formData });
    const data = await res.json().catch(() => ({}));
    setSending(false);
    if (!res.ok) {
      setReply(content);
      setNotice({ type: "error", text: data.error || "Antwort konnte nicht gesendet werden." });
      focusReplyInput();
      return;
    }
    setFiles([]);
    if (data.message) setTicket((current: any) => mergeMessage(current, data.message));
    socketRef.current?.emit("ticket:sync", { ticketId });
    focusReplyInput();
  }

  async function closeTicket(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const reason = closeReason.trim();
    if (!ticket || reason.length < 3) return setNotice({ type: "error", text: "Bitte gib einen echten Schließgrund ein." });
    setClosing(true);
    setNotice(null);
    const socket = socketRef.current;

    if (socket?.connected) {
      socket.emit("ticket:close", { ticketId, reason }, (result: any) => {
        setClosing(false);
        if (result?.error || !result?.ok) {
          setNotice({ type: "error", text: result?.error || "Ticket konnte nicht geschlossen werden." });
          return;
        }
        setTicket(result.ticket);
        setCloseOpen(false);
        setNotice({ type: "success", text: "Ticket wurde geschlossen." });
      });
      return;
    }

    const res = await fetch(`/api/tickets/${ticketId}`, { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ reason }) });
    const data = await res.json().catch(() => ({}));
    setClosing(false);
    if (!res.ok) return setNotice({ type: "error", text: data.error || "Ticket konnte nicht geschlossen werden." });
    setTicket(data.ticket);
    setCloseOpen(false);
    socketRef.current?.emit("ticket:sync", { ticketId });
    focusReplyInput();
  }


  async function archiveTicket(archive: boolean) {
    if (!ticket) return;
    setArchiving(true);
    setNotice(null);
    const res = await fetch(`/api/admin/tickets/${ticket.id}/archive`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ archive })
    });
    const data = await res.json().catch(() => ({}));
    setArchiving(false);
    if (!res.ok) return setNotice({ type: "error", text: data.error || "Ticket konnte nicht verschoben werden." });
    setTicket(data.ticket);
    socketRef.current?.emit("ticket:sync", { ticketId: data.ticket.id });
    setNotice({ type: "success", text: archive ? "Ticket wurde archiviert." : "Ticket wurde wiederhergestellt." });
  }

  if (!ticket) {
    return <div className="grid h-full place-items-center p-8 text-sm text-zinc-500">Ticket wird geladen...</div>;
  }

  return (
    <div className="flex h-full min-h-0 flex-col">
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 p-5">
        <div className="min-w-0">
          <Link href="/app/admin" className="mb-3 inline-flex items-center gap-2 text-xs text-zinc-500 transition hover:text-white"><ArrowLeft size={14} /> Zurück zum Admin Panel</Link>
          <h2 className="truncate text-xl font-semibold tracking-[-.04em]">{ticket.title}</h2>
          <p className="mt-1 text-xs text-zinc-500">{ticket.category} · {ticket.priority} · von {ticket.user?.displayName} @{ticket.user?.username}</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="rounded-full border border-white/10 px-3 py-2 text-xs text-zinc-400">{ticket.status}</span>
          {ticket.status !== "CLOSED" && <button onClick={() => setCloseOpen(true)} className="soft-button text-red-100"><XCircle size={16} /> Schließen</button>}
          {ticket.status === "CLOSED" && !ticket.archivedAt && <button onClick={() => archiveTicket(true)} disabled={archiving} className="soft-button"><Archive size={16} /> Archivieren</button>}
          {ticket.archivedAt && <button onClick={() => archiveTicket(false)} disabled={archiving} className="soft-button"><ArchiveRestore size={16} /> Wiederherstellen</button>}
        </div>
      </div>

      {notice && <div className="border-b border-white/10 p-4"><Notice type={notice.type}>{notice.text}</Notice></div>}
      {ticket.status === "CLOSED" && (
        <div className="border-b border-red-400/20 bg-red-500/10 px-5 py-4 text-sm text-red-50">
          Geschlossen aufgrund von: <b>{ticket.closeReason || "Kein Grund angegeben"}</b>
        </div>
      )}
      {ticket.archivedAt && (
        <div className="border-b border-white/10 bg-white/[.04] px-5 py-3 text-sm text-zinc-300">
          Dieses Ticket liegt im Archiv. Du kannst es über den Button oben wiederherstellen.
        </div>
      )}

      <div className="nexo-scrollbar min-h-0 flex-1 space-y-4 overflow-y-auto p-5">
        {ticket.messages.map((message: any) => (
          <div key={message.id} className="rounded-[1.75rem] border border-white/10 bg-white/[.035] p-4">
            <div className="mb-2 flex items-center justify-between gap-3">
              <p className="text-sm font-medium">{message.author?.displayName || "User"} <span className="text-zinc-500">@{message.author?.username}</span></p>
              {message.isStaff && <span className="rounded-full bg-white px-2 py-0.5 text-[10px] font-semibold text-black">STAFF</span>}
            </div>
            <p className="whitespace-pre-wrap text-sm leading-6 text-zinc-300">{message.content}</p>
            <TicketAttachments attachments={message.attachments} />
          </div>
        ))}
      </div>

      <form onSubmit={sendReply} className="border-t border-white/10 p-4">
        <div className="space-y-3 rounded-3xl border border-white/10 bg-black/30 p-2">
          <FilePicker id="admin-ticket-files" files={files} onChange={setFiles} />
          <div className="flex gap-3">
            <input ref={replyInputRef} value={reply} onChange={(event) => setReply(event.target.value)} disabled={ticket.status === "CLOSED" || sending} className="flex-1 bg-transparent px-3 text-sm outline-none placeholder:text-zinc-600 disabled:opacity-40" placeholder={ticket.status === "CLOSED" ? "Ticket ist geschlossen" : "Admin-Antwort schreiben..."} />
            <button disabled={ticket.status === "CLOSED" || sending} className="primary-button p-3">{sending ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}</button>
          </div>
        </div>
      </form>

      <Modal open={closeOpen} onClose={() => !closing && setCloseOpen(false)} title="Ticket schließen" description="Ein Schließgrund ist Pflicht und wird für User sichtbar gespeichert.">
        <form onSubmit={closeTicket} className="space-y-4">
          <textarea value={closeReason} onChange={(event) => setCloseReason(event.target.value)} className="field min-h-28 resize-none" maxLength={500} placeholder="Grund fürs Schließen..." required autoFocus />
          <div className="rounded-3xl border border-red-400/20 bg-red-500/10 p-4 text-sm leading-6 text-red-100">Warnung: Danach kann niemand mehr in diesem Ticket antworten.</div>
          <div className="flex justify-end gap-3">
            <button type="button" onClick={() => setCloseOpen(false)} disabled={closing} className="soft-button">Abbrechen</button>
            <button disabled={closing} className="primary-button inline-flex items-center gap-2 bg-red-100 text-red-950 hover:bg-red-200">{closing && <Loader2 size={16} className="animate-spin" />} Ticket schließen</button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
