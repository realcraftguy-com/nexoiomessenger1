"use client";

import { ReactNode } from "react";
import clsx from "clsx";

export function Notice({ type = "info", children }: { type?: "info" | "success" | "error"; children: ReactNode }) {
  if (!children) return null;
  return (
    <div
      className={clsx(
        "rounded-2xl border px-4 py-3 text-sm",
        type === "info" && "border-white/10 bg-white/[.04] text-zinc-300",
        type === "success" && "border-emerald-400/20 bg-emerald-400/10 text-emerald-100",
        type === "error" && "border-red-500/20 bg-red-500/10 text-red-100"
      )}
    >
      {children}
    </div>
  );
}
