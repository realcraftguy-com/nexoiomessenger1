import { initials } from "@/lib/format";

export function Avatar({ user, size = "md" }: { user: { displayName: string; avatarUrl?: string | null; avatarColor?: string | null }; size?: "sm" | "md" | "lg" }) {
  const classes = size === "sm" ? "h-8 w-8 text-[10px]" : size === "lg" ? "h-12 w-12 text-sm" : "h-10 w-10 text-xs";
  if (user.avatarUrl) {
    return <img src={user.avatarUrl} alt="Avatar" className={`${classes} rounded-2xl object-cover`} />;
  }
  return (
    <div className={`${classes} grid shrink-0 place-items-center rounded-2xl font-black text-black`} style={{ backgroundColor: user.avatarColor || "#fff" }}>
      {initials(user.displayName)}
    </div>
  );
}
