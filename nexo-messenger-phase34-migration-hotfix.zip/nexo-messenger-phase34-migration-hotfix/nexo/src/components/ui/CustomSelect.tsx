"use client";

import { useEffect, useRef, useState } from "react";
import { Check, ChevronDown } from "lucide-react";
import clsx from "clsx";

export type SelectOption = {
  value: string;
  label: string;
  description?: string;
};

export function CustomSelect({
  name,
  value,
  defaultValue,
  options,
  onChange,
  label,
  className
}: {
  name?: string;
  value?: string;
  defaultValue?: string;
  options: SelectOption[];
  onChange?: (value: string) => void;
  label?: string;
  className?: string;
}) {
  const [internal, setInternal] = useState(defaultValue || options[0]?.value || "");
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement | null>(null);
  const selectedValue = value ?? internal;
  const selected = options.find((option) => option.value === selectedValue) || options[0];

  useEffect(() => {
    function onDocClick(event: MouseEvent) {
      if (!ref.current?.contains(event.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onDocClick);
    return () => document.removeEventListener("mousedown", onDocClick);
  }, []);

  function select(nextValue: string) {
    setInternal(nextValue);
    onChange?.(nextValue);
    setOpen(false);
  }

  return (
    <div ref={ref} className={clsx("relative space-y-2", className)}>
      {label && <span className="label">{label}</span>}
      {name && <input type="hidden" name={name} value={selectedValue} />}
      <button
        type="button"
        onClick={() => setOpen((state) => !state)}
        className="field flex min-h-12 w-full items-center justify-between gap-3 text-left"
      >
        <span>
          <span className="block text-sm text-white">{selected?.label}</span>
          {selected?.description && <span className="mt-0.5 block text-xs text-zinc-500">{selected.description}</span>}
        </span>
        <ChevronDown size={16} className={clsx("shrink-0 text-zinc-500 transition", open && "rotate-180 text-white")} />
      </button>
      {open && (
        <div className="absolute left-0 right-0 top-full z-40 mt-2 overflow-hidden rounded-2xl border border-white/10 bg-surface-900 p-1 shadow-2xl shadow-black/50">
          {options.map((option) => {
            const active = option.value === selectedValue;
            return (
              <button
                key={option.value}
                type="button"
                onClick={() => select(option.value)}
                className={clsx(
                  "flex w-full items-center justify-between gap-3 rounded-xl px-3 py-2.5 text-left text-sm transition",
                  active ? "bg-white text-black" : "text-zinc-300 hover:bg-white/[.07] hover:text-white"
                )}
              >
                <span>
                  <span className="block font-medium">{option.label}</span>
                  {option.description && <span className={clsx("mt-0.5 block text-xs", active ? "text-black/60" : "text-zinc-500")}>{option.description}</span>}
                </span>
                {active && <Check size={15} />}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
