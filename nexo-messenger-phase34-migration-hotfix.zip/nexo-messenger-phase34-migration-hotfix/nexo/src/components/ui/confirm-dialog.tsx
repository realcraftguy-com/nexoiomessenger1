"use client";

import { useMemo, useState } from "react";
import { Modal } from "@/components/ui/Modal";

export function ConfirmDialog({ open, title, description, confirmLabel = "Bestätigen", cancelLabel = "Abbrechen", danger = false, requiredText, onClose, onConfirm }: { open: boolean; title: string; description?: string; confirmLabel?: string; cancelLabel?: string; danger?: boolean; requiredText?: string; onClose: () => void; onConfirm: () => void }) {
  const [value, setValue] = useState("");
  const canConfirm = useMemo(() => !requiredText || value === requiredText, [requiredText, value]);
  return (
    <Modal open={open} title={title} description={description} onClose={onClose} size="sm">
      <div className="space-y-4">
        {requiredText && (
          <label className="space-y-2">
            <span className="label">Tippe {requiredText}</span>
            <input className="field" value={value} onChange={(event) => setValue(event.target.value)} autoFocus />
          </label>
        )}
        <div className="flex justify-end gap-2">
          <button type="button" className="soft-button" onClick={onClose}>{cancelLabel}</button>
          <button type="button" disabled={!canConfirm} onClick={onConfirm} className={danger ? "rounded-2xl border border-red-400/20 bg-red-500/15 px-4 py-2 text-sm font-medium text-red-100 transition hover:bg-red-500/25 disabled:opacity-50" : "primary-button disabled:opacity-50"}>{confirmLabel}</button>
        </div>
      </div>
    </Modal>
  );
}
