import clsx from "clsx";

export function Skeleton({ className = "" }: { className?: string }) {
  return <div className={clsx("animate-pulse rounded-2xl bg-white/[.07]", className)} />;
}

export function MessageSkeleton() {
  return (
    <div className="flex gap-3 p-1">
      <Skeleton className="size-10 shrink-0 rounded-2xl" />
      <div className="flex-1 space-y-2">
        <Skeleton className="h-3 w-36" />
        <Skeleton className="h-16 w-full max-w-xl rounded-3xl" />
      </div>
    </div>
  );
}
