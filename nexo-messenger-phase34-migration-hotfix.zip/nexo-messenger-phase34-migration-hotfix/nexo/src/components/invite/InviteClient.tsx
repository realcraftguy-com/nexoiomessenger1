"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";

export function InviteClient({ code }: { code: string }) {
  const router = useRouter();
  const [invite, setInvite] = useState<any>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch(`/api/invites/${code}`).then(async (res) => {
      const data = await res.json().catch(() => ({}));
      if (!res.ok) return setError(data.error || "Invite konnte nicht geladen werden");
      setInvite(data.invite);
    });
  }, [code]);

  async function join() {
    const res = await fetch(`/api/invites/${code}`, { method: "POST" });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      if (res.status === 401) return router.push(`/login?next=/invite/${code}`);
      return setError(data.error || "Beitreten fehlgeschlagen");
    }
    router.push(data.channelId ? `/app/servers/${data.serverId}/channels/${data.channelId}` : "/app/@me");
  }

  return (
    <main className="grid min-h-screen place-items-center bg-surface-950 px-4 text-white">
      <div className="absolute inset-0 bg-grid bg-[size:48px_48px] opacity-[.08]" />
      <div className="panel relative w-full max-w-md p-6 text-center">
        <Link href="/" className="mx-auto mb-6 grid h-14 w-14 place-items-center rounded-2xl bg-white text-sm font-black text-black">NX</Link>
        {error ? <p className="rounded-2xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-200">{error}</p> : invite ? (
          <>
            <h1 className="text-3xl font-semibold tracking-[-.04em]">{invite.server.name}</h1>
            <p className="mt-2 text-sm text-zinc-500">{invite.server._count.members} Mitglieder · Einladung über Nexo</p>
            <button onClick={join} className="primary-button mt-6 w-full py-3">Server beitreten</button>
          </>
        ) : <p className="text-sm text-zinc-500">Lade Invite...</p>}
      </div>
    </main>
  );
}
