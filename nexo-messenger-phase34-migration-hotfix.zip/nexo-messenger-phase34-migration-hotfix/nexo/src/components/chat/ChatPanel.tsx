"use client";

import {
  FormEvent,
  KeyboardEvent,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { io, Socket } from "socket.io-client";
import {
  Archive,
  ArrowDown,
  Download,
  Edit3,
  FileText,
  Flag,
  Image as ImageIcon,
  Loader2,
  Music,
  Paperclip,
  Pin,
  Reply,
  Search,
  Send,
  Smile,
  Trash2,
  Video,
  Wifi,
  WifiOff,
  X,
} from "lucide-react";
import { Avatar } from "@/components/ui/Avatar";
import { SimpleMarkdown } from "@/lib/markdown";
import { Modal } from "@/components/ui/Modal";
import { FullEmojiPicker } from "@/components/chat/FullEmojiPicker";
import { MessageSkeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";

type Author = {
  id: string;
  username: string;
  displayName: string;
  avatarUrl?: string | null;
  avatarColor: string;
};
type Attachment = {
  id?: string;
  name: string;
  url: string;
  mimeType: string;
  size: number;
};
type ReplyPreview = {
  id: string;
  content: string;
  deletedAt?: string | null;
  author?: Author;
} | null;
type Message = {
  id: string;
  content: string;
  createdAt: string;
  editedAt?: string | null;
  deletedAt?: string | null;
  channelId?: string;
  threadId?: string;
  author: Author;
  attachments?: string | Attachment[] | null;
  reactions?: string | Record<string, string[]> | null;
  replyToId?: string | null;
  replyTo?: ReplyPreview;
  clientMessageId?: string | null;
  pending?: boolean;
  failed?: boolean;
};

type PinItem = {
  id: string;
  createdAt: string;
  message?: Message | null;
  dmMessage?: Message | null;
  pinnedBy?: Pick<Author, "id" | "username" | "displayName"> | null;
};

type SearchResult = { type: "channel" | "dm"; message: Message };
type ReactionUser = Pick<
  Author,
  "id" | "username" | "displayName" | "avatarUrl" | "avatarColor"
>;
type ReactionPreview = {
  messageId: string;
  emoji: string;
  users: ReactionUser[];
  loading: boolean;
} | null;

type Props = {
  mode: "channel" | "dm";
  id: string;
  title: string;
  subtitle?: string;
  members?: { user: Author & { status: string } }[];
};

function parseAttachments(value: Message["attachments"]): Attachment[] {
  if (!value) return [];
  if (Array.isArray(value)) return value;
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function parseReactions(value: Message["reactions"]): Record<string, string[]> {
  if (!value) return {};
  if (typeof value !== "string") return !Array.isArray(value) ? value : {};
  try {
    const parsed: unknown = JSON.parse(value);
    return parsed && typeof parsed === "object" && !Array.isArray(parsed)
      ? (parsed as Record<string, string[]>)
      : {};
  } catch {
    return {};
  }
}

function reactionSummary(value: Message["reactions"]) {
  return Object.entries(parseReactions(value)).filter(
    ([, users]) => Array.isArray(users) && users.length > 0,
  );
}

function formatBytes(size: number) {
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

function mergeMessages(current: Message[], incoming: Message[]) {
  const incomingList = incoming || [];
  const map = new Map<string, Message>();
  for (const item of current) {
    if (
      item.pending &&
      item.clientMessageId &&
      incomingList.some(
        (message) => message.clientMessageId === item.clientMessageId,
      )
    )
      continue;
    map.set(item.id, item);
  }
  for (const item of incomingList) {
    const duplicateTemp = item.clientMessageId
      ? Array.from(map.values()).find(
          (message) =>
            message.pending && message.clientMessageId === item.clientMessageId,
        )
      : undefined;
    if (duplicateTemp) map.delete(duplicateTemp.id);
    const existing = map.get(item.id);
    map.set(item.id, { ...existing, ...item, pending: false, failed: false });
  }
  return Array.from(map.values()).sort(
    (a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime(),
  );
}

function messageTargetId(message: Message, mode: "channel" | "dm") {
  return mode === "channel" ? message.channelId : message.threadId;
}
function extension(name: string) {
  const clean = name.toLowerCase().split("?")[0];
  const index = clean.lastIndexOf(".");
  return index >= 0 ? clean.slice(index) : "";
}
function fileKind(
  file: Pick<Attachment, "name" | "mimeType">,
): "image" | "audio" | "video" | "archive" | "file" {
  const type = file.mimeType || "";
  const ext = extension(file.name);
  if (
    type.startsWith("image/") ||
    [".jpg", ".jpeg", ".png", ".gif", ".webp"].includes(ext)
  )
    return "image";
  if (type.startsWith("audio/") || [".mp3", ".wav"].includes(ext))
    return "audio";
  if (type.startsWith("video/") || [".mp4"].includes(ext)) return "video";
  if ([".zip", ".rar", ".7z", ".tar", ".gz"].includes(ext)) return "archive";
  return "file";
}
function attachmentIcon(file: Pick<Attachment, "name" | "mimeType">) {
  const kind = fileKind(file);
  if (kind === "image") return <ImageIcon size={16} />;
  if (kind === "audio") return <Music size={16} />;
  if (kind === "video") return <Video size={16} />;
  if (kind === "archive") return <Archive size={16} />;
  return <FileText size={16} />;
}
function dateLabel(value: string) {
  const date = new Date(value);
  const today = new Date();
  const yesterday = new Date();
  yesterday.setDate(today.getDate() - 1);
  if (date.toDateString() === today.toDateString()) return "Heute";
  if (date.toDateString() === yesterday.toDateString()) return "Gestern";
  return new Intl.DateTimeFormat("de-DE", {
    day: "2-digit",
    month: "long",
    year: "numeric",
  }).format(date);
}
function sameMessageGroup(previous: Message | undefined, current: Message) {
  if (!previous || previous.author.id !== current.author.id) return false;
  if (dateLabel(previous.createdAt) !== dateLabel(current.createdAt))
    return false;
  const delta =
    new Date(current.createdAt).getTime() -
    new Date(previous.createdAt).getTime();
  return delta >= 0 && delta < 5 * 60 * 1000;
}

function MessageAttachments({
  files,
  onPreview,
}: {
  files: Attachment[];
  onPreview: (file: Attachment) => void;
}) {
  if (!files.length) return null;
  return (
    <div className="mt-3 grid gap-2">
      {files.map((file, index) => {
        const kind = fileKind(file);
        const key = `${file.url}-${index}`;
        const meta = (
          <div className="flex items-center gap-3 p-3 text-xs text-zinc-400">
            <span className="grid size-9 place-items-center rounded-xl border border-white/10 bg-white/[.04] text-zinc-300">
              {attachmentIcon(file)}
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm text-zinc-100">{file.name}</p>
              <p>{formatBytes(file.size)}</p>
            </div>
            <Download size={15} />
          </div>
        );
        if (kind === "image")
          return (
            <button
              key={key}
              type="button"
              onClick={() => onPreview(file)}
              className="block overflow-hidden rounded-2xl border border-white/10 bg-black/30 text-left transition hover:border-white/25"
            >
              <div className="bg-black/50">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={file.url}
                  alt={file.name}
                  className="max-h-[420px] w-full object-contain"
                />
              </div>
              {meta}
            </button>
          );
        if (kind === "audio")
          return (
            <div
              key={key}
              className="overflow-hidden rounded-2xl border border-white/10 bg-black/30"
            >
              <div className="flex items-center gap-3 border-b border-white/10 bg-white/[.03] p-3">
                <span className="grid size-10 place-items-center rounded-xl border border-white/10 bg-white/[.05]">
                  <Music size={18} />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm text-zinc-100">{file.name}</p>
                  <p className="text-xs text-zinc-500">
                    {formatBytes(file.size)}
                  </p>
                </div>
                <a
                  href={file.url}
                  target="_blank"
                  rel="noreferrer"
                  className="rounded-xl p-2 text-zinc-400 transition hover:bg-white/10 hover:text-white"
                >
                  <Download size={15} />
                </a>
              </div>
              <div className="p-3">
                <audio
                  controls
                  preload="metadata"
                  src={file.url}
                  className="w-full"
                />
              </div>
            </div>
          );
        if (kind === "video")
          return (
            <div
              key={key}
              className="overflow-hidden rounded-2xl border border-white/10 bg-black/30"
            >
              <video
                controls
                preload="metadata"
                src={file.url}
                className="max-h-[420px] w-full bg-black object-contain"
              />
              {meta}
            </div>
          );
        return (
          <a
            key={key}
            href={file.url}
            target="_blank"
            rel="noreferrer"
            className="block overflow-hidden rounded-2xl border border-white/10 bg-black/30 transition hover:border-white/25"
          >
            {meta}
          </a>
        );
      })}
    </div>
  );
}

export function ChatPanel({ mode, id, title, subtitle, members = [] }: Props) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [typing, setTyping] = useState<string[]>([]);
  const [text, setText] = useState("");
  const [error, setError] = useState("");
  const [connected, setConnected] = useState(false);
  const [loadingMessages, setLoadingMessages] = useState(true);
  const [me, setMe] = useState<Author | null>(null);
  const [files, setFiles] = useState<File[]>([]);
  const [isSending, setIsSending] = useState(false);
  const [emojiOpen, setEmojiOpen] = useState(false);
  const [reactionTarget, setReactionTarget] = useState<Message | null>(null);
  const [reactionPreview, setReactionPreview] = useState<ReactionPreview>(null);
  const [reportTarget, setReportTarget] = useState<Message | null>(null);
  const [reportReason, setReportReason] = useState(
    "Spam oder störendes Verhalten",
  );
  const [reportDetails, setReportDetails] = useState("");
  const [submittingReport, setSubmittingReport] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Message | null>(null);
  const [replyTarget, setReplyTarget] = useState<Message | null>(null);
  const [editing, setEditing] = useState<Message | null>(null);
  const [editText, setEditText] = useState("");
  const [lightbox, setLightbox] = useState<Attachment | null>(null);
  const [nearBottom, setNearBottom] = useState(true);
  const [newCount, setNewCount] = useState(0);
  const [pinCount, setPinCount] = useState(0);
  const [canPin, setCanPin] = useState(false);
  const [pins, setPins] = useState<PinItem[]>([]);
  const [pinOpen, setPinOpen] = useState(false);
  const [loadingPins, setLoadingPins] = useState(false);
  const [hasMore, setHasMore] = useState(false);
  const [loadingOlder, setLoadingOlder] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [searching, setSearching] = useState(false);
  const [dmBlockedReason, setDmBlockedReason] = useState("");
  const socketRef = useRef<Socket | null>(null);
  const inputRef = useRef<HTMLTextAreaElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const scrollRef = useRef<HTMLDivElement | null>(null);
  const endRef = useRef<HTMLDivElement | null>(null);
  const typingTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const { toast } = useToast();

  const endpoint =
    mode === "channel"
      ? `/api/channels/${id}/messages`
      : `/api/dms/${id}/messages`;
  const joinEvent = mode === "channel" ? "channel:join" : "dm:join";
  const messageEvent = mode === "channel" ? "channel:message" : "dm:message";
  const typingEvent = mode === "channel" ? "channel:typing" : "dm:typing";
  const payloadKey = mode === "channel" ? "channelId" : "threadId";
  const deleteEvent =
    mode === "channel" ? "channel:message:delete" : "dm:message:delete";
  const deletedEvent =
    mode === "channel" ? "channel:message:deleted" : "dm:message:deleted";
  const pinEndpoint =
    mode === "channel" ? `/api/channels/${id}/pins` : `/api/dms/${id}/pins`;

  const refreshMessages = useCallback(async () => {
    const res = await fetch(endpoint, { cache: "no-store" });
    setLoadingMessages(false);
    if (!res.ok) return;
    const data = await res.json().catch(() => ({}));
    const nextMessages = Array.isArray(data.messages)
      ? (data.messages as Message[])
      : [];
    setHasMore(Boolean(data.hasMore));
    setMessages((items) => mergeMessages(items, nextMessages));
  }, [endpoint]);

  const refreshPins = useCallback(async () => {
    setLoadingPins(true);
    const res = await fetch(pinEndpoint, { cache: "no-store" });
    setLoadingPins(false);
    if (!res.ok) return;
    const data = await res.json().catch(() => ({}));
    const nextPins = Array.isArray(data.pins) ? (data.pins as PinItem[]) : [];
    setPins(nextPins);
    setPinCount(nextPins.length);
    setCanPin(Boolean(data.canPin));
  }, [pinEndpoint]);

  const scrollToBottom = useCallback((behavior: ScrollBehavior = "smooth") => {
    endRef.current?.scrollIntoView({ behavior, block: "end" });
    setNewCount(0);
  }, []);

  function updateNearBottom() {
    const node = scrollRef.current;
    if (!node) return;
    const distance = node.scrollHeight - node.scrollTop - node.clientHeight;
    const close = distance < 140;
    setNearBottom(close);
    if (close) setNewCount(0);
  }

  useEffect(() => {
    let cancelled = false;
    setMessages([]);
    setError("");
    setLoadingMessages(true);
    setReplyTarget(null);
    setEditing(null);
    setPinCount(0);
    setCanPin(false);
    setPins([]);
    setHasMore(false);
    setDmBlockedReason("");
    fetch("/api/auth/me").then(async (res) => {
      if (!cancelled && res.ok) setMe((await res.json()).user);
    });
    refreshMessages().then(() =>
      window.setTimeout(() => scrollToBottom("auto"), 60),
    );
    refreshPins().catch(() => undefined);
    if (mode === "dm")
      fetch(`/api/dms/${id}/safety`, { cache: "no-store" })
        .then(async (res) => {
          if (res.ok) {
            const data = await res.json();
            if (!cancelled)
              setDmBlockedReason(
                data.blocked ? data.reason || "Dieser DM ist blockiert." : "",
              );
          }
        })
        .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, [id, mode, refreshMessages, refreshPins, scrollToBottom]);

  useEffect(() => {
    const interval = window.setInterval(
      () => {
        void refreshMessages();
      },
      connected ? 45000 : 2500,
    );
    const onFocus = () => {
      void refreshMessages();
    };
    const onVisibility = () => {
      if (!document.hidden) void refreshMessages();
    };
    window.addEventListener("focus", onFocus);
    document.addEventListener("visibilitychange", onVisibility);
    return () => {
      window.clearInterval(interval);
      window.removeEventListener("focus", onFocus);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [connected, refreshMessages]);

  useEffect(() => {
    const socket = io({
      withCredentials: true,
      transports: ["websocket", "polling"],
    });
    socketRef.current = socket;
    socket.on("connect", () => {
      setConnected(true);
      socket.emit(joinEvent, { [payloadKey]: id });
      void refreshMessages();
    });
    socket.on("disconnect", () => {
      setConnected(false);
      toast({
        type: "warning",
        title: "Verbindung verloren",
        description: "Nexo nutzt kurz den Fallback.",
      });
    });
    socket.on("connect_error", () => {
      setConnected(false);
      setError("Verbindung getrennt. Nexo verbindet automatisch neu...");
    });
    socket.on(messageEvent, (message: Message) => {
      const targetId = messageTargetId(message, mode);
      if (targetId && targetId !== id) return;
      setError("");
      setMessages((items) => mergeMessages(items, [message]));
      if (!nearBottom) setNewCount((count) => count + 1);
      window.dispatchEvent(
        new CustomEvent("nexo:message", { detail: { mode, id, message } }),
      );
    });
    socket.on(`${mode}:message:updated`, (payload: { message?: Message }) => {
      if (payload.message)
        setMessages((items) =>
          items.map((item) =>
            item.id === payload.message?.id
              ? { ...item, ...payload.message }
              : item,
          ),
        );
    });
    socket.on(deletedEvent, (payload: Record<string, string>) => {
      const targetId = payload[payloadKey];
      if (targetId && targetId !== id) return;
      setMessages((items) =>
        items.map((message) =>
          message.id === payload.messageId
            ? {
                ...message,
                deletedAt: new Date().toISOString(),
                content: "",
                attachments: [],
              }
            : message,
        ),
      );
      window.dispatchEvent(
        new CustomEvent("nexo:message-deleted", {
          detail: { mode, id, messageId: payload.messageId },
        }),
      );
    });
    socket.on(
      `${mode}:message:reaction`,
      (payload: { message?: Message } & Record<string, string>) => {
        const message = payload.message;
        if (!message) return;
        const targetId = messageTargetId(message, mode) || payload[payloadKey];
        if (targetId && targetId !== id) return;
        setMessages((items) =>
          items.map((item) =>
            item.id === message.id
              ? { ...item, reactions: message.reactions }
              : item,
          ),
        );
      },
    );
    socket.on("channel:pins:changed", (payload: { channelId?: string }) => {
      if (mode === "channel" && payload.channelId === id) void refreshPins();
    });
    socket.on("dm:pins:changed", (payload: { threadId?: string }) => {
      if (mode === "dm" && payload.threadId === id) void refreshPins();
    });
    socket.on(
      "dm:safety:changed",
      (payload: { threadId?: string; blocked?: boolean; reason?: string }) => {
        if (mode !== "dm" || payload.threadId !== id) return;
        setDmBlockedReason(
          payload.blocked ? payload.reason || "Dieser DM ist blockiert." : "",
        );
        toast({
          type: payload.blocked ? "warning" : "success",
          title: payload.blocked ? "DM blockiert" : "DM wieder freigegeben",
          description: payload.reason || undefined,
        });
      },
    );
    socket.on(
      typingEvent,
      (payload: {
        channelId?: string;
        threadId?: string;
        user?: { displayName: string };
        typing?: boolean;
      }) => {
        if (payload[payloadKey] !== id) return;
        setTyping((current) => {
          const name = payload.user?.displayName || "Jemand";
          const next = payload.typing
            ? Array.from(new Set([...current, name]))
            : current.filter((item) => item !== name);
          return next.slice(0, 3);
        });
      },
    );
    return () => {
      socket.emit(typingEvent, { [payloadKey]: id, typing: false });
      socket.disconnect();
    };
  }, [
    deletedEvent,
    id,
    joinEvent,
    messageEvent,
    mode,
    nearBottom,
    payloadKey,
    refreshMessages,
    refreshPins,
    toast,
    typingEvent,
  ]);

  useEffect(() => {
    if (nearBottom) scrollToBottom("smooth");
  }, [messages.length, nearBottom, scrollToBottom]);

  const typingLabel = useMemo(
    () => (typing.length ? `${typing.join(", ")} tippt...` : ""),
    [typing],
  );
  function stopTypingSoon() {
    if (typingTimerRef.current) clearTimeout(typingTimerRef.current);
    typingTimerRef.current = setTimeout(
      () =>
        socketRef.current?.emit(typingEvent, {
          [payloadKey]: id,
          typing: false,
        }),
      1400,
    );
  }
  function focusInput() {
    window.requestAnimationFrame(() => inputRef.current?.focus());
  }
  function onPickFiles(selected: FileList | null) {
    if (!selected) return;
    setFiles((current) => [...current, ...Array.from(selected)].slice(0, 5));
    if (fileInputRef.current) fileInputRef.current.value = "";
    focusInput();
  }
  async function uploadSelectedFiles() {
    if (!files.length) return [] as Attachment[];
    const form = new FormData();
    files.forEach((file) => form.append("files", file));
    const res = await fetch("/api/uploads/messages", {
      method: "POST",
      body: form,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok)
      throw new Error(data.error || "Datei konnte nicht hochgeladen werden.");
    return data.attachments as Attachment[];
  }
  function applySentMessage(tempId: string, message: Message) {
    setMessages((items) => {
      const hasFinal = items.some((item) => item.id === message.id);
      if (hasFinal) return items.filter((item) => item.id !== tempId);
      const replaced = items.map((item) =>
        item.id === tempId ? message : item,
      );
      return replaced.some((item) => item.id === message.id)
        ? replaced
        : [...items.filter((item) => item.id !== tempId), message];
    });
    window.dispatchEvent(
      new CustomEvent("nexo:message", { detail: { mode, id, message } }),
    );
  }
  async function sendMessageFallback(
    content: string,
    attachments: Attachment[],
    clientMessageId: string,
    replyToId?: string,
  ) {
    const res = await fetch(endpoint, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        content,
        attachmentIds: attachments.map((file) => file.id).filter(Boolean),
        clientMessageId,
        replyToId,
      }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !data.message)
      throw new Error(
        data.error || "Nachricht konnte nicht gespeichert werden.",
      );
    return data.message as Message;
  }
  function sendMessageSocket(
    content: string,
    attachments: Attachment[],
    clientMessageId: string,
    replyToId?: string,
  ) {
    return new Promise<Message>((resolve, reject) => {
      const socket = socketRef.current;
      if (!socket?.connected) return reject(new Error("socket_not_connected"));
      (socket.timeout(6000) as Socket).emit(
        messageEvent,
        {
          [payloadKey]: id,
          content,
          attachmentIds: attachments.map((file) => file.id).filter(Boolean),
          clientMessageId,
          replyToId,
        },
        (err: Error | null, result: { error?: string; message?: Message }) => {
          if (err) return reject(err);
          if (result?.error) return reject(new Error(result.error));
          if (!result?.message) return reject(new Error("empty_socket_ack"));
          resolve(result.message);
        },
      );
    });
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (!canSend)
      return toast({
        type: "warning",
        title: "DM blockiert",
        description: dmBlockedReason,
      });
    const content = text.trim();
    if ((!content && files.length === 0) || !me || isSending) return;
    setError("");
    setIsSending(true);
    setEmojiOpen(false);
    socketRef.current?.emit(typingEvent, { [payloadKey]: id, typing: false });
    const tempId = `temp-${crypto.randomUUID()}`;
    const clientMessageId = crypto.randomUUID();
    const replyToId = replyTarget?.id;
    try {
      const attachments = await uploadSelectedFiles();
      setText("");
      setFiles([]);
      setReplyTarget(null);
      focusInput();
      const optimistic: Message = {
        id: tempId,
        content,
        attachments,
        createdAt: new Date().toISOString(),
        author: me,
        pending: true,
        clientMessageId,
        replyTo: replyTarget
          ? {
              id: replyTarget.id,
              content: replyTarget.content,
              author: replyTarget.author,
            }
          : null,
      };
      setMessages((items) => [...items, optimistic]);
      let saved: Message;
      try {
        saved = await sendMessageSocket(
          content,
          attachments,
          clientMessageId,
          replyToId,
        );
      } catch {
        saved = await sendMessageFallback(
          content,
          attachments,
          clientMessageId,
          replyToId,
        );
      }
      applySentMessage(tempId, saved);
      setIsSending(false);
      focusInput();
    } catch (err) {
      setIsSending(false);
      setMessages((items) =>
        items.map((msg) =>
          msg.id === tempId ? { ...msg, pending: false, failed: true } : msg,
        ),
      );
      const message =
        err instanceof Error
          ? err.message
          : "Nachricht konnte nicht gesendet werden.";
      setError(message);
      toast({
        type: "error",
        title: "Nachricht fehlgeschlagen",
        description: message,
      });
      focusInput();
    }
  }

  function onText(value: string) {
    setText(value);
    socketRef.current?.emit(typingEvent, {
      [payloadKey]: id,
      typing: value.length > 0,
    });
    if (value.length > 0) stopTypingSoon();
  }
  function insertEmoji(emoji: string) {
    setText((current) => `${current}${emoji}`);
    focusInput();
  }

  async function loadReactionPreview(message: Message, emoji: string) {
    const parsed = parseReactions(message.reactions);
    const ids = parsed[emoji] || [];
    setReactionPreview({
      messageId: message.id,
      emoji,
      users: [],
      loading: true,
    });
    const res = await fetch(
      `/api/messages/${message.id}/reactions?emoji=${encodeURIComponent(emoji)}&mode=${mode}`,
      { cache: "no-store" },
    );
    const data = await res.json().catch(() => ({}));
    if (!res.ok || !Array.isArray(data.users)) {
      const fallbackUsers = ids.map((userId) => {
        if (me?.id === userId) return me;
        if (message.author.id === userId) return message.author;
        const known = members
          .map((member) => member.user)
          .find((user) => user.id === userId);
        return (
          known || {
            id: userId,
            username: `user-${userId.slice(0, 6)}`,
            displayName: `User ${userId.slice(0, 6)}`,
            avatarColor: "#71717a",
            avatarUrl: null,
          }
        );
      });
      setReactionPreview({
        messageId: message.id,
        emoji,
        users: fallbackUsers,
        loading: false,
      });
      return;
    }
    setReactionPreview({
      messageId: message.id,
      emoji,
      users: data.users as ReactionUser[],
      loading: false,
    });
  }

  async function submitReport(event: FormEvent) {
    event.preventDefault();
    if (!reportTarget) return;
    setSubmittingReport(true);
    const body = {
      targetUserId:
        reportTarget.author.id === me?.id ? undefined : reportTarget.author.id,
      messageId: mode === "channel" ? reportTarget.id : undefined,
      dmMessageId: mode === "dm" ? reportTarget.id : undefined,
      reason: `${reportReason}${reportDetails.trim() ? `: ${reportDetails.trim()}` : ""}`,
    };
    const res = await fetch("/api/reports", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json().catch(() => ({}));
    setSubmittingReport(false);
    if (!res.ok)
      return toast({
        type: "error",
        title: "Melden fehlgeschlagen",
        description: data.error || "Report konnte nicht gesendet werden.",
      });
    setReportTarget(null);
    setReportDetails("");
    toast({
      type: "success",
      title: "Nachricht gemeldet",
      description: "Ein Admin kann den Report jetzt prüfen.",
    });
  }

  function reactToMessage(message: Message, emoji: string) {
    setReactionTarget(null);
    socketRef.current?.emit(
      `${mode}:message:react`,
      { [payloadKey]: id, messageId: message.id, emoji },
      (result: { error?: string; message?: Message }) => {
        if (result?.error) return setError(result.error);
        if (result?.message)
          setMessages((items) =>
            items.map((item) =>
              item.id === result.message?.id
                ? { ...item, reactions: result.message?.reactions }
                : item,
            ),
          );
      },
    );
    focusInput();
  }
  function deleteMessage(message: Message) {
    socketRef.current?.emit(
      deleteEvent,
      { [payloadKey]: id, messageId: message.id },
      (result: { error?: string }) => {
        if (result?.error) return setError(result.error);
        setMessages((items) =>
          items.map((item) =>
            item.id === message.id
              ? {
                  ...item,
                  deletedAt: new Date().toISOString(),
                  content: "",
                  attachments: [],
                }
              : item,
          ),
        );
        setDeleteTarget(null);
        focusInput();
      },
    );
  }
  async function saveEdit(event: FormEvent) {
    event.preventDefault();
    if (!editing) return;
    const content = editText.trim();
    if (!content) return;
    const editEndpoint =
      mode === "channel"
        ? `/api/messages/${editing.id}`
        : `/api/dm-messages/${editing.id}`;
    const res = await fetch(editEndpoint, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ content }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      toast({
        type: "error",
        title: "Bearbeiten fehlgeschlagen",
        description: data.error || "Nachricht konnte nicht bearbeitet werden.",
      });
      return;
    }
    setMessages((items) =>
      items.map((item) => (item.id === editing.id ? data.message : item)),
    );
    setEditing(null);
    toast({ type: "success", title: "Nachricht bearbeitet" });
  }
  async function pinMessage(message: Message) {
    if (!canPin) return;
    const res = await fetch(`/api/messages/${message.id}/pin`, {
      method: "POST",
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok)
      return toast({
        type: "error",
        title: "Pin fehlgeschlagen",
        description: data.error || "Nachricht konnte nicht gepinnt werden.",
      });
    await refreshPins();
    toast({
      type: "success",
      title: data?.alreadyPinned ? "War bereits gepinnt" : "Nachricht gepinnt",
    });
  }
  async function unpinMessage(messageId: string) {
    if (!canPin) return;
    const res = await fetch(`/api/messages/${messageId}/pin`, {
      method: "DELETE",
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok)
      return toast({
        type: "error",
        title: "Entpinnen fehlgeschlagen",
        description: data.error || "Pin konnte nicht entfernt werden.",
      });
    await refreshPins();
    toast({ type: "success", title: "Pin entfernt" });
  }
  function highlightLoadedMessage(messageId: string) {
    const node = scrollRef.current?.querySelector(
      `[data-message-id="${messageId}"]`,
    );
    if (node instanceof HTMLElement) {
      node.scrollIntoView({ behavior: "smooth", block: "center" });
      node.classList.add("ring-2", "ring-white/30", "bg-white/[.04]");
      window.setTimeout(
        () =>
          node.classList.remove("ring-2", "ring-white/30", "bg-white/[.04]"),
        1800,
      );
      return true;
    }
    return false;
  }
  async function jumpToMessage(messageId: string) {
    if (highlightLoadedMessage(messageId)) return;
    setLoadingOlder(true);
    const res = await fetch(
      `${endpoint}?limit=50&around=${encodeURIComponent(messageId)}`,
      { cache: "no-store" },
    );
    const data = await res.json().catch(() => ({}));
    setLoadingOlder(false);
    if (!res.ok)
      return toast({
        type: "error",
        title: "Nachricht nicht erreichbar",
        description:
          data.error || "Sie wurde gelöscht oder du hast keinen Zugriff.",
      });
    const aroundMessages = Array.isArray(data.messages)
      ? (data.messages as Message[])
      : [];
    setMessages((items) => mergeMessages(items, aroundMessages));
    setHasMore(Boolean(data.hasMoreBefore));
    window.setTimeout(() => {
      if (!highlightLoadedMessage(messageId))
        toast({
          type: "warning",
          title: "Nachricht nicht gefunden",
          description:
            "Der Verlauf wurde geladen, aber die Nachricht ist nicht sichtbar.",
        });
    }, 90);
  }
  async function loadOlderMessages() {
    if (loadingOlder || !messages[0]) return;
    const beforeId = messages[0].id;
    const node = scrollRef.current;
    const previousHeight = node?.scrollHeight || 0;
    setLoadingOlder(true);
    const res = await fetch(
      `${endpoint}?limit=50&before=${encodeURIComponent(beforeId)}`,
      { cache: "no-store" },
    );
    const data = await res.json().catch(() => ({}));
    setLoadingOlder(false);
    if (!res.ok)
      return toast({
        type: "error",
        title: "Ältere Nachrichten konnten nicht geladen werden",
        description: data.error || undefined,
      });
    const older = Array.isArray(data.messages)
      ? (data.messages as Message[])
      : [];
    setHasMore(Boolean(data.hasMore));
    setMessages((items) => mergeMessages(older, items));
    window.requestAnimationFrame(() => {
      if (!node) return;
      node.scrollTop = node.scrollHeight - previousHeight + node.scrollTop;
    });
  }
  async function runSearch(event?: FormEvent) {
    event?.preventDefault();
    const q = searchQuery.trim();
    if (q.length < 2) return setSearchResults([]);
    setSearching(true);
    const scoped =
      mode === "channel"
        ? `channelId=${encodeURIComponent(id)}`
        : `threadId=${encodeURIComponent(id)}`;
    const res = await fetch(
      `/api/search/messages?q=${encodeURIComponent(q)}&${scoped}`,
      { cache: "no-store" },
    );
    const data = await res.json().catch(() => ({}));
    setSearching(false);
    if (!res.ok)
      return toast({
        type: "error",
        title: "Suche fehlgeschlagen",
        description: data.error || undefined,
      });
    setSearchResults(Array.isArray(data.results) ? data.results : []);
  }

  function highlightedSnippet(text: string, query: string) {
    const clean = query.trim();
    if (!clean) return text || "Anhang";
    const lower = text.toLowerCase();
    const index = lower.indexOf(clean.toLowerCase());
    if (index < 0) return text || "Anhang";
    return (
      <>
        {text.slice(0, index)}
        <mark className="rounded bg-white px-1 text-black">
          {text.slice(index, index + clean.length)}
        </mark>
        {text.slice(index + clean.length)}
      </>
    );
  }

  const canSend = !dmBlockedReason;

  return (
    <div className="grid h-full min-h-0 grid-cols-1 lg:grid-cols-[1fr_260px] max-md:pb-safe">
      <div className="flex min-w-0 flex-col">
        <div className="flex items-center justify-between gap-4 border-b border-white/10 px-4 py-3 sm:px-5 sm:py-4">
          <div className="min-w-0">
            <h2 className="truncate font-semibold tracking-[-.02em]">
              {title}
            </h2>
            {subtitle && (
              <p className="truncate text-xs text-zinc-500">{subtitle}</p>
            )}
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                setSearchOpen(true);
                window.setTimeout(
                  () => document.getElementById("nexo-chat-search")?.focus(),
                  50,
                );
              }}
              className="soft-button inline-flex items-center gap-2 px-3 py-2 text-xs max-sm:px-2"
            >
              <Search size={14} /> <span className="max-sm:hidden">Suche</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setPinOpen(true);
                void refreshPins();
              }}
              className="soft-button inline-flex items-center gap-2 px-3 py-2 text-xs max-sm:px-2"
            >
              <Pin size={14} /> <span className="max-sm:hidden">Pins</span>{" "}
              <span className="rounded-full bg-white px-1.5 py-0.5 text-[10px] font-bold text-black">
                {pinCount}
              </span>
            </button>
            <div className="hidden items-center gap-2 rounded-full border border-white/10 bg-white/[.03] px-3 py-1 text-[11px] text-zinc-400 sm:flex">
              {connected ? <Wifi size={13} /> : <WifiOff size={13} />}
              {connected ? "Live" : "Fallback"}
            </div>
          </div>
        </div>
        <div
          ref={scrollRef}
          onScroll={updateNearBottom}
          className="nexo-scrollbar relative min-h-0 flex-1 overflow-y-auto p-3 sm:p-5"
        >
          <div className="space-y-1">
            {!loadingMessages && hasMore && (
              <div className="mb-4 flex justify-center">
                <button
                  type="button"
                  onClick={loadOlderMessages}
                  disabled={loadingOlder}
                  className="soft-button inline-flex items-center gap-2 px-4 py-2 text-xs"
                >
                  {loadingOlder && (
                    <Loader2 size={13} className="animate-spin" />
                  )}{" "}
                  Ältere Nachrichten laden
                </button>
              </div>
            )}
            {!loadingMessages && !hasMore && messages.length > 0 && (
              <div className="mb-4 text-center text-[11px] text-zinc-700">
                Anfang des Chats erreicht
              </div>
            )}
            {loadingMessages && messages.length === 0 && (
              <div className="space-y-5">
                <MessageSkeleton />
                <MessageSkeleton />
                <MessageSkeleton />
              </div>
            )}
            {!loadingMessages && messages.length === 0 && (
              <div className="mx-auto mt-16 max-w-md rounded-[2rem] border border-dashed border-white/10 bg-white/[.025] p-8 text-center text-sm text-zinc-500">
                <div className="mx-auto mb-4 grid h-12 w-12 place-items-center rounded-2xl border border-white/10 bg-white/[.04]">
                  <Send size={18} />
                </div>
                <h3 className="text-lg font-semibold text-zinc-100">
                  Noch ganz ruhig hier
                </h3>
                <p className="mt-2 leading-6">
                  Starte die Unterhaltung oder pinne später wichtige Nachrichten
                  oben an.
                </p>
              </div>
            )}
            {messages.map((message, index) => {
              const previous = messages[index - 1];
              const showDivider =
                !previous ||
                dateLabel(previous.createdAt) !== dateLabel(message.createdAt);
              const grouped = sameMessageGroup(previous, message);
              const attachments = parseAttachments(message.attachments);
              const canDelete = me && message.author.id === me.id;
              return (
                <div key={message.id} data-message-id={message.id}>
                  {showDivider && (
                    <div className="my-5 flex items-center gap-3">
                      <span className="h-px flex-1 bg-white/10" />
                      <span className="rounded-full border border-white/10 bg-black/40 px-3 py-1 text-[11px] text-zinc-500">
                        {dateLabel(message.createdAt)}
                      </span>
                      <span className="h-px flex-1 bg-white/10" />
                    </div>
                  )}
                  <div
                    className={`group relative flex gap-3 rounded-3xl px-2 py-1.5 transition hover:bg-white/[.025] ${grouped ? "mt-0" : "mt-3"}`}
                  >
                    <div className="w-10 shrink-0">
                      {grouped ? (
                        <span className="block pt-2 text-right text-[10px] text-zinc-700 opacity-0 group-hover:opacity-100">
                          {new Date(message.createdAt).toLocaleTimeString(
                            "de-DE",
                            { hour: "2-digit", minute: "2-digit" },
                          )}
                        </span>
                      ) : (
                        <Avatar user={message.author} />
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      {!grouped && (
                        <div className="mb-1 flex items-center gap-2">
                          <span className="text-sm font-medium">
                            {message.author.displayName}
                          </span>
                          <span className="text-xs text-zinc-600">
                            {new Date(message.createdAt).toLocaleTimeString(
                              "de-DE",
                              { hour: "2-digit", minute: "2-digit" },
                            )}
                          </span>
                          {message.editedAt && (
                            <span className="text-xs text-zinc-600">
                              bearbeitet
                            </span>
                          )}
                          {message.pending && (
                            <span className="inline-flex items-center gap-1 text-xs text-zinc-500">
                              <Loader2 size={12} className="animate-spin" />{" "}
                              sendet
                            </span>
                          )}
                          {message.failed && (
                            <span className="text-xs text-red-300">
                              nicht gesendet
                            </span>
                          )}
                        </div>
                      )}
                      <div className="relative rounded-3xl border border-white/10 bg-white/[.035] px-4 py-3 text-sm leading-6 text-zinc-200">
                        <div className="absolute right-3 top-2 z-10 hidden items-center gap-1 rounded-full border border-white/10 bg-[#09090b]/95 p-1 shadow-2xl shadow-black/40 backdrop-blur-md group-hover:flex group-focus-within:flex">
                          <button
                            type="button"
                            onClick={() => setReplyTarget(message)}
                            className="rounded-full p-1.5 text-zinc-400 transition hover:bg-white/10 hover:text-white"
                            title="Antworten"
                          >
                            <Reply size={14} />
                          </button>
                          <button
                            type="button"
                            onClick={() => setReactionTarget(message)}
                            className="rounded-full p-1.5 text-zinc-400 transition hover:bg-white/10 hover:text-white"
                            title="Reagieren"
                          >
                            <Smile size={14} />
                          </button>
                          {canPin && (
                            <button
                              type="button"
                              onClick={() => pinMessage(message)}
                              className="rounded-full p-1.5 text-zinc-400 transition hover:bg-white/10 hover:text-white"
                              title="Pinnen"
                            >
                              <Pin size={14} />
                            </button>
                          )}
                          {me?.id !== message.author.id && (
                            <button
                              type="button"
                              onClick={() => {
                                setReportTarget(message);
                                setReportReason(
                                  "Spam oder störendes Verhalten",
                                );
                                setReportDetails("");
                              }}
                              className="rounded-full p-1.5 text-zinc-400 transition hover:bg-amber-500/10 hover:text-amber-100"
                              title="Melden"
                            >
                              <Flag size={14} />
                            </button>
                          )}
                          {canDelete && (
                            <button
                              type="button"
                              onClick={() => {
                                setEditing(message);
                                setEditText(message.content);
                              }}
                              className="rounded-full p-1.5 text-zinc-400 transition hover:bg-white/10 hover:text-white"
                              title="Bearbeiten"
                            >
                              <Edit3 size={14} />
                            </button>
                          )}
                          {canDelete && (
                            <button
                              type="button"
                              onClick={() => setDeleteTarget(message)}
                              className="rounded-full p-1.5 text-zinc-400 transition hover:bg-red-500/15 hover:text-red-200"
                              title="Löschen"
                            >
                              <Trash2 size={14} />
                            </button>
                          )}
                        </div>
                        {message.replyTo && (
                          <button
                            type="button"
                            onClick={() =>
                              void jumpToMessage(message.replyTo?.id || "")
                            }
                            className="mb-2 block w-full rounded-2xl border-l-2 border-white/20 bg-black/25 px-3 py-2 text-left text-xs text-zinc-400"
                          >
                            <span className="font-medium text-zinc-200">
                              Antwort an{" "}
                              {message.replyTo.author?.displayName ||
                                "Nachricht"}
                            </span>
                            <br />
                            {message.replyTo.deletedAt
                              ? "Nachricht nicht verfügbar"
                              : message.replyTo.content || "Anhang"}
                          </button>
                        )}
                        {message.deletedAt ? (
                          <em className="text-zinc-500">
                            Diese Nachricht wurde gelöscht.
                          </em>
                        ) : (
                          <>
                            {message.content && (
                              <SimpleMarkdown text={message.content} />
                            )}
                            <MessageAttachments
                              files={attachments}
                              onPreview={setLightbox}
                            />
                          </>
                        )}
                        {reactionSummary(message.reactions).length > 0 && (
                          <div className="relative mt-3 flex flex-wrap gap-1.5">
                            {reactionSummary(message.reactions).map(
                              ([emoji, users]) => {
                                const active = me
                                  ? users.includes(me.id)
                                  : false;
                                const previewOpen =
                                  reactionPreview?.messageId === message.id &&
                                  reactionPreview.emoji === emoji;
                                return (
                                  <span
                                    key={emoji}
                                    className="relative inline-flex"
                                    onMouseEnter={() =>
                                      void loadReactionPreview(message, emoji)
                                    }
                                    onFocus={() =>
                                      void loadReactionPreview(message, emoji)
                                    }
                                  >
                                    <button
                                      type="button"
                                      onClick={() =>
                                        reactToMessage(message, emoji)
                                      }
                                      title={`${users.length} Reaktion(en)`}
                                      className={`rounded-full border px-2.5 py-1 text-xs transition active:scale-95 ${active ? "border-white/40 bg-white text-black shadow-lg shadow-white/10" : "border-white/10 bg-black/30 text-zinc-200 hover:bg-white/10"}`}
                                    >
                                      {emoji}{" "}
                                      <span className="opacity-70">
                                        {users.length}
                                      </span>
                                    </button>
                                    {previewOpen && (
                                      <div
                                        className="absolute bottom-full left-0 z-30 mb-2 w-64 rounded-2xl border border-white/10 bg-[#09090b]/95 p-2 text-left shadow-2xl shadow-black/50 backdrop-blur-xl"
                                        onMouseLeave={() =>
                                          setReactionPreview(null)
                                        }
                                      >
                                        <p className="mb-2 px-2 text-[11px] font-semibold uppercase tracking-[.18em] text-zinc-500">
                                          {emoji} Reaktionen
                                        </p>
                                        {reactionPreview.loading ? (
                                          <p className="px-2 py-2 text-xs text-zinc-500">
                                            Lade...
                                          </p>
                                        ) : reactionPreview.users.length ? (
                                          reactionPreview.users.map((user) => (
                                            <div
                                              key={user.id}
                                              className="flex items-center gap-2 rounded-xl px-2 py-1.5"
                                            >
                                              <Avatar user={user} size="sm" />
                                              <div className="min-w-0">
                                                <p className="truncate text-xs font-medium text-zinc-100">
                                                  {user.displayName}
                                                  {user.id === me?.id
                                                    ? " · du"
                                                    : ""}
                                                </p>
                                                <p className="truncate text-[11px] text-zinc-500">
                                                  @{user.username}
                                                </p>
                                              </div>
                                            </div>
                                          ))
                                        ) : (
                                          <p className="px-2 py-2 text-xs text-zinc-500">
                                            Keine sichtbaren User.
                                          </p>
                                        )}
                                      </div>
                                    )}
                                  </span>
                                );
                              },
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
            <div ref={endRef} />
          </div>
          {!nearBottom && (
            <button
              type="button"
              onClick={() => scrollToBottom()}
              className="sticky bottom-3 mx-auto mt-4 flex items-center gap-2 rounded-full border border-white/10 bg-white text-black px-4 py-2 text-xs font-semibold shadow-2xl"
            >
              <ArrowDown size={14} />{" "}
              {newCount > 0 ? `${newCount} neue` : "Zum neuesten"}
            </button>
          )}
        </div>
        <form onSubmit={submit} className="border-t border-white/10 p-3 sm:p-4">
          {typingLabel && (
            <p className="mb-2 text-xs text-zinc-500">{typingLabel}</p>
          )}
          {error && (
            <div className="mb-2 flex items-center justify-between gap-3 rounded-2xl border border-red-400/20 bg-red-500/10 px-3 py-2 text-xs text-red-100">
              <span>{error}</span>
              <button
                type="button"
                onClick={focusInput}
                className="rounded-full border border-red-200/20 px-2 py-1"
              >
                Erneut versuchen
              </button>
            </div>
          )}
          {dmBlockedReason && (
            <div className="mb-3 rounded-2xl border border-red-400/20 bg-red-500/10 px-4 py-3 text-xs leading-5 text-red-100">
              {dmBlockedReason}
            </div>
          )}
          {replyTarget && (
            <div className="mb-3 flex items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/[.035] px-3 py-2 text-xs text-zinc-400">
              <span className="truncate">
                Antwort an{" "}
                <b className="text-zinc-200">
                  {replyTarget.author.displayName}
                </b>
                : {replyTarget.content || "Anhang"}
              </span>
              <button
                type="button"
                onClick={() => setReplyTarget(null)}
                className="rounded-full p-1 hover:bg-white/10"
              >
                <X size={13} />
              </button>
            </div>
          )}
          {files.length > 0 && (
            <div className="mb-3 flex flex-wrap gap-2">
              {files.map((file, index) => (
                <div
                  key={`${file.name}-${index}`}
                  className="flex items-center gap-2 rounded-2xl border border-white/10 bg-white/[.04] px-3 py-2 text-xs text-zinc-300"
                >
                  {attachmentIcon({ name: file.name, mimeType: file.type })}
                  <span className="max-w-[220px] truncate">{file.name}</span>
                  <span className="text-zinc-600">
                    {formatBytes(file.size)}
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      setFiles((current) =>
                        current.filter((_, i) => i !== index),
                      )
                    }
                    className="rounded-full p-1 hover:bg-white/10"
                  >
                    <X size={12} />
                  </button>
                </div>
              ))}
            </div>
          )}
          <div className="relative flex gap-2 rounded-3xl border border-white/10 bg-black/30 p-2 focus-within:border-white/20">
            <input
              ref={fileInputRef}
              type="file"
              multiple
              className="hidden"
              onChange={(event) => onPickFiles(event.target.files)}
            />
            <button
              type="button"
              disabled={!canSend}
              onClick={() => fileInputRef.current?.click()}
              className="soft-button self-end p-3 disabled:cursor-not-allowed disabled:opacity-50"
              title="Dateien hochladen"
            >
              <Paperclip size={16} />
            </button>
            <button
              type="button"
              disabled={!canSend}
              onClick={() => setEmojiOpen((open) => !open)}
              className="soft-button self-end p-3 disabled:cursor-not-allowed disabled:opacity-50"
              title="Emojis"
            >
              <Smile size={16} />
            </button>
            {emojiOpen && (
              <>
                <button
                  type="button"
                  aria-label="Emoji-Auswahl schließen"
                  className="fixed inset-0 z-40 cursor-default bg-transparent"
                  onClick={() => {
                    setEmojiOpen(false);
                    focusInput();
                  }}
                />
                <div
                  onMouseDown={(event) => event.stopPropagation()}
                  onClick={(event) => event.stopPropagation()}
                  className="absolute bottom-[72px] left-0 z-50 w-[382px] max-sm:left-[-54px] max-sm:w-[calc(100vw-32px)]"
                >
                  <FullEmojiPicker onSelect={insertEmoji} />
                </div>
              </>
            )}
            <textarea
              ref={inputRef}
              value={text}
              disabled={!canSend}
              onChange={(event) => onText(event.target.value)}
              onBlur={() =>
                socketRef.current?.emit(typingEvent, {
                  [payloadKey]: id,
                  typing: false,
                })
              }
              onKeyDown={(event: KeyboardEvent<HTMLTextAreaElement>) => {
                if (event.key === "Enter" && !event.shiftKey) {
                  event.preventDefault();
                  event.currentTarget.form?.requestSubmit();
                }
              }}
              placeholder={
                canSend ? "Nachricht schreiben..." : "Senden ist blockiert"
              }
              className="min-h-[44px] flex-1 resize-none bg-transparent px-3 py-3 text-sm outline-none placeholder:text-zinc-600 disabled:cursor-not-allowed disabled:opacity-60"
              maxLength={4000}
            />
            <button
              disabled={
                !canSend || isSending || (!text.trim() && files.length === 0)
              }
              className="primary-button self-end p-3 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {isSending ? (
                <Loader2 size={16} className="animate-spin" />
              ) : (
                <Send size={16} />
              )}
            </button>
          </div>
        </form>
      </div>
      <aside className="hidden border-l border-white/10 bg-black/20 p-4 lg:block">
        <p className="label mb-3">Mitglieder</p>
        <div className="space-y-2">
          {members.map((member) => (
            <div
              key={member.user.id}
              className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[.03] p-2"
            >
              <Avatar user={member.user} size="sm" />
              <div className="min-w-0">
                <p className="truncate text-sm">{member.user.displayName}</p>
                <p className="text-xs text-zinc-500">
                  {member.user.status.toLowerCase().replaceAll("_", " ")}
                </p>
              </div>
            </div>
          ))}
          {members.length === 0 && (
            <p className="text-sm text-zinc-500">
              Details werden hier angezeigt.
            </p>
          )}
        </div>
      </aside>
      <Modal
        open={Boolean(reactionTarget)}
        title="Reaktion hinzufügen"
        description="Wähle ein Emoji für diese Nachricht."
        onClose={() => setReactionTarget(null)}
        size="sm"
      >
        <div className="mb-3 flex gap-2">
          {["👍", "❤️", "😂", "😮", "🔥"].map((emoji) => (
            <button
              key={emoji}
              type="button"
              onClick={() =>
                reactionTarget && reactToMessage(reactionTarget, emoji)
              }
              className="rounded-2xl border border-white/10 bg-white/[.04] px-3 py-2 text-lg hover:bg-white/[.08]"
            >
              {emoji}
            </button>
          ))}
        </div>
        <div className="overflow-hidden rounded-[28px]">
          <FullEmojiPicker
            onSelect={(emoji) =>
              reactionTarget && reactToMessage(reactionTarget, emoji)
            }
          />
        </div>
      </Modal>
      <Modal
        open={pinOpen}
        title="Gepinnte Nachrichten"
        description="Wichtige Nachrichten in diesem Chat. Klick öffnet die Nachricht im Verlauf."
        onClose={() => setPinOpen(false)}
      >
        <div className="space-y-3">
          {loadingPins && (
            <div className="rounded-2xl border border-white/10 bg-white/[.03] p-4 text-sm text-zinc-500">
              Pins werden geladen...
            </div>
          )}
          {!loadingPins && pins.length === 0 && (
            <div className="rounded-3xl border border-dashed border-white/10 p-6 text-center text-sm text-zinc-500">
              Noch keine Pins. Nutze das Pin-Symbol an einer Nachricht.
            </div>
          )}
          {pins.map((pin) => {
            const pinnedMessage = pin.message || pin.dmMessage || null;
            const attachments = parseAttachments(pinnedMessage?.attachments);
            const content = pinnedMessage?.deletedAt
              ? "Diese Nachricht wurde gelöscht."
              : pinnedMessage?.content ||
                (attachments.length ? "Anhang" : "Keine Vorschau");
            return (
              <div
                key={pin.id}
                className="rounded-3xl border border-white/10 bg-white/[.035] p-4"
              >
                <div className="mb-3 flex items-center gap-3">
                  {pinnedMessage?.author && (
                    <Avatar user={pinnedMessage.author} size="sm" />
                  )}
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">
                      {pinnedMessage?.author?.displayName ||
                        "Gelöschte Nachricht"}
                    </p>
                    <p className="text-xs text-zinc-500">
                      gepinnt {new Date(pin.createdAt).toLocaleString("de-DE")}
                      {pin.pinnedBy?.displayName
                        ? ` · von ${pin.pinnedBy.displayName}`
                        : ""}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  disabled={!pinnedMessage}
                  onClick={() => {
                    if (pinnedMessage) {
                      setPinOpen(false);
                      void jumpToMessage(pinnedMessage.id);
                    }
                  }}
                  className="block w-full rounded-2xl border border-white/10 bg-black/25 p-3 text-left text-sm leading-6 text-zinc-300 transition hover:bg-white/[.05] disabled:cursor-not-allowed disabled:opacity-70"
                >
                  <span className="line-clamp-3 break-words">{content}</span>
                  {attachments.length > 0 && (
                    <span className="mt-2 inline-flex items-center gap-1 rounded-full border border-white/10 px-2 py-1 text-[11px] text-zinc-500">
                      <Paperclip size={11} /> {attachments.length} Anhang
                      {attachments.length === 1 ? "" : "änge"}
                    </span>
                  )}
                </button>
                {canPin && pinnedMessage && (
                  <div className="mt-3 flex justify-end">
                    <button
                      type="button"
                      onClick={() => unpinMessage(pinnedMessage.id)}
                      className="soft-button px-3 py-2 text-xs"
                    >
                      <X size={13} /> Entpinnen
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </Modal>
      <Modal
        open={searchOpen}
        title="Nachrichten suchen"
        description="Suche nur in diesem aktuell zugänglichen Chat."
        onClose={() => setSearchOpen(false)}
      >
        <form onSubmit={runSearch} className="mb-4 flex gap-2">
          <input
            id="nexo-chat-search"
            value={searchQuery}
            onChange={(event) => setSearchQuery(event.target.value)}
            className="field"
            placeholder="Suchbegriff..."
          />
          <button
            className="primary-button"
            disabled={searching || searchQuery.trim().length < 2}
          >
            {searching ? (
              <Loader2 size={16} className="animate-spin" />
            ) : (
              <Search size={16} />
            )}
          </button>
        </form>
        <div className="space-y-2">
          {searchResults.length === 0 && (
            <div className="rounded-3xl border border-dashed border-white/10 p-6 text-center text-sm text-zinc-500">
              Keine Ergebnisse oder noch nicht gesucht.
            </div>
          )}
          {searchResults.map((result) => (
            <button
              key={result.message.id}
              type="button"
              onClick={() => {
                setSearchOpen(false);
                void jumpToMessage(result.message.id);
              }}
              className="block w-full rounded-2xl border border-white/10 bg-white/[.035] p-3 text-left transition hover:bg-white/[.06]"
            >
              <p className="truncate text-sm font-medium">
                {result.message.author.displayName}
              </p>
              <p className="mt-1 line-clamp-2 text-sm leading-6 text-zinc-400">
                {highlightedSnippet(
                  result.message.content || "Anhang",
                  searchQuery,
                )}
              </p>
              <p className="mt-1 text-xs text-zinc-600">
                {new Date(result.message.createdAt).toLocaleString("de-DE")}
              </p>
            </button>
          ))}
        </div>
      </Modal>

      <Modal
        open={Boolean(reportTarget)}
        title="Nachricht melden"
        description="Der Report wird nur für Admins sichtbar und enthält den nötigen Chat-Kontext."
        onClose={() => !submittingReport && setReportTarget(null)}
        size="sm"
      >
        <form onSubmit={submitReport} className="space-y-4">
          <div className="rounded-2xl border border-white/10 bg-black/30 p-3 text-sm text-zinc-300">
            <p className="text-xs uppercase tracking-[.18em] text-zinc-600">
              Vorschau
            </p>
            <p className="mt-2 line-clamp-3 break-words">
              {reportTarget?.content || "Nachricht mit Anhang"}
            </p>
          </div>
          <label className="block space-y-2">
            <span className="label">Grund</span>
            <select
              value={reportReason}
              onChange={(event) => setReportReason(event.target.value)}
              className="field"
            >
              <option>Spam oder störendes Verhalten</option>
              <option>Beleidigung oder Belästigung</option>
              <option>Gefährliche Inhalte</option>
              <option>Private Daten / Doxxing</option>
              <option>Sonstiges</option>
            </select>
          </label>
          <label className="block space-y-2">
            <span className="label">Beschreibung optional</span>
            <textarea
              value={reportDetails}
              onChange={(event) => setReportDetails(event.target.value)}
              className="field min-h-24 resize-none"
              maxLength={600}
              placeholder="Was sollen Admins wissen?"
            />
          </label>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              disabled={submittingReport}
              onClick={() => setReportTarget(null)}
              className="soft-button"
            >
              Abbrechen
            </button>
            <button disabled={submittingReport} className="primary-button">
              {submittingReport && (
                <Loader2 size={14} className="animate-spin" />
              )}{" "}
              Melden
            </button>
          </div>
        </form>
      </Modal>
      <Modal
        open={Boolean(deleteTarget)}
        title="Nachricht löschen?"
        description="Diese Nachricht verschwindet für alle in diesem Chat."
        onClose={() => setDeleteTarget(null)}
        size="sm"
      >
        <div className="space-y-4">
          <div className="rounded-2xl border border-white/10 bg-black/30 p-4 text-sm text-zinc-400">
            {deleteTarget?.content ? (
              <SimpleMarkdown text={deleteTarget.content} />
            ) : (
              "Diese Nachricht enthält nur Anhänge."
            )}
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              className="soft-button"
              onClick={() => setDeleteTarget(null)}
            >
              Abbrechen
            </button>
            <button
              type="button"
              className="rounded-2xl border border-red-400/20 bg-red-500/15 px-4 py-2 text-sm font-medium text-red-100 transition hover:bg-red-500/25"
              onClick={() => deleteTarget && deleteMessage(deleteTarget)}
            >
              Löschen
            </button>
          </div>
        </div>
      </Modal>
      <Modal
        open={Boolean(editing)}
        title="Nachricht bearbeiten"
        onClose={() => setEditing(null)}
        size="sm"
      >
        <form onSubmit={saveEdit} className="space-y-4">
          <textarea
            className="field min-h-32 resize-none"
            value={editText}
            onChange={(event) => setEditText(event.target.value)}
            autoFocus
            maxLength={4000}
          />
          <div className="flex justify-end gap-2">
            <button
              type="button"
              className="soft-button"
              onClick={() => setEditing(null)}
            >
              Abbrechen
            </button>
            <button className="primary-button">Speichern</button>
          </div>
        </form>
      </Modal>
      <Modal
        open={Boolean(lightbox)}
        title={lightbox?.name || "Bild"}
        onClose={() => setLightbox(null)}
        size="lg"
      >
        <div className="overflow-hidden rounded-3xl border border-white/10 bg-black">
          {lightbox && (
            <img
              src={lightbox.url}
              alt={lightbox.name}
              className="max-h-[72vh] w-full object-contain"
            />
          )}
        </div>
        {lightbox && (
          <div className="mt-3 flex items-center justify-between text-xs text-zinc-500">
            <span>{formatBytes(lightbox.size)}</span>
            <a
              href={lightbox.url}
              target="_blank"
              rel="noreferrer"
              className="soft-button inline-flex items-center gap-2"
            >
              <Download size={14} /> Download
            </a>
          </div>
        )}
      </Modal>
    </div>
  );
}
