"use client";

import data from "@emoji-mart/data";
import Picker from "@emoji-mart/react";

type EmojiSelection = {
  native?: string;
  unified?: string;
  shortcodes?: string;
  name?: string;
};

type Props = {
  onSelect: (emoji: string) => void;
};

function emojiFromUnified(unified?: string) {
  if (!unified) return "";
  try {
    return unified
      .split("-")
      .map((part) => String.fromCodePoint(Number.parseInt(part, 16)))
      .join("");
  } catch {
    return "";
  }
}

export function FullEmojiPicker({ onSelect }: Props) {
  return (
    <div className="nexo-emoji-picker overflow-hidden rounded-[28px] border border-white/10 bg-[#050505] shadow-[0_24px_90px_rgba(0,0,0,.95)] ring-1 ring-black/80">
      <Picker
        data={data}
        theme="dark"
        locale="de"
        set="native"
        navPosition="top"
        previewPosition="none"
        searchPosition="sticky"
        skinTonePosition="preview"
        maxFrequentRows={2}
        perLine={8}
        emojiSize={22}
        emojiButtonSize={38}
        noCountryFlags={false}
        autoFocus
        onEmojiSelect={(emoji: EmojiSelection) => {
          const value = emoji.native || emojiFromUnified(emoji.unified);
          if (value) onSelect(value);
        }}
      />
    </div>
  );
}
