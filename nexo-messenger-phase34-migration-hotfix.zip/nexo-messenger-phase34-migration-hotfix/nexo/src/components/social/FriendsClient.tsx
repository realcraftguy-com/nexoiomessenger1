"use client";

import { FormEvent, ReactNode, useEffect, useMemo, useState } from "react";
import { io } from "socket.io-client";
import {
  Check,
  Clock3,
  Loader2,
  MessageCircle,
  Search,
  UserMinus,
  UserPlus,
  Users,
  X,
} from "lucide-react";
import { useRouter } from "next/navigation";
import { Avatar } from "@/components/ui/Avatar";
import { Notice } from "@/components/ui/Notice";
import { Modal } from "@/components/ui/Modal";
import { useToast } from "@/hooks/use-toast";

type User = {
  id: string;
  username: string;
  displayName: string;
  avatarUrl?: string | null;
  avatarColor: string;
  status?: string;
};
type FriendRequest = {
  id: string;
  senderId: string;
  receiverId: string;
  user?: User | null;
  createdAt: string;
};
type Friendship = {
  id: string;
  userAId: string;
  userBId: string;
  user?: User | null;
  createdAt: string;
};

type FriendData = {
  incoming: FriendRequest[];
  outgoing: FriendRequest[];
  friendships: Friendship[];
};

function StatusDot({ status }: { status?: string }) {
  const online = status === "ONLINE";
  return (
    <span
      className={`size-2.5 rounded-full ${online ? "bg-emerald-300" : "bg-zinc-600"}`}
    />
  );
}

export function FriendsClient() {
  const router = useRouter();
  const { toast } = useToast();
  const [data, setData] = useState<FriendData>({
    incoming: [],
    outgoing: [],
    friendships: [],
  });
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [notice, setNotice] = useState("");
  const [onlineOnly, setOnlineOnly] = useState(false);
  const [removeTarget, setRemoveTarget] = useState<Friendship | null>(null);

  const onlineFriends = useMemo(
    () => data.friendships.filter((item) => item.user?.status === "ONLINE"),
    [data.friendships],
  );
  const visibleFriends = useMemo(
    () =>
      [...(onlineOnly ? onlineFriends : data.friendships)].sort(
        (a, b) =>
          Number(b.user?.status === "ONLINE") -
            Number(a.user?.status === "ONLINE") ||
          (a.user?.displayName || "").localeCompare(b.user?.displayName || ""),
      ),
    [data.friendships, onlineFriends, onlineOnly],
  );

  async function load() {
    const res = await fetch("/api/friends/requests", { cache: "no-store" });
    setLoading(false);
    if (!res.ok) return;
    setData(await res.json());
  }

  useEffect(() => {
    void load();
  }, []);
  useEffect(() => {
    const socket = io({
      withCredentials: true,
      transports: ["websocket", "polling"],
    });
    const refresh = () => {
      void load();
    };
    socket.on("friend:request:new", () => {
      toast({ type: "info", title: "Neue Freundschaftsanfrage" });
      refresh();
    });
    socket.on("friend:request:updated", refresh);
    socket.on("friend:added", () => {
      toast({ type: "success", title: "Freundschaft aktualisiert" });
      refresh();
    });
    socket.on("friend:removed", () => {
      toast({ type: "warning", title: "Freundschaft entfernt" });
      refresh();
    });
    socket.on("user:block:changed", refresh);
    return () => {
      socket.disconnect();
    };
  }, [toast]);

  async function search(event: FormEvent) {
    event.preventDefault();
    const clean = query.trim();
    setNotice("");
    if (clean.length < 2) return setNotice("Gib mindestens 2 Zeichen ein.");
    const res = await fetch(
      `/api/users/search?q=${encodeURIComponent(clean)}`,
      { cache: "no-store" },
    );
    const json = await res.json().catch(() => ({}));
    if (!res.ok)
      return toast({
        type: "error",
        title: json.error || "Suche fehlgeschlagen",
      });
    setResults(Array.isArray(json.users) ? json.users : []);
  }

  async function sendRequest(userId: string) {
    setBusyId(userId);
    const res = await fetch("/api/friends/requests", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ userId }),
    });
    const json = await res.json().catch(() => ({}));
    setBusyId(null);
    if (!res.ok)
      return toast({
        type: "error",
        title: json.error || "Anfrage fehlgeschlagen",
      });
    toast({
      type: "success",
      title: json.alreadyFriends
        ? "Ihr seid bereits Freunde"
        : json.incomingPending
          ? "Diese Person hat dir schon eine Anfrage gesendet"
          : "Freundschaftsanfrage gesendet",
    });
    setResults([]);
    setQuery("");
    await load();
  }

  async function respond(requestId: string, action: "accept" | "reject") {
    setBusyId(requestId);
    const res = await fetch(`/api/friends/requests/${requestId}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action }),
    });
    const json = await res.json().catch(() => ({}));
    setBusyId(null);
    if (!res.ok)
      return toast({
        type: "error",
        title: json.error || "Aktion fehlgeschlagen",
      });
    toast({
      type: "success",
      title: action === "accept" ? "Anfrage angenommen" : "Anfrage abgelehnt",
    });
    await load();
  }

  async function cancelRequest(requestId: string) {
    setBusyId(requestId);
    const res = await fetch(`/api/friends/requests/${requestId}`, {
      method: "DELETE",
    });
    const json = await res.json().catch(() => ({}));
    setBusyId(null);
    if (!res.ok)
      return toast({
        type: "error",
        title: json.error || "Abbrechen fehlgeschlagen",
      });
    toast({ type: "success", title: "Anfrage abgebrochen" });
    await load();
  }

  async function removeFriend(friendshipId: string) {
    setBusyId(friendshipId);
    const res = await fetch(`/api/friends/${friendshipId}`, {
      method: "DELETE",
    });
    const json = await res.json().catch(() => ({}));
    setBusyId(null);
    if (!res.ok)
      return toast({
        type: "error",
        title: json.error || "Entfernen fehlgeschlagen",
      });
    toast({ type: "success", title: "Freund entfernt" });
    setRemoveTarget(null);
    await load();
  }

  async function openDm(userId: string) {
    setBusyId(userId);
    const res = await fetch("/api/dms", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ userId }),
    });
    const json = await res.json().catch(() => ({}));
    setBusyId(null);
    if (!res.ok)
      return toast({
        type: "error",
        title: json.error || "DM konnte nicht geöffnet werden",
      });
    if (json.state === "accepted" && json.thread?.id)
      router.push(`/app/@me?thread=${json.thread.id}`);
    else
      toast({
        type: "info",
        title: "DM-Anfrage ist offen",
        description: "Der Chat startet nach Annahme der Anfrage.",
      });
  }

  function UserCard({
    user,
    children,
  }: {
    user?: User | null;
    children: ReactNode;
  }) {
    if (!user) return null;
    return (
      <div className="rounded-3xl border border-white/10 bg-white/[.035] p-4">
        <div className="flex items-center gap-3">
          <Avatar user={user} />
          <div className="min-w-0 flex-1">
            <p className="truncate font-medium">{user.displayName}</p>
            <p className="flex items-center gap-2 text-xs text-zinc-500">
              <StatusDot status={user.status} /> @{user.username}
            </p>
          </div>
          {children}
        </div>
      </div>
    );
  }

  if (loading)
    return (
      <div className="grid h-full place-items-center text-sm text-zinc-500">
        <Loader2 className="mr-2 animate-spin" size={16} /> Lade Freunde...
      </div>
    );

  return (
    <div className="nexo-scrollbar h-full overflow-y-auto p-4 sm:p-6">
      <div className="mx-auto max-w-6xl space-y-6">
        <header className="rounded-[2rem] border border-white/10 bg-white/[.035] p-6">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <p className="text-xs font-bold uppercase tracking-[.18em] text-zinc-600">
                Nexo Social
              </p>
              <h1 className="mt-2 text-3xl font-semibold tracking-[-.06em]">
                Freunde
              </h1>
              <p className="mt-2 text-sm leading-6 text-zinc-500">
                Freunde, Online-Status und Anfragen sind hier komplett
                bedienbar.
              </p>
            </div>
            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              <div className="rounded-2xl border border-white/10 bg-black/20 p-3">
                <b className="block text-lg text-white">
                  {data.friendships.length}
                </b>
                Freunde
              </div>
              <div className="rounded-2xl border border-white/10 bg-black/20 p-3">
                <b className="block text-lg text-white">
                  {onlineFriends.length}
                </b>
                Online
              </div>
              <div className="rounded-2xl border border-white/10 bg-black/20 p-3">
                <b className="block text-lg text-white">
                  {data.incoming.length}
                </b>
                Anfragen
              </div>
            </div>
          </div>
        </header>
        {notice && <Notice>{notice}</Notice>}
        <form
          onSubmit={search}
          className="flex gap-2 rounded-3xl border border-white/10 bg-black/20 p-2"
        >
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            className="field border-0 bg-transparent"
            placeholder="User suchen und Freundschaftsanfrage senden..."
          />
          <button className="primary-button">
            <Search size={16} /> Suchen
          </button>
        </form>
        {results.length > 0 && (
          <section className="grid gap-3 md:grid-cols-2">
            {results.map((user) => (
              <UserCard key={user.id} user={user}>
                <button
                  disabled={busyId === user.id}
                  onClick={() => sendRequest(user.id)}
                  className="soft-button px-3 py-2 text-xs"
                >
                  {busyId === user.id ? (
                    <Loader2 size={14} className="animate-spin" />
                  ) : (
                    <UserPlus size={14} />
                  )}{" "}
                  Hinzufügen
                </button>
              </UserCard>
            ))}
          </section>
        )}

        <div className="grid gap-6 xl:grid-cols-2">
          <section className="space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h2 className="flex items-center gap-2 font-semibold">
                <Users size={18} /> Freunde
              </h2>
              <label className="flex items-center gap-2 rounded-full border border-white/10 bg-white/[.03] px-3 py-2 text-xs text-zinc-400">
                <input
                  type="checkbox"
                  checked={onlineOnly}
                  onChange={(event) => setOnlineOnly(event.target.checked)}
                />{" "}
                Nur online
              </label>
            </div>
            {data.friendships.length === 0 && (
              <div className="rounded-3xl border border-dashed border-white/10 p-6 text-center text-sm text-zinc-500">
                Noch keine Freunde. Suche oben einen User.
              </div>
            )}
            {data.friendships.length > 0 && visibleFriends.length === 0 && (
              <div className="rounded-3xl border border-dashed border-white/10 p-6 text-center text-sm text-zinc-500">
                Gerade ist keiner deiner Freunde online.
              </div>
            )}
            {visibleFriends.map((friendship) => (
              <UserCard key={friendship.id} user={friendship.user}>
                <div className="flex gap-2">
                  <button
                    onClick={() =>
                      friendship.user && openDm(friendship.user.id)
                    }
                    disabled={
                      !friendship.user || busyId === friendship.user?.id
                    }
                    className="soft-button px-3 py-2 text-xs"
                  >
                    <MessageCircle size={14} /> DM
                  </button>
                  <button
                    onClick={() => setRemoveTarget(friendship)}
                    disabled={busyId === friendship.id}
                    className="rounded-2xl border border-red-400/20 bg-red-500/10 px-3 py-2 text-xs text-red-100"
                  >
                    <UserMinus size={14} />
                  </button>
                </div>
              </UserCard>
            ))}
          </section>
          <section className="space-y-5">
            <div className="space-y-3">
              <h2 className="font-semibold">Eingehende Anfragen</h2>
              {data.incoming.length === 0 && (
                <p className="rounded-3xl border border-dashed border-white/10 p-4 text-sm text-zinc-500">
                  Keine offenen eingehenden Anfragen.
                </p>
              )}
              {data.incoming.map((request) => (
                <UserCard key={request.id} user={request.user}>
                  <div className="flex gap-2">
                    <button
                      disabled={busyId === request.id}
                      onClick={() => respond(request.id, "accept")}
                      className="primary-button px-3 py-2 text-xs"
                    >
                      <Check size={14} />
                    </button>
                    <button
                      disabled={busyId === request.id}
                      onClick={() => respond(request.id, "reject")}
                      className="soft-button px-3 py-2 text-xs"
                    >
                      <X size={14} />
                    </button>
                  </div>
                </UserCard>
              ))}
            </div>
            <div className="space-y-3">
              <h2 className="font-semibold">Ausgehend</h2>
              {data.outgoing.length === 0 && (
                <p className="rounded-3xl border border-dashed border-white/10 p-4 text-sm text-zinc-500">
                  Keine ausgehenden Anfragen.
                </p>
              )}
              {data.outgoing.map((request) => (
                <UserCard key={request.id} user={request.user}>
                  <button
                    disabled={busyId === request.id}
                    onClick={() => cancelRequest(request.id)}
                    className="soft-button px-3 py-2 text-xs"
                  >
                    <Clock3 size={14} /> Abbrechen
                  </button>
                </UserCard>
              ))}
            </div>
          </section>
        </div>
      </div>
      <Modal
        open={Boolean(removeTarget)}
        title="Freund entfernen?"
        description={
          removeTarget?.user
            ? `${removeTarget.user.displayName} wird aus deiner Freundesliste entfernt.`
            : undefined
        }
        onClose={() => setRemoveTarget(null)}
        size="sm"
      >
        <div className="space-y-4">
          <div className="rounded-2xl border border-red-400/20 bg-red-500/10 p-4 text-sm text-red-100">
            Ihr könnt danach wieder eine neue Anfrage senden.
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              className="soft-button"
              onClick={() => setRemoveTarget(null)}
            >
              Abbrechen
            </button>
            <button
              type="button"
              className="rounded-2xl border border-red-400/20 bg-red-500/15 px-4 py-2 text-sm text-red-100"
              onClick={() => removeTarget && removeFriend(removeTarget.id)}
            >
              Entfernen
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
