"use client";

import { FormEvent, ReactNode, useEffect, useMemo, useState } from "react";
import { io } from "socket.io-client";
import {
  Activity,
  Ban,
  Bell,
  Bot,
  Check,
  Code2,
  Eye,
  Gamepad2,
  ImagePlus,
  KeyRound,
  Languages,
  Link2,
  LogOut,
  Monitor,
  Palette,
  Save,
  Search,
  Shield,
  SlidersHorizontal,
  Sparkles,
  UserRound,
  Volume2,
  Zap
} from "lucide-react";
import clsx from "clsx";
import { Avatar } from "@/components/ui/Avatar";
import { CustomSelect } from "@/components/ui/CustomSelect";
import { Notice } from "@/components/ui/Notice";

const colors = ["#ffffff", "#e5e7eb", "#d4d4d8", "#a1a1aa", "#71717a", "#38bdf8", "#34d399", "#fbbf24", "#fb7185", "#a78bfa", "#f97316", "#22c55e"];
const statusOptions = [
  { value: "ONLINE", label: "Online", description: "Du bist erreichbar" },
  { value: "BUSY", label: "Beschäftigt", description: "Du wirkst beschäftigt" },
  { value: "DO_NOT_DISTURB", label: "Nicht stören", description: "Ruhiger Modus" },
  { value: "OFFLINE", label: "Offline", description: "Du wirkst unsichtbar" }
];

type SectionId =
  | "account"
  | "profile"
  | "privacy"
  | "authorized"
  | "connections"
  | "notifications"
  | "appearance"
  | "voice"
  | "activity"
  | "accessibility"
  | "hotkeys"
  | "language"
  | "sessions"
  | "developer"
  | "logout";

type SettingsSectionItem = {
  id: SectionId;
  label: string;
  icon: any;
  danger?: boolean;
};

type SettingsSectionGroup = {
  group: string;
  items: SettingsSectionItem[];
};

type BlockedUser = { id: string; blockedId: string; createdAt: string; user?: { id: string; username: string; displayName: string; avatarUrl?: string | null; avatarColor: string; status?: string } | null };

const sections: SettingsSectionGroup[] = [
  { group: "Account", items: [
    { id: "account", label: "Account", icon: UserRound },
    { id: "profile", label: "Profile", icon: Sparkles },
    { id: "privacy", label: "Daten & Privatsphäre", icon: Shield },
    { id: "authorized", label: "Autorisierte Apps", icon: Bot },
    { id: "connections", label: "Verknüpfungen", icon: Link2 }
  ] },
  { group: "Erlebnis", items: [
    { id: "notifications", label: "Benachrichtigungen", icon: Bell },
    { id: "appearance", label: "Erscheinungsbild", icon: Palette },
    { id: "voice", label: "Sprach- & Videochat", icon: Volume2 },
    { id: "activity", label: "Aktivität", icon: Gamepad2 },
    { id: "accessibility", label: "Barrierefreiheit", icon: Eye },
    { id: "hotkeys", label: "Hotkeys", icon: Zap },
    { id: "language", label: "Sprache & Zeit", icon: Languages }
  ] },
  { group: "Erweitert", items: [
    { id: "sessions", label: "Geräte & Sessions", icon: Monitor },
    { id: "developer", label: "Entwickler", icon: Code2 },
    { id: "logout", label: "Abmelden", icon: LogOut, danger: true }
  ] }
];

function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return <label className="block space-y-2"><span className="label">{label}</span>{children}{hint && <span className="block text-xs leading-5 text-zinc-500">{hint}</span>}</label>;
}

function Toggle({ name, label, description, defaultChecked }: { name: string; label: string; description: string; defaultChecked?: boolean }) {
  return (
    <label className="flex items-center justify-between gap-4 rounded-3xl border border-white/10 bg-white/[.035] p-4 transition hover:border-white/20 hover:bg-white/[.055]">
      <span>
        <span className="block text-sm font-medium text-white">{label}</span>
        <span className="mt-1 block text-xs leading-5 text-zinc-500">{description}</span>
      </span>
      <input name={name} type="checkbox" defaultChecked={defaultChecked} className="h-5 w-5 accent-white" />
    </label>
  );
}

function SettingCard({ title, description, children, icon: Icon }: { title: string; description?: string; children: ReactNode; icon?: any }) {
  return (
    <section className="rounded-[2rem] border border-white/10 bg-white/[.035] p-5 shadow-2xl shadow-black/20">
      <div className="mb-5 flex items-start gap-3">
        {Icon && <span className="grid size-10 place-items-center rounded-2xl border border-white/10 bg-white/[.05] text-zinc-200"><Icon size={18} /></span>}
        <div>
          <h3 className="text-lg font-semibold tracking-[-.03em] text-white">{title}</h3>
          {description && <p className="mt-1 text-sm leading-6 text-zinc-500">{description}</p>}
        </div>
      </div>
      {children}
    </section>
  );
}

export function SettingsClient() {
  const [me, setMe] = useState<any>(null);
  const [active, setActive] = useState<SectionId>("account");
  const [query, setQuery] = useState("");
  const [avatarUrl, setAvatarUrl] = useState("");
  const [avatarColor, setAvatarColor] = useState("#ffffff");
  const [accentColor, setAccentColor] = useState("#ffffff");
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [twoFactorCode, setTwoFactorCode] = useState("");
  const [savingProfile, setSavingProfile] = useState(false);
  const [saving2fa, setSaving2fa] = useState(false);
  const [loggingOutAll, setLoggingOutAll] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [blockedUsers, setBlockedUsers] = useState<BlockedUser[]>([]);

  const allItems = useMemo(() => sections.flatMap((section) => section.items), []);
  const activeItem = allItems.find((item) => item.id === active);

  async function load() {
    const res = await fetch("/api/auth/me", { cache: "no-store" });
    if (!res.ok) return;
    const user = (await res.json()).user;
    setMe(user);
    setAvatarUrl(user.avatarUrl || "");
    setAvatarColor(user.avatarColor || "#ffffff");
    setAccentColor(user.accentColor || user.avatarColor || "#ffffff");
    loadBlocklist().catch(() => undefined);
  }

  useEffect(() => { load(); }, []);
  useEffect(() => {
    const socket = io({ withCredentials: true, transports: ["websocket", "polling"] });
    socket.on("user:block:changed", () => { void loadBlocklist(); });
    return () => { socket.disconnect(); };
  }, []);

  async function loadBlocklist() {
    const res = await fetch("/api/users/blocked", { cache: "no-store" });
    if (res.ok) setBlockedUsers(((await res.json()).blocks || []) as BlockedUser[]);
  }

  async function unblockUser(userId: string) {
    const res = await fetch(`/api/users/${userId}/block`, { method: "DELETE" });
    if (!res.ok) return setMessage({ type: "error", text: "User konnte nicht entblockt werden." });
    setMessage({ type: "success", text: "User entblockt." });
    await loadBlocklist();
  }

  async function onAvatarChange(file?: File) {
    if (!file) return;
    if (!["image/png", "image/jpeg", "image/webp"].includes(file.type)) return setMessage({ type: "error", text: "Nur PNG, JPG/JPEG oder WebP sind erlaubt." });
    if (file.size > 2_000_000) return setMessage({ type: "error", text: "Avatar ist zu groß. Maximal 2 MB." });
    const form = new FormData();
    form.append("avatar", file);
    setUploadingAvatar(true);
    const res = await fetch("/api/uploads/avatar", { method: "POST", body: form });
    const data = await res.json().catch(() => ({}));
    setUploadingAvatar(false);
    if (!res.ok) return setMessage({ type: "error", text: data.error || "Avatar konnte nicht hochgeladen werden." });
    setAvatarUrl(String(data.avatarUrl || ""));
    setMessage({ type: "success", text: "Avatar sicher hochgeladen." });
  }

  async function removeAvatar() {
    const res = await fetch("/api/uploads/avatar", { method: "DELETE" });
    if (!res.ok) return setMessage({ type: "error", text: "Avatar konnte nicht entfernt werden." });
    setAvatarUrl("");
    setMessage({ type: "success", text: "Avatar entfernt." });
  }

  async function saveProfile(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!me) return;
    setSavingProfile(true);
    setMessage(null);
    const form = new FormData(event.currentTarget);
    const payload = {
      displayName: String(form.get("displayName") || me.displayName),
      username: String(form.get("username") || me.username),
      avatarUrl,
      avatarColor,
      accentColor,
      bio: String(form.get("bio") || ""),
      pronouns: String(form.get("pronouns") || ""),
      location: String(form.get("location") || ""),
      customStatus: String(form.get("customStatus") || ""),
      compactMode: Boolean(form.get("compactMode")),
      reduceMotion: Boolean(form.get("reduceMotion")),
      showOnline: Boolean(form.get("showOnline")),
      allowDmRequests: Boolean(form.get("allowDmRequests")),
      status: String(form.get("status") || me.status),
      onboarded: true
    };
    const res = await fetch("/api/settings/profile", { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify(payload) });
    const data = await res.json().catch(() => ({}));
    setSavingProfile(false);
    if (!res.ok) return setMessage({ type: "error", text: data.error || "Einstellungen konnten nicht gespeichert werden." });
    setMe(data.user);
    setMessage({ type: "success", text: "Gespeichert." });
  }

  async function setTwoFactor(enabled: boolean) {
    setSaving2fa(true);
    setMessage(null);
    const res = await fetch("/api/settings/security", { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ enabled, code: enabled ? twoFactorCode : "" }) });
    const data = await res.json().catch(() => ({}));
    setSaving2fa(false);
    if (!res.ok) return setMessage({ type: "error", text: data.error || "Sicherheit konnte nicht geändert werden." });
    setMe((current: typeof me) => current ? ({ ...current, twoFactorEnabled: data.user.twoFactorEnabled }) : current);
    setTwoFactorCode("");
    setMessage({ type: "success", text: enabled ? "Login-PIN ist aktiviert." : "Login-PIN ist deaktiviert." });
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    window.location.href = "/login";
  }

  async function logoutAll() {
    setLoggingOutAll(true);
    await fetch("/api/settings/sessions/logout-all", { method: "POST" });
    window.location.href = "/login";
  }

  const filteredSections = sections.map((section) => ({
    ...section,
    items: section.items.filter((item) => item.label.toLowerCase().includes(query.toLowerCase()))
  })).filter((section) => section.items.length);

  if (!me) return <div className="grid h-full place-items-center text-sm text-zinc-500">Lade Einstellungen...</div>;

  return (
    <div className="grid h-full min-h-0 grid-cols-[300px_1fr] bg-black/20">
      <aside className="nexo-scrollbar border-r border-white/10 bg-[#0b0b0d] p-4">
        <div className="mb-4 rounded-3xl border border-white/10 bg-white/[.04] p-4">
          <div className="flex items-center gap-3"><Avatar user={me} /><div className="min-w-0"><p className="truncate font-semibold text-white">{me.displayName}</p><p className="truncate text-xs text-zinc-500">@{me.username}</p></div></div>
        </div>
        <div className="relative mb-4">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
          <input value={query} onChange={(e) => setQuery(e.target.value)} className="field h-11 pl-9" placeholder="Einstellungen suchen" />
        </div>
        <nav className="space-y-5">
          {filteredSections.map((section) => (
            <div key={section.group}>
              <p className="mb-2 px-2 text-[11px] font-bold uppercase tracking-[.16em] text-zinc-600">{section.group}</p>
              <div className="space-y-1">
                {section.items.map((item) => {
                  const Icon = item.icon;
                  const selected = active === item.id;
                  return <button key={item.id} onClick={() => item.id === "logout" ? logout() : setActive(item.id)} className={clsx("flex w-full items-center gap-3 rounded-2xl px-3 py-2.5 text-left text-sm transition", selected ? "bg-white text-black" : (item as any).danger ? "text-red-300 hover:bg-red-500/10" : "text-zinc-400 hover:bg-white/[.06] hover:text-white")}><Icon size={17} /> {item.label}</button>;
                })}
              </div>
            </div>
          ))}
        </nav>
      </aside>

      <main className="nexo-scrollbar overflow-y-auto p-6">
        <div className="mx-auto max-w-5xl space-y-6">
          <header className="flex items-end justify-between gap-4 border-b border-white/10 pb-6">
            <div>
              <p className="text-xs font-bold uppercase tracking-[.18em] text-zinc-600">Nexo Einstellungen</p>
              <h1 className="mt-2 text-3xl font-semibold tracking-[-.06em] text-white">{activeItem?.label}</h1>
              <p className="mt-2 max-w-2xl text-sm leading-6 text-zinc-500">Alle Einstellungen sind in Nexo-eigenem Design gebaut: klare Panels, keine Browser-Standardfenster, keine unnötigen technischen Texte.</p>
            </div>
            <div className="hidden rounded-3xl border border-white/10 bg-white/[.035] px-4 py-3 text-xs text-zinc-500 md:block">Account seit {new Date(me.createdAt).toLocaleDateString("de-DE")}</div>
          </header>
          {message && <Notice type={message.type}>{message.text}</Notice>}

          <form onSubmit={saveProfile} className="space-y-6">
            {(active === "account" || active === "profile") && (
              <div className="grid gap-6 xl:grid-cols-[1.15fr_.85fr]">
                <SettingCard title="Profil" description="So sehen dich andere in Chats, DMs, Tickets und Servern." icon={UserRound}>
                  <div className="grid gap-4 sm:grid-cols-2">
                    <Field label="Anzeigename"><input name="displayName" className="field" defaultValue={me.displayName} minLength={2} maxLength={40} /></Field>
                    <Field label="Username"><input name="username" className="field" defaultValue={me.username} minLength={3} maxLength={24} /></Field>
                    <Field label="Pronomen / Kurzinfo"><input name="pronouns" className="field" defaultValue={me.pronouns || ""} maxLength={40} placeholder="Optional" /></Field>
                    <Field label="Ort / Team"><input name="location" className="field" defaultValue={me.location || ""} maxLength={60} placeholder="Optional" /></Field>
                    <div className="sm:col-span-2"><Field label="Über mich"><textarea name="bio" className="field min-h-28 resize-none" defaultValue={me.bio || ""} maxLength={220} placeholder="Kurze Bio" /></Field></div>
                    <div className="sm:col-span-2"><Field label="Custom Status"><input name="customStatus" className="field" defaultValue={me.customStatus || ""} maxLength={80} placeholder="Was machst du gerade?" /></Field></div>
                  </div>
                </SettingCard>
                <SettingCard title="Avatar & Präsenz" icon={ImagePlus}>
                  <div className="rounded-3xl border border-white/10 bg-black/20 p-4">
                    <div className="flex flex-wrap items-center gap-4"><Avatar user={{ ...me, avatarUrl, avatarColor }} size="lg" /><label className="secondary-button cursor-pointer"><input type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={(e) => onAvatarChange(e.target.files?.[0])} /> {uploadingAvatar ? "Lädt hoch..." : "Profilbild hochladen"}</label><button type="button" onClick={removeAvatar} className="soft-button">Avatar entfernen</button></div>
                    <p className="mt-3 text-xs leading-5 text-zinc-500">Neue Avatare laufen über den sicheren Upload: PNG/JPG/WebP, maximal 2 MB, kein SVG und keine externen Tracking-URLs.</p>
                  </div>
                  <div className="mt-5 grid gap-4">
                    <CustomSelect name="status" label="Status" defaultValue={me.status} options={statusOptions} />
                    <Field label="Avatar-Farbe"><div className="flex flex-wrap gap-2">{colors.map((color) => <button key={color} type="button" onClick={() => setAvatarColor(color)} className={clsx("grid size-9 place-items-center rounded-2xl border", avatarColor === color ? "border-white" : "border-white/10")} style={{ backgroundColor: color }}>{avatarColor === color && <Check size={15} className="text-black" />}</button>)}</div></Field>
                    <Field label="Akzentfarbe"><div className="flex flex-wrap gap-2">{colors.map((color) => <button key={color} type="button" onClick={() => setAccentColor(color)} className={clsx("grid size-9 place-items-center rounded-2xl border", accentColor === color ? "border-white" : "border-white/10")} style={{ backgroundColor: color }}>{accentColor === color && <Check size={15} className="text-black" />}</button>)}</div></Field>
                  </div>
                </SettingCard>
              </div>
            )}

            {active === "privacy" && <SettingCard title="Privatsphäre" description="Kontrolliere, wer dich sieht und erreichen kann." icon={Shield}><div className="grid gap-3"><Toggle name="allowDmRequests" label="Nachrichtenanfragen erlauben" description="Andere können dir eine DM-Anfrage senden." defaultChecked={me.allowDmRequests} /><Toggle name="showOnline" label="Status anzeigen" description="Andere sehen deinen Online-/Abwesend-Status." defaultChecked={me.showOnline} /><div className="rounded-3xl border border-white/10 bg-black/20 p-4"><div className="mb-3 flex items-center gap-2"><Ban size={16} /><b>Blockierte User</b></div><p className="mb-3 text-xs leading-5 text-zinc-500">Blockierte User können dir keine neuen DMs senden. Bestehende DMs zeigen einen Hinweis statt zu crashen.</p>{blockedUsers.length === 0 && <p className="rounded-2xl border border-dashed border-white/10 p-4 text-sm text-zinc-500">Niemand ist blockiert.</p>}<div className="space-y-2">{blockedUsers.map((block) => block.user && <div key={block.id} className="flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[.03] p-3"><Avatar user={block.user} size="sm" /><div className="min-w-0 flex-1"><p className="truncate text-sm">{block.user.displayName}</p><p className="truncate text-xs text-zinc-500">@{block.user.username}</p></div><button type="button" onClick={() => unblockUser(block.blockedId)} className="soft-button px-3 py-2 text-xs">Entblocken</button></div>)}</div></div></div></SettingCard>}
            {active === "appearance" && <SettingCard title="Erscheinungsbild" icon={Palette}><div className="grid gap-3"><Toggle name="compactMode" label="Kompakter Modus" description="Mehr Nachrichten auf weniger Platz." defaultChecked={me.compactMode} /><Toggle name="reduceMotion" label="Animationen reduzieren" description="Ruhigeres Interface mit weniger Bewegung." defaultChecked={me.reduceMotion} /></div></SettingCard>}
            {active === "notifications" && <SettingCard title="Benachrichtigungen" description="Visuelle Optionen sind vorbereitet; echte Desktop-Pushs kommen später als eigene App-/Browser-Erlaubnis." icon={Bell}><div className="grid gap-3"><Toggle name="showOnline" label="Visuelle Badges aktiv" description="Ungelesen-Badges und Markierungen anzeigen." defaultChecked /><div className="rounded-3xl border border-white/10 bg-black/20 p-4 text-sm text-zinc-400">Tonprofile, Erwähnungen, Ticket-Hinweise und Ruhezeiten sind als UI vorbereitet und werden in der nächsten Rechte-/Notification-Phase technisch erweitert.</div></div></SettingCard>}
            {active === "accessibility" && <SettingCard title="Barrierefreiheit" icon={Eye}><div className="grid gap-3"><Toggle name="reduceMotion" label="Reduzierte Animationen" description="Übergänge und Motion-Effekte minimieren." defaultChecked={me.reduceMotion} /><div className="rounded-3xl border border-white/10 bg-black/20 p-4 text-sm text-zinc-400">Hoher Kontrast, größere Schrift und Screenreader-Texte sind in der UI vorbereitet.</div></div></SettingCard>}
            {active === "voice" && <SettingCard title="Sprach- & Videochat" description="Voice ist aktuell UI-vorbereitet; WebRTC/Media-Server kommt separat." icon={Volume2}><div className="grid gap-3 sm:grid-cols-2"><div className="rounded-3xl border border-white/10 bg-black/20 p-4"><b>Sprachchat</b><p className="mt-1 text-sm text-zinc-500">Mikrofon, Eingangsgerät und Push-to-Talk vorbereitet.</p></div><div className="rounded-3xl border border-white/10 bg-black/20 p-4"><b>Video & Streaming</b><p className="mt-1 text-sm text-zinc-500">Kamera, Bildschirmfreigabe und Qualität vorbereitet.</p></div></div></SettingCard>}
            {active === "authorized" && <SettingCard title="Autorisierte Apps" icon={Bot}><p className="text-sm text-zinc-500">Noch keine verbundenen Apps. Bot-/OAuth-System ist vorbereitet, aber aktuell deaktiviert.</p></SettingCard>}
            {active === "connections" && <SettingCard title="Verknüpfungen" icon={Link2}><p className="text-sm text-zinc-500">Minecraft, GitHub, Spotify oder Schul-Accounts können später hier verbunden werden.</p></SettingCard>}
            {active === "activity" && <SettingCard title="Aktivität" icon={Gamepad2}><p className="text-sm text-zinc-500">Aktivitätsstatus, registrierte Spiele und Overlay-Optionen sind als Nexo-eigener Bereich vorbereitet.</p></SettingCard>}
            {active === "hotkeys" && <SettingCard title="Hotkeys" icon={Zap}><div className="grid gap-2 text-sm text-zinc-400"><p><kbd className="rounded bg-white/10 px-2 py-1">Ctrl</kbd> + <kbd className="rounded bg-white/10 px-2 py-1">K</kbd> Suche öffnen</p><p><kbd className="rounded bg-white/10 px-2 py-1">Esc</kbd> Dialog schließen</p></div></SettingCard>}
            {active === "language" && <SettingCard title="Sprache & Zeit" icon={Languages}><div className="grid gap-4 sm:grid-cols-2"><Field label="Sprache"><input className="field" value="Deutsch" readOnly /></Field><Field label="Zeitformat"><input className="field" value="24 Stunden" readOnly /></Field></div></SettingCard>}
            {active === "developer" && <SettingCard title="Entwickler" icon={Code2}><div className="rounded-3xl border border-white/10 bg-black/20 p-4 text-sm text-zinc-400">Debug-Infos bleiben absichtlich minimal, damit Nutzer keine Backend-Details sehen. Erweiterte Logs sind nur serverseitig.</div></SettingCard>}

            {["account", "profile", "privacy", "appearance", "notifications", "accessibility"].includes(active) && <button disabled={savingProfile} className="primary-button inline-flex items-center gap-2"><Save size={16} /> {savingProfile ? "Speichert..." : "Änderungen speichern"}</button>}
          </form>

          {active === "account" && <SettingCard title="Sicherheit" description="Zusätzlicher Login-Code schützt deinen Account." icon={KeyRound}><div className="grid gap-4 md:grid-cols-[1fr_auto] md:items-end"><Field label="6-stellige Login-PIN"><input value={twoFactorCode} onChange={(e) => setTwoFactorCode(e.target.value.replace(/\D/g, "").slice(0, 6))} className="field" placeholder="123456" inputMode="numeric" /></Field><button onClick={() => setTwoFactor(true)} disabled={saving2fa || twoFactorCode.length !== 6} className="primary-button">Login-PIN aktivieren</button></div>{me.twoFactorEnabled && <button onClick={() => setTwoFactor(false)} className="secondary-button mt-4">Login-PIN deaktivieren</button>}</SettingCard>}
          {active === "sessions" && <SettingCard title="Geräte & Sessions" description="Sitzungen werden über Session-Versionen abgesichert." icon={Monitor}><div className="rounded-3xl border border-white/10 bg-black/20 p-4 text-sm text-zinc-400"><b className="text-white">Aktuelles Gerät</b><p className="mt-1">Dieser Browser ist aktuell angemeldet.</p></div><button onClick={logoutAll} disabled={loggingOutAll} className="mt-4 rounded-2xl border border-red-400/20 bg-red-500/10 px-4 py-2 text-sm font-semibold text-red-200 hover:bg-red-500/20">Überall abmelden</button></SettingCard>}
        </div>
      </main>
    </div>
  );
}
