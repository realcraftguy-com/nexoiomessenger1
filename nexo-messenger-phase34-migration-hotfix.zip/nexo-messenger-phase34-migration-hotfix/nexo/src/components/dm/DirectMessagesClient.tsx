"use client";

import Link from "next/link";
import { FormEvent, useEffect, useMemo, useRef, useState } from "react";
import { io, Socket } from "socket.io-client";
import {
  Check,
  Clock3,
  Eraser,
  Loader2,
  MoreHorizontal,
  Pencil,
  Search,
  Send,
  Trash2,
  UserMinus,
  X,
} from "lucide-react";
import { useSearchParams } from "next/navigation";
import { ChatPanel } from "@/components/chat/ChatPanel";
import { Avatar } from "@/components/ui/Avatar";
import { Modal } from "@/components/ui/Modal";
import { Notice } from "@/components/ui/Notice";
import clsx from "clsx";

type User = {
  id: string;
  username: string;
  displayName: string;
  avatarUrl?: string | null;
  avatarColor: string;
  status: string;
};
type MeUser = User & { email?: string; isAdmin?: boolean };
type MessagePreview = {
  id: string;
  content: string;
  createdAt: string;
  authorId?: string;
  threadId?: string;
};
type ApiResult = {
  error?: string;
  ok?: boolean;
  state?: string;
  thread?: Thread;
  user?: User;
};
type ThreadMember = {
  userId: string;
  unread: number;
  nickname?: string | null;
  user: User;
};
type Thread = {
  id: string;
  status: "PENDING" | "ACCEPTED";
  requestedById?: string | null;
  updatedAt?: string;
  requestedBy?: User | null;
  members: ThreadMember[];
  messages?: MessagePreview[];
};
type DangerAction = {
  thread: Thread;
  action: "clear_messages" | "delete_thread";
} | null;

export function DirectMessagesClient() {
  const searchParams = useSearchParams();
  const preferredThreadId = searchParams.get("thread");
  const [threads, setThreads] = useState<Thread[]>([]);
  const [selected, setSelected] = useState<Thread | null>(null);
  const [results, setResults] = useState<User[]>([]);
  const [query, setQuery] = useState("");
  const [me, setMe] = useState<MeUser | null>(null);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [loadingRequestId, setLoadingRequestId] = useState<string | null>(null);
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);
  const [nicknameTarget, setNicknameTarget] = useState<Thread | null>(null);
  const [nicknameDraft, setNicknameDraft] = useState("");
  const [dangerAction, setDangerAction] = useState<DangerAction>(null);
  const [confirmText, setConfirmText] = useState("");
  const [actionBusy, setActionBusy] = useState(false);
  const socketRef = useRef<Socket | null>(null);
  const selectedRef = useRef<Thread | null>(null);
  const meRef = useRef<MeUser | null>(null);

  useEffect(() => {
    selectedRef.current = selected;
  }, [selected]);
  useEffect(() => {
    meRef.current = me;
  }, [me]);

  const acceptedThreads = useMemo(
    () => threads.filter((thread) => thread.status === "ACCEPTED"),
    [threads],
  );
  const incomingRequests = useMemo(
    () =>
      threads.filter(
        (thread) =>
          thread.status === "PENDING" && thread.requestedById !== me?.id,
      ),
    [threads, me?.id],
  );
  const outgoingRequests = useMemo(
    () =>
      threads.filter(
        (thread) =>
          thread.status === "PENDING" && thread.requestedById === me?.id,
      ),
    [threads, me?.id],
  );

  async function loadThreads(options?: { keepSelected?: boolean }) {
    const res = await fetch("/api/dms", { cache: "no-store" });
    if (!res.ok) return;
    const data = await res.json();
    const nextThreads: Thread[] = data.threads || [];
    setThreads(nextThreads);
    nextThreads
      .filter((thread) => thread.status === "ACCEPTED")
      .forEach((thread) =>
        socketRef.current?.emit("dm:join", { threadId: thread.id }),
      );

    setSelected((current) => {
      const preferred = preferredThreadId
        ? nextThreads.find(
            (thread) =>
              thread.id === preferredThreadId && thread.status === "ACCEPTED",
          )
        : null;
      if (preferred) return preferred;
      if (!options?.keepSelected && !current)
        return (
          nextThreads.find((thread) => thread.status === "ACCEPTED") || null
        );
      if (!current) return current;
      const fresh = nextThreads.find((thread) => thread.id === current.id);
      return fresh?.status === "ACCEPTED" ? fresh : null;
    });
  }

  function upsertThread(thread: Thread) {
    setThreads((items) => {
      const exists = items.some((item) => item.id === thread.id);
      const next = exists
        ? items.map((item) =>
            item.id === thread.id ? { ...item, ...thread } : item,
          )
        : [thread, ...items];
      return next.sort(
        (a, b) =>
          new Date(b.updatedAt || 0).getTime() -
          new Date(a.updatedAt || 0).getTime(),
      );
    });
    if (thread.status === "ACCEPTED")
      socketRef.current?.emit("dm:join", { threadId: thread.id });
  }

  function removeThread(threadId: string) {
    setThreads((items) => items.filter((thread) => thread.id !== threadId));
    setSelected((current) => (current?.id === threadId ? null : current));
  }

  useEffect(() => {
    const socket = io({
      withCredentials: true,
      transports: ["websocket", "polling"],
    });
    socketRef.current = socket;
    socket.on("connect", () => {
      setThreads((items) => {
        items
          .filter((thread) => thread.status === "ACCEPTED")
          .forEach((thread) => socket.emit("dm:join", { threadId: thread.id }));
        return items;
      });
    });
    socket.on(
      "dm:request:created",
      (payload: { thread: Thread; direction: "incoming" | "outgoing" }) => {
        upsertThread(payload.thread);
        if (payload.direction === "incoming") {
          setNotice("Neue Nachrichtenanfrage erhalten.");
        }
      },
    );
    socket.on("dm:request:accepted", (payload: { thread: Thread }) => {
      upsertThread(payload.thread);
      setSelected((current) => current || payload.thread);
      setNotice("Nachrichtenanfrage angenommen. Ihr könnt jetzt schreiben.");
    });
    socket.on(
      "dm:request:removed",
      (payload: { threadId: string; action?: string }) => {
        removeThread(payload.threadId);
        setNotice(
          payload.action === "cancel"
            ? "Nachrichtenanfrage wurde zurückgezogen."
            : "Nachrichtenanfrage wurde abgelehnt.",
        );
      },
    );
    socket.on("dm:message", (message: MessagePreview) => {
      setThreads((items) => {
        const next = items.map((thread) => {
          if (thread.id !== message.threadId) return thread;
          const active = thread.id === selectedRef.current?.id;
          const exists = thread.messages?.some((m) => m.id === message.id);
          const messages = exists
            ? thread.messages
            : [message, ...(thread.messages || [])];
          const members = exists
            ? thread.members
            : thread.members.map((member) =>
                member.userId === meRef.current?.id
                  ? { ...member, unread: active ? 0 : (member.unread || 0) + 1 }
                  : member,
              );
          return {
            ...thread,
            messages,
            members,
            updatedAt: new Date().toISOString(),
          };
        });
        return next.sort(
          (a, b) =>
            new Date(b.updatedAt || 0).getTime() -
            new Date(a.updatedAt || 0).getTime(),
        );
      });
    });
    socket.on("dm:messages:cleared", ({ threadId }: { threadId: string }) => {
      window.dispatchEvent(
        new CustomEvent("nexo:dm-cleared", { detail: { threadId } }),
      );
      setThreads((items) =>
        items.map((thread) =>
          thread.id === threadId
            ? {
                ...thread,
                messages: [],
                updatedAt: new Date().toISOString(),
                members: thread.members.map((member) => ({
                  ...member,
                  unread: 0,
                })),
              }
            : thread,
        ),
      );
    });
    socket.on("dm:thread:deleted", ({ threadId }: { threadId: string }) => {
      removeThread(threadId);
    });
    socket.on(
      "dm:member:updated",
      ({ threadId, member }: { threadId: string; member: ThreadMember }) => {
        setThreads((items) =>
          items.map((thread) =>
            thread.id === threadId
              ? {
                  ...thread,
                  members: thread.members.map((item) =>
                    item.userId === member.userId
                      ? { ...item, ...member }
                      : item,
                  ),
                }
              : thread,
          ),
        );
      },
    );
    return () => {
      socket.disconnect();
    };
  }, []);

  useEffect(() => {
    fetch("/api/auth/me").then(
      async (res) => res.ok && setMe((await res.json()).user),
    );
    loadThreads();
    const timer = window.setInterval(
      () => loadThreads({ keepSelected: true }),
      7000,
    );
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    function handleMessageEvent(event: Event) {
      const detail = (
        event as CustomEvent<{
          mode?: string;
          id?: string;
          message?: MessagePreview;
        }>
      ).detail;
      if (detail?.mode !== "dm" || !detail.id || !detail.message) return;
      const message = detail.message;
      setThreads((items) => {
        const next = items.map((thread) => {
          if (thread.id !== detail.id) return thread;
          const exists = thread.messages?.some(
            (item) => item.id === message.id,
          );
          const messages = exists
            ? thread.messages
            : [message, ...(thread.messages || [])];
          return { ...thread, messages, updatedAt: new Date().toISOString() };
        });
        return next.sort(
          (a, b) =>
            new Date(b.updatedAt || 0).getTime() -
            new Date(a.updatedAt || 0).getTime(),
        );
      });
    }
    window.addEventListener("nexo:message", handleMessageEvent);
    return () => window.removeEventListener("nexo:message", handleMessageEvent);
  }, []);

  useEffect(() => {
    acceptedThreads.forEach((thread) =>
      socketRef.current?.emit("dm:join", { threadId: thread.id }),
    );
  }, [acceptedThreads.length]);

  async function search(event: FormEvent) {
    event.preventDefault();
    setError("");
    setNotice("");
    const clean = query.trim();
    if (clean.length < 2) return setError("Gib mindestens 2 Zeichen ein.");
    const res = await fetch(`/api/users/search?q=${encodeURIComponent(clean)}`);
    if (res.ok) setResults((await res.json()).users);
  }

  async function requestDm(userId: string) {
    setLoadingRequestId(userId);
    setError("");
    setNotice("");

    const finish = async (ok: boolean, data: ApiResult) => {
      setLoadingRequestId(null);
      if (!ok)
        return setError(data.error || "Anfrage konnte nicht gesendet werden.");
      if (data.thread) upsertThread(data.thread);

      if (data.state === "accepted") {
        setSelected(data.thread || null);
        setNotice("Chat geöffnet.");
      } else if (data.state === "pending_incoming") {
        setNotice(
          "Diese Person hat dir bereits eine Anfrage gesendet. Du kannst sie unten annehmen.",
        );
      } else {
        setNotice("Anfrage gesendet.");
      }
      setResults([]);
      setQuery("");
    };

    if (socketRef.current?.connected) {
      socketRef.current.emit(
        "dm:request:create",
        { userId },
        (result: ApiResult) => finish(!result?.error, result || {}),
      );
      return;
    }

    const res = await fetch("/api/dms", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ userId }),
    });
    const data = await res.json().catch(() => ({}));
    await finish(res.ok, data);
  }

  async function handleRequest(
    thread: Thread,
    action: "accept" | "decline" | "cancel",
  ) {
    setLoadingRequestId(thread.id);
    setError("");
    setNotice("");

    const finish = async (ok: boolean, data: ApiResult) => {
      setLoadingRequestId(null);
      if (!ok)
        return setError(data.error || "Aktion konnte nicht ausgeführt werden.");

      if (action === "accept" && data.thread) {
        upsertThread(data.thread);
        setSelected(data.thread || null);
        setNotice("Anfrage angenommen. Ihr könnt jetzt schreiben.");
      } else if (action === "decline") {
        removeThread(thread.id);
        setNotice("Anfrage abgelehnt.");
      } else {
        removeThread(thread.id);
        setNotice("Anfrage zurückgezogen.");
      }
    };

    if (socketRef.current?.connected) {
      socketRef.current.emit(
        "dm:request:respond",
        { threadId: thread.id, action },
        (result: ApiResult) => finish(!result?.error, result || {}),
      );
      return;
    }

    const res = await fetch(`/api/dms/${thread.id}/request`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action }),
    });
    const data = await res.json().catch(() => ({}));
    await finish(res.ok, data);
  }

  function otherUser(thread: Thread) {
    return (
      thread.members.find((m) => m.userId !== me?.id)?.user ||
      thread.members[0]?.user
    );
  }

  function ownMember(thread: Thread) {
    return thread.members.find((m) => m.userId === me?.id);
  }

  function threadTitle(thread: Thread) {
    return (
      ownMember(thread)?.nickname?.trim() ||
      otherUser(thread)?.displayName ||
      "Unbekannter User"
    );
  }

  function openNicknameModal(thread: Thread) {
    setActiveMenuId(null);
    setNicknameTarget(thread);
    setNicknameDraft(ownMember(thread)?.nickname || "");
  }

  function openDangerModal(
    thread: Thread,
    action: "clear_messages" | "delete_thread",
  ) {
    setActiveMenuId(null);
    setDangerAction({ thread, action });
    setConfirmText("");
  }

  async function saveNickname(event: FormEvent) {
    event.preventDefault();
    if (!nicknameTarget) return;
    setActionBusy(true);
    setError("");
    setNotice("");
    const res = await fetch(`/api/dms/${nicknameTarget.id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ nickname: nicknameDraft }),
    });
    const data = await res.json().catch(() => ({}));
    setActionBusy(false);
    if (!res.ok)
      return setError(
        data.error || "Nickname konnte nicht gespeichert werden.",
      );
    setNicknameTarget(null);
    setNotice(
      nicknameDraft.trim() ? "Nickname gespeichert." : "Nickname entfernt.",
    );
    await loadThreads({ keepSelected: true });
  }

  async function runDangerAction() {
    if (!dangerAction || confirmText !== "LÖSCHEN") return;
    setActionBusy(true);
    setError("");
    setNotice("");
    const res = await fetch(`/api/dms/${dangerAction.thread.id}`, {
      method: "DELETE",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ action: dangerAction.action }),
    });
    const data = await res.json().catch(() => ({}));
    setActionBusy(false);
    if (!res.ok)
      return setError(data.error || "Aktion konnte nicht ausgeführt werden.");

    const deletedThreadId = dangerAction.thread.id;
    const action = dangerAction.action;
    setDangerAction(null);
    setConfirmText("");

    if (action === "clear_messages") {
      window.dispatchEvent(
        new CustomEvent("nexo:dm-cleared", {
          detail: { threadId: deletedThreadId },
        }),
      );
      setThreads((items) =>
        items.map((thread) =>
          thread.id === deletedThreadId
            ? {
                ...thread,
                messages: [],
                updatedAt: new Date().toISOString(),
                members: thread.members.map((member) => ({
                  ...member,
                  unread: 0,
                })),
              }
            : thread,
        ),
      );
      setNotice("Chatverlauf gelöscht.");
    } else {
      setSelected((current) =>
        current?.id === deletedThreadId ? null : current,
      );
      setThreads((items) =>
        items.filter((thread) => thread.id !== deletedThreadId),
      );
      setNotice("Kontakt und Chat wurden entfernt.");
    }
    await loadThreads({ keepSelected: true });
  }

  const other = selected ? otherUser(selected) : null;
  const selectedTitle = selected ? threadTitle(selected) : "";
  const selectedSubtitle =
    selected && other
      ? ownMember(selected)?.nickname
        ? `${other.displayName} · @${other.username}`
        : `@${other.username}`
      : undefined;

  return (
    <div className="grid h-full min-h-0 md:grid-cols-[340px_1fr]">
      <aside className="nexo-scrollbar overflow-y-auto border-r border-white/10 bg-surface-900/60 p-4">
        <Link
          href="/app/@me/friends"
          className="mb-3 flex items-center justify-between rounded-3xl border border-white/10 bg-white/[.035] px-4 py-3 text-sm font-medium text-white transition hover:bg-white/[.07]"
        >
          <span>Freunde</span>
          <span className="rounded-full border border-white/10 px-2 py-1 text-[11px] text-zinc-500">
            {acceptedThreads.length}
          </span>
        </Link>
        <form onSubmit={search} className="mb-4 flex gap-2">
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="User suchen..."
            className="field py-2"
          />
          <button className="soft-button px-3">
            <Search size={16} />
          </button>
        </form>
        {error && (
          <div className="mb-4">
            <Notice type="error">{error}</Notice>
          </div>
        )}
        {notice && (
          <div className="mb-4">
            <Notice>{notice}</Notice>
          </div>
        )}

        {results.length > 0 && (
          <div className="mb-4 rounded-3xl border border-white/10 bg-black/30 p-2">
            <p className="label mb-2 px-2">Gefunden</p>
            {results.map((user) => {
              const disabled = loadingRequestId === user.id;
              return (
                <button
                  key={user.id}
                  disabled={disabled}
                  onClick={() => requestDm(user.id)}
                  className="flex w-full items-center gap-3 rounded-2xl p-2 text-left transition hover:bg-white/[.06] disabled:opacity-60"
                >
                  <Avatar user={user} size="sm" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm">{user.displayName}</p>
                    <p className="truncate text-xs text-zinc-500">
                      @{user.username}
                    </p>
                  </div>
                  <span className="rounded-full border border-white/10 px-2 py-1 text-[11px] text-zinc-400">
                    Anfragen
                  </span>
                </button>
              );
            })}
          </div>
        )}

        {incomingRequests.length > 0 && (
          <section className="mb-5">
            <p className="label mb-3">Nachrichtenanfragen</p>
            <div className="space-y-2">
              {incomingRequests.map((thread) => {
                const user = otherUser(thread);
                return (
                  <div
                    key={thread.id}
                    className="rounded-3xl border border-white/10 bg-white/[.035] p-3"
                  >
                    <div className="mb-3 flex items-center gap-3">
                      <Avatar user={user} size="sm" />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium">
                          {user?.displayName}
                        </p>
                        <p className="truncate text-xs text-zinc-500">
                          @{user?.username} möchte dir schreiben
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button
                        disabled={loadingRequestId === thread.id}
                        onClick={() => handleRequest(thread, "accept")}
                        className="primary-button flex-1 justify-center py-2 text-xs"
                      >
                        <Check size={14} /> Annehmen
                      </button>
                      <button
                        disabled={loadingRequestId === thread.id}
                        onClick={() => handleRequest(thread, "decline")}
                        className="soft-button flex-1 justify-center py-2 text-xs"
                      >
                        <X size={14} /> Ablehnen
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>
        )}

        {outgoingRequests.length > 0 && (
          <section className="mb-5">
            <p className="label mb-3">Ausstehend</p>
            <div className="space-y-2">
              {outgoingRequests.map((thread) => {
                const user = otherUser(thread);
                return (
                  <div
                    key={thread.id}
                    className="rounded-3xl border border-white/10 bg-white/[.025] p-3"
                  >
                    <div className="mb-3 flex items-center gap-3">
                      <Avatar user={user} size="sm" />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium">
                          {user?.displayName}
                        </p>
                        <p className="flex items-center gap-1 truncate text-xs text-zinc-500">
                          <Clock3 size={12} /> wartet auf Zustimmung
                        </p>
                      </div>
                    </div>
                    <button
                      disabled={loadingRequestId === thread.id}
                      onClick={() => handleRequest(thread, "cancel")}
                      className="soft-button w-full justify-center py-2 text-xs"
                    >
                      <X size={14} /> Zurückziehen
                    </button>
                  </div>
                );
              })}
            </div>
          </section>
        )}

        <p className="label mb-3">Direktnachrichten</p>
        <div className="space-y-2">
          {acceptedThreads.map((thread) => {
            const member =
              thread.members.find((m) => m.userId !== me?.id) ||
              thread.members[0];
            const unreadMember = ownMember(thread);
            const last = thread.messages?.[0]?.content;
            const active = selected?.id === thread.id;
            return (
              <div
                key={thread.id}
                className={clsx(
                  "relative flex items-center gap-2 rounded-2xl border p-2 transition",
                  active
                    ? "border-white bg-white text-black"
                    : "border-white/10 bg-white/[.03] hover:bg-white/[.07]",
                )}
              >
                <button
                  onClick={() => setSelected(thread)}
                  className="flex min-w-0 flex-1 items-center gap-3 rounded-xl p-1 text-left"
                >
                  <Avatar user={member.user} size="sm" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">
                      {threadTitle(thread)}
                    </p>
                    <p
                      className={clsx(
                        "truncate text-xs",
                        active ? "text-black/60" : "text-zinc-500",
                      )}
                    >
                      {last || "Noch keine Nachricht"}
                    </p>
                  </div>
                  {(unreadMember?.unread || 0) > 0 && (
                    <span className="rounded-full bg-white px-2 py-0.5 text-xs text-black">
                      {unreadMember?.unread}
                    </span>
                  )}
                </button>
                <button
                  type="button"
                  onClick={(event) => {
                    event.stopPropagation();
                    setActiveMenuId(
                      activeMenuId === thread.id ? null : thread.id,
                    );
                  }}
                  className={clsx(
                    "grid h-9 w-9 shrink-0 place-items-center rounded-xl border transition",
                    active
                      ? "border-black/10 bg-black/[.06] text-black hover:bg-black/[.1]"
                      : "border-white/10 bg-white/[.04] text-zinc-400 hover:text-white",
                  )}
                  aria-label="Chat-Aktionen öffnen"
                >
                  <MoreHorizontal size={16} />
                </button>
                {activeMenuId === thread.id && (
                  <div className="absolute right-2 top-12 z-20 w-56 rounded-2xl border border-white/10 bg-surface-900 p-2 text-white shadow-2xl shadow-black/50">
                    <button
                      type="button"
                      onClick={() => openNicknameModal(thread)}
                      className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-left text-sm text-zinc-200 hover:bg-white/[.07]"
                    >
                      <Pencil size={14} /> Nickname geben
                    </button>
                    <button
                      type="button"
                      onClick={() => openDangerModal(thread, "clear_messages")}
                      className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-left text-sm text-zinc-200 hover:bg-white/[.07]"
                    >
                      <Eraser size={14} /> Chat löschen
                    </button>
                    <button
                      type="button"
                      onClick={() => openDangerModal(thread, "delete_thread")}
                      className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-left text-sm text-red-300 hover:bg-red-500/10"
                    >
                      <UserMinus size={14} /> Kontakt entfernen
                    </button>
                  </div>
                )}
              </div>
            );
          })}
          {acceptedThreads.length === 0 && (
            <p className="rounded-3xl border border-dashed border-white/10 p-4 text-sm text-zinc-500">
              Noch keine bestätigten DMs.
            </p>
          )}
        </div>
      </aside>
      <div className="min-h-0">
        {selected && other ? (
          <ChatPanel
            mode="dm"
            id={selected.id}
            title={selectedTitle}
            subtitle={selectedSubtitle}
          />
        ) : (
          <div className="grid h-full place-items-center p-8 text-center">
            <div className="max-w-md rounded-[2rem] border border-white/10 bg-white/[.035] p-8">
              <div className="mx-auto mb-4 grid h-12 w-12 place-items-center rounded-2xl border border-white/10 bg-white/[.05]">
                <Send size={18} />
              </div>
              <h2 className="text-xl font-semibold tracking-[-.04em]">
                Starte sicher einen Chat
              </h2>
              <p className="mt-2 text-sm leading-6 text-zinc-500">
                Suche einen User und sende eine Anfrage. Nachrichten sind erst
                möglich, wenn die andere Person zustimmt.
              </p>
            </div>
          </div>
        )}
      </div>

      <Modal
        open={!!nicknameTarget}
        title="Nickname ändern"
        description="Der Nickname ist nur für dich sichtbar und ändert nicht das echte Profil der anderen Person."
        onClose={() => !actionBusy && setNicknameTarget(null)}
        size="sm"
      >
        <form onSubmit={saveNickname} className="space-y-4">
          <div>
            <label className="label mb-2 block">Nickname</label>
            <input
              value={nicknameDraft}
              onChange={(event) => setNicknameDraft(event.target.value)}
              className="field"
              placeholder={
                nicknameTarget
                  ? otherUser(nicknameTarget)?.displayName
                  : "Nickname"
              }
              maxLength={32}
            />
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              disabled={actionBusy}
              onClick={() => setNicknameTarget(null)}
              className="soft-button flex-1 justify-center"
            >
              Abbrechen
            </button>
            <button
              disabled={actionBusy}
              className="primary-button flex-1 justify-center"
            >
              {actionBusy && <Loader2 size={14} className="animate-spin" />}{" "}
              Speichern
            </button>
          </div>
        </form>
      </Modal>

      <Modal
        open={!!dangerAction}
        title={
          dangerAction?.action === "clear_messages"
            ? "Chatverlauf löschen?"
            : "Kontakt entfernen?"
        }
        description={
          dangerAction?.action === "clear_messages"
            ? "Alle Nachrichten in diesem Chat werden dauerhaft entfernt. Diese Aktion kann nicht rückgängig gemacht werden."
            : "Der komplette DM-Chat wird entfernt. Danach braucht ihr wieder eine neue Nachrichtenanfrage."
        }
        onClose={() => !actionBusy && setDangerAction(null)}
        size="sm"
      >
        <div className="space-y-4">
          <div className="rounded-2xl border border-red-400/20 bg-red-500/10 p-4 text-sm leading-6 text-red-100">
            {dangerAction?.action === "clear_messages"
              ? "Warnung: Der sichtbare Chatverlauf wird gelöscht."
              : "Warnung: Kontakt und Chat verschwinden aus deiner DM-Liste."}
          </div>
          <div>
            <label className="label mb-2 block">
              Zum Bestätigen LÖSCHEN eingeben
            </label>
            <input
              value={confirmText}
              onChange={(event) => setConfirmText(event.target.value)}
              className="field"
              placeholder="LÖSCHEN"
            />
          </div>
          <div className="flex gap-2">
            <button
              type="button"
              disabled={actionBusy}
              onClick={() => setDangerAction(null)}
              className="soft-button flex-1 justify-center"
            >
              Abbrechen
            </button>
            <button
              type="button"
              disabled={actionBusy || confirmText !== "LÖSCHEN"}
              onClick={runDangerAction}
              className="inline-flex flex-1 items-center justify-center gap-2 rounded-full border border-red-400/30 bg-red-500/15 px-4 py-2 text-sm font-medium text-red-100 transition hover:bg-red-500/25 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {actionBusy ? (
                <Loader2 size={14} className="animate-spin" />
              ) : (
                <Trash2 size={14} />
              )}
              Löschen
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
