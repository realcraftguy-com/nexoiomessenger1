"use client";

import { FormEvent, useEffect, useRef, useState } from "react";
import { io, Socket } from "socket.io-client";
import { LifeBuoy, Loader2, Send, XCircle } from "lucide-react";
import { CustomSelect } from "@/components/ui/CustomSelect";
import { Notice } from "@/components/ui/Notice";
import { Modal } from "@/components/ui/Modal";
import { FilePicker } from "@/components/support/FilePicker";
import { TicketAttachments } from "@/components/support/TicketAttachments";

const categoryOptions = [
  { value: "Allgemein", label: "Allgemein", description: "Fragen und Sonstiges" },
  { value: "Account", label: "Account", description: "Login, Profil, Passwort" },
  { value: "Bug", label: "Bug", description: "Etwas funktioniert nicht" },
  { value: "Server", label: "Server", description: "Channels, Einladungen, Rollen" },
  { value: "AI", label: "Nexo AI", description: "Hilfe mit dem AI-Chat" }
];

const priorityOptions = [
  { value: "LOW", label: "Niedrig", description: "Kann warten" },
  { value: "NORMAL", label: "Normal", description: "Normales Problem" },
  { value: "HIGH", label: "Hoch", description: "Wichtig" },
  { value: "URGENT", label: "Dringend", description: "Blockiert dich komplett" }
];

function mergeTicketList(tickets: any[], updated: any) {
  if (!updated) return tickets;
  const exists = tickets.some((ticket) => ticket.id === updated.id);
  const next = exists ? tickets.map((ticket) => ticket.id === updated.id ? updated : ticket) : [updated, ...tickets];
  return next.sort((a, b) => new Date(b.updatedAt || b.createdAt).getTime() - new Date(a.updatedAt || a.createdAt).getTime());
}

type SupportTab = "active" | "closed" | "all";

export function SupportClient() {
  const [tickets, setTickets] = useState<any[]>([]);
  const [ticketTab, setTicketTab] = useState<SupportTab>("active");
  const [selected, setSelected] = useState<any | null>(null);
  const [reply, setReply] = useState("");
  const [notice, setNotice] = useState<{ type: "success" | "error"; text: string } | null>(null);
  const [createFiles, setCreateFiles] = useState<File[]>([]);
  const [replyFiles, setReplyFiles] = useState<File[]>([]);
  const [closeOpen, setCloseOpen] = useState(false);
  const [closeReason, setCloseReason] = useState("");
  const [closing, setClosing] = useState(false);
  const [sending, setSending] = useState(false);
  const socketRef = useRef<Socket | null>(null);
  const replyInputRef = useRef<HTMLInputElement | null>(null);

  async function load() {
    const res = await fetch("/api/tickets");
    if (res.ok) {
      const data = await res.json();
      setTickets(data.tickets);
      setSelected((current: any) => {
        if (!current) return data.tickets[0] || null;
        return data.tickets.find((ticket: any) => ticket.id === current.id) || data.tickets[0] || null;
      });
    }
  }

  useEffect(() => { load(); }, []);
  useEffect(() => {
    const socket = io({ withCredentials: true, transports: ["websocket", "polling"] });
    socketRef.current = socket;
    socket.on("ticket:message", ({ ticketId, message }) => {
      setTickets((items) => items.map((ticket) => {
        if (ticket.id !== ticketId || ticket.messages.some((item: any) => item.id === message.id)) return ticket;
        return { ...ticket, messages: [...ticket.messages, message], status: message.isStaff ? "ANSWERED" : "OPEN" };
      }));
      setSelected((ticket: any) => {
        if (ticket?.id !== ticketId || ticket.messages.some((item: any) => item.id === message.id)) return ticket;
        return { ...ticket, messages: [...ticket.messages, message], status: message.isStaff ? "ANSWERED" : "OPEN" };
      });
    });
    socket.on("ticket:created", ({ ticket }) => {
      setTickets((items) => mergeTicketList(items, ticket));
      setSelected((current: any) => current || ticket);
    });
    socket.on("ticket:updated", ({ ticket }) => {
      setTickets((items) => mergeTicketList(items, ticket));
      setSelected((current: any) => current?.id === ticket.id ? ticket : current);
    });
    socket.on("ticket:closed", ({ ticket }) => {
      setTickets((items) => mergeTicketList(items, ticket));
      setSelected((current: any) => current?.id === ticket.id ? ticket : current);
    });
    socket.on("ticket:deleted", ({ ticketId }: { ticketId: string }) => {
      setTickets((items) => items.filter((ticket) => ticket.id !== ticketId));
      setSelected((current: any) => current?.id === ticketId ? null : current);
    });
    return () => { socket.disconnect(); };
  }, []);

  useEffect(() => {
    if (selected?.id) socketRef.current?.emit("ticket:join", { ticketId: selected.id });
  }, [selected?.id]);

  async function create(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setNotice(null);
    const form = event.currentTarget;
    const formData = new FormData(form);
    createFiles.forEach((file) => formData.append("files", file));
    const res = await fetch("/api/tickets", { method: "POST", body: formData });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return setNotice({ type: "error", text: data.error || "Ticket konnte nicht erstellt werden." });
    form.reset();
    setCreateFiles([]);
    setNotice({ type: "success", text: "Ticket wurde erstellt." });
    if (data.ticket) {
      setTickets((items) => mergeTicketList(items, data.ticket));
      setSelected(data.ticket);
      socketRef.current?.emit("ticket:sync", { ticketId: data.ticket.id });
    } else {
      await load();
    }
  }

  function focusReplyInput() {
    window.requestAnimationFrame(() => replyInputRef.current?.focus());
  }

  async function sendReply(event: FormEvent) {
    event.preventDefault();
    if (!selected || !reply.trim()) return;
    const content = reply.trim();
    setReply("");
    focusReplyInput();
    setSending(true);
    setNotice(null);

    if (replyFiles.length === 0) {
      socketRef.current?.emit("ticket:message", { ticketId: selected.id, content }, (result: any) => {
        setSending(false);
        if (result?.error) {
          setReply(content);
          setNotice({ type: "error", text: result.error });
        }
        focusReplyInput();
      });
      return;
    }

    const formData = new FormData();
    formData.append("content", content);
    replyFiles.forEach((file) => formData.append("files", file));
    const res = await fetch(`/api/tickets/${selected.id}/messages`, { method: "POST", body: formData });
    const data = await res.json().catch(() => ({}));
    setSending(false);
    if (!res.ok) {
      setReply(content);
      setNotice({ type: "error", text: data.error || "Antwort konnte nicht gesendet werden." });
      focusReplyInput();
      return;
    }
    setReplyFiles([]);
    if (data.message) {
      setTickets((items) => items.map((ticket) => ticket.id === selected.id ? { ...ticket, messages: ticket.messages.some((item: any) => item.id === data.message.id) ? ticket.messages : [...ticket.messages, data.message], status: data.message.isStaff ? "ANSWERED" : "OPEN" } : ticket));
      setSelected((ticket: any) => ticket?.id === selected.id ? { ...ticket, messages: ticket.messages.some((item: any) => item.id === data.message.id) ? ticket.messages : [...ticket.messages, data.message], status: data.message.isStaff ? "ANSWERED" : "OPEN" } : ticket);
      socketRef.current?.emit("ticket:sync", { ticketId: selected.id });
    }
    focusReplyInput();
  }

  function openCloseModal() {
    setCloseReason("");
    setCloseOpen(true);
    setNotice(null);
  }

  async function submitClose(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selected) return;
    const reason = closeReason.trim();
    if (reason.length < 3) return setNotice({ type: "error", text: "Bitte gib einen Grund fürs Schließen an." });
    setClosing(true);
    setNotice(null);
    const socket = socketRef.current;

    if (socket?.connected) {
      socket.emit("ticket:close", { ticketId: selected.id, reason }, async (result: any) => {
        setClosing(false);
        if (result?.error || !result?.ok) {
          setNotice({ type: "error", text: result?.error || "Ticket konnte nicht geschlossen werden." });
          return;
        }
        setCloseOpen(false);
        setSelected(result.ticket);
        setTickets((items) => mergeTicketList(items, result.ticket));
        setNotice({ type: "success", text: "Ticket wurde geschlossen." });
      });
      return;
    }

    const res = await fetch(`/api/tickets/${selected.id}`, { method: "PATCH", headers: { "content-type": "application/json" }, body: JSON.stringify({ reason }) });
    const data = await res.json().catch(() => ({}));
    setClosing(false);
    if (!res.ok) return setNotice({ type: "error", text: data.error || "Ticket konnte nicht geschlossen werden." });
    setCloseOpen(false);
    setTickets((items) => mergeTicketList(items, data.ticket));
    setSelected(data.ticket);
    socketRef.current?.emit("ticket:sync", { ticketId: selected.id });
    setNotice({ type: "success", text: "Ticket wurde geschlossen." });
  }

  const counts = {
    active: tickets.filter((ticket) => ticket.status !== "CLOSED").length,
    closed: tickets.filter((ticket) => ticket.status === "CLOSED").length,
    all: tickets.length
  };
  const tabs: { id: SupportTab; label: string; count: number }[] = [
    { id: "active", label: "Aktiv", count: counts.active },
    { id: "closed", label: "Geschlossen", count: counts.closed },
    { id: "all", label: "Alle", count: counts.all }
  ];
  const visibleTickets = tickets.filter((ticket) => {
    if (ticketTab === "active") return ticket.status !== "CLOSED";
    if (ticketTab === "closed") return ticket.status === "CLOSED";
    return true;
  });

  return (
    <div className="grid h-full min-h-0 lg:grid-cols-[360px_1fr]">
      <aside className="nexo-scrollbar overflow-y-auto border-r border-white/10 bg-surface-900/60 p-4">
        <form onSubmit={create} className="mb-5 rounded-3xl border border-white/10 bg-white/[.03] p-4">
          <div className="mb-4 flex items-center gap-3"><LifeBuoy size={18} /><h2 className="font-semibold">Ticket öffnen</h2></div>
          <div className="space-y-3">
            <input name="title" className="field" placeholder="Titel" required />
            <CustomSelect name="category" defaultValue="Allgemein" options={categoryOptions} />
            <CustomSelect name="priority" defaultValue="NORMAL" options={priorityOptions} />
            <textarea name="description" className="field min-h-28" placeholder="Beschreibe dein Problem..." required />
            <FilePicker id="ticket-create-files" files={createFiles} onChange={setCreateFiles} />
            {notice && <Notice type={notice.type}>{notice.text}</Notice>}
            <button className="primary-button w-full">Ticket erstellen</button>
          </div>
        </form>
        <div className="mb-3 flex items-center justify-between gap-3">
          <p className="label">Meine Tickets</p>
          <span className="text-[11px] text-zinc-600">{counts.active} aktiv</span>
        </div>
        <div className="mb-3 flex gap-2 overflow-x-auto pb-1">
          {tabs.map((tab) => (
            <button key={tab.id} type="button" onClick={() => setTicketTab(tab.id)} className={`shrink-0 rounded-2xl border px-3 py-2 text-xs transition ${ticketTab === tab.id ? "border-white/30 bg-white text-black" : "border-white/10 bg-white/[.03] text-zinc-400 hover:bg-white/[.07] hover:text-white"}`}>
              {tab.label} <span className="ml-1 opacity-60">{tab.count}</span>
            </button>
          ))}
        </div>
        <div className="space-y-2">
          {visibleTickets.length === 0 && <div className="rounded-3xl border border-dashed border-white/10 bg-white/[.02] p-6 text-center text-sm text-zinc-500">Hier ist gerade nichts. Alles aufgeräumt.</div>}
          {visibleTickets.map((ticket) => (
            <button key={ticket.id} onClick={() => setSelected(ticket)} className="w-full rounded-3xl border border-white/10 bg-white/[.03] p-4 text-left transition hover:bg-white/[.07]">
              <div className="flex items-center justify-between gap-3"><p className="font-medium">{ticket.title}</p><span className="rounded-full border border-white/10 px-2 py-1 text-[10px] text-zinc-400">{ticket.status}</span></div>
              <p className="mt-1 text-xs text-zinc-500">{ticket.category} · {ticket.priority}</p>
              {ticket.closeReason && <p className="mt-2 line-clamp-2 text-xs text-red-100/80">Grund: {ticket.closeReason}</p>}
            </button>
          ))}
        </div>
      </aside>
      <section className="flex min-h-0 flex-col">
        {selected ? (
          <>
            <div className="flex items-center justify-between border-b border-white/10 p-5">
              <div><h2 className="font-semibold">{selected.title}</h2><p className="text-xs text-zinc-500">{selected.category} · {selected.priority}</p></div>
              {selected.status !== "CLOSED" && <button onClick={openCloseModal} className="soft-button"><XCircle size={16} /> Schließen</button>}
            </div>
            {selected.status === "CLOSED" && (
              <div className="border-b border-red-400/20 bg-red-500/10 px-5 py-3 text-sm text-red-50">
                Ticket geschlossen. Grund: <b>{selected.closeReason || "Kein Grund angegeben"}</b>
              </div>
            )}
            <div className="nexo-scrollbar min-h-0 flex-1 space-y-4 overflow-y-auto p-5">
              {selected.messages.map((message: any) => (
                <div key={message.id} className="rounded-3xl border border-white/10 bg-white/[.035] p-4">
                  <div className="mb-2 flex items-center justify-between"><p className="text-sm font-medium">{message.author?.displayName || "User"}</p>{message.isStaff && <span className="rounded-full bg-white px-2 py-0.5 text-[10px] font-semibold text-black">STAFF</span>}</div>
                  <p className="whitespace-pre-wrap text-sm leading-6 text-zinc-300">{message.content}</p>
                  <TicketAttachments attachments={message.attachments} />
                </div>
              ))}
            </div>
            <form onSubmit={sendReply} className="border-t border-white/10 p-4">
              <div className="space-y-3 rounded-3xl border border-white/10 bg-black/30 p-2">
                <FilePicker id="ticket-reply-files" files={replyFiles} onChange={setReplyFiles} />
                <div className="flex gap-3">
                  <input ref={replyInputRef} value={reply} onChange={(event) => setReply(event.target.value)} disabled={selected.status === "CLOSED" || sending} className="flex-1 bg-transparent px-3 text-sm outline-none placeholder:text-zinc-600 disabled:opacity-40" placeholder={selected.status === "CLOSED" ? "Ticket ist geschlossen" : "Antwort schreiben..."} />
                  <button disabled={selected.status === "CLOSED" || sending} className="primary-button p-3">{sending ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}</button>
                </div>
              </div>
            </form>
          </>
        ) : <div className="grid h-full place-items-center text-zinc-500">Wähle ein Ticket aus.</div>}
      </section>

      <Modal open={closeOpen} onClose={() => !closing && setCloseOpen(false)} title="Ticket schließen" description="Ein geschlossenes Ticket braucht immer einen Grund, damit später klar ist, was passiert ist.">
        <form onSubmit={submitClose} className="space-y-4">
          <textarea value={closeReason} onChange={(event) => setCloseReason(event.target.value)} className="field min-h-28 resize-none" placeholder="Grund fürs Schließen..." required autoFocus />
          <div className="rounded-3xl border border-red-400/20 bg-red-500/10 p-4 text-sm leading-6 text-red-100">Warnung: Nach dem Schließen kann in diesem Ticket nicht mehr geantwortet werden.</div>
          <div className="flex justify-end gap-3">
            <button type="button" onClick={() => setCloseOpen(false)} disabled={closing} className="soft-button">Abbrechen</button>
            <button disabled={closing} className="primary-button inline-flex items-center gap-2 bg-red-100 text-red-950 hover:bg-red-200">{closing && <Loader2 size={16} className="animate-spin" />} Ticket schließen</button>
          </div>
        </form>
      </Modal>
    </div>
  );
}
