"use client";

import { useState } from "react";
import { Archive, Download, FileText, Image as ImageIcon, Music, Video } from "lucide-react";

type Attachment = {
  id: string;
  name: string;
  url: string;
  mimeType: string;
  size: number;
};

function formatBytes(size: number) {
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

function fileUrl(url: string) {
  if (url.startsWith("/uploads/tickets/")) return `/api/files/tickets/${url.slice("/uploads/tickets/".length)}`;
  return url;
}

function extension(name: string) {
  const clean = name.toLowerCase().split("?")[0];
  const index = clean.lastIndexOf(".");
  return index >= 0 ? clean.slice(index) : "";
}

function fileKind(file: Pick<Attachment, "name" | "mimeType">): "image" | "audio" | "video" | "archive" | "file" {
  const type = file.mimeType || "";
  const ext = extension(file.name);
  if (type.startsWith("image/") || [".jpg", ".jpeg", ".png", ".gif", ".webp", ".avif"].includes(ext)) return "image";
  if (type.startsWith("audio/") || [".mp3", ".ogg", ".oga", ".opus", ".wav", ".flac", ".m4a", ".aac", ".weba", ".mid", ".midi"].includes(ext)) return "audio";
  if (type.startsWith("video/") || [".mp4", ".webm", ".mov", ".m4v"].includes(ext)) return "video";
  if ([".zip", ".rar", ".7z", ".tar", ".gz"].includes(ext)) return "archive";
  return "file";
}

function iconFor(file: Pick<Attachment, "name" | "mimeType">) {
  const kind = fileKind(file);
  if (kind === "image") return <ImageIcon size={17} />;
  if (kind === "audio") return <Music size={17} />;
  if (kind === "video") return <Video size={17} />;
  if (kind === "archive") return <Archive size={17} />;
  return <FileText size={17} />;
}

function ImagePreview({ file }: { file: Attachment }) {
  const [failed, setFailed] = useState(false);
  const src = fileUrl(file.url);

  if (failed) {
    return (
      <a href={src} target="_blank" rel="noreferrer" className="flex items-center gap-3 rounded-2xl border border-red-400/20 bg-red-500/10 p-3 text-sm text-red-100 transition hover:bg-red-500/15">
        <ImageIcon size={18} /> Bild konnte nicht direkt geladen werden. Öffnen
      </a>
    );
  }

  return (
    <a href={src} target="_blank" rel="noreferrer" className="group block overflow-hidden rounded-2xl border border-white/10 bg-black/20 transition hover:border-white/20 hover:bg-white/[.04]">
      <div className="flex max-h-[560px] min-h-0 w-full items-center justify-center bg-black/20">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={src}
          alt={file.name}
          loading="lazy"
          onError={() => setFailed(true)}
          className="h-auto max-h-[560px] w-auto max-w-full object-contain transition group-hover:scale-[1.005]"
        />
      </div>
      <AttachmentMeta file={file} />
    </a>
  );
}

function AttachmentMeta({ file }: { file: Attachment }) {
  return (
    <div className="flex items-center gap-3 border-t border-white/10 p-3">
      <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-white/10 bg-white/[.04]">{iconFor(file)}</div>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium text-zinc-100">{file.name}</p>
        <p className="text-xs text-zinc-500">{formatBytes(file.size)}</p>
      </div>
      <Download size={16} className="text-zinc-500" />
    </div>
  );
}

function AudioCard({ file }: { file: Attachment }) {
  const src = fileUrl(file.url);
  return (
    <div className="overflow-hidden rounded-2xl border border-white/10 bg-black/25">
      <div className="flex items-center gap-3 border-b border-white/10 p-3">
        <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-white/10 bg-white/[.04]"><Music size={17} /></div>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-medium text-zinc-100">{file.name}</p>
          <p className="text-xs text-zinc-500">{formatBytes(file.size)}</p>
        </div>
        <a href={src} target="_blank" rel="noreferrer" className="rounded-xl p-2 text-zinc-500 transition hover:bg-white/10 hover:text-white" title="Öffnen"><Download size={16} /></a>
      </div>
      <div className="p-3">
        <audio controls preload="metadata" src={src} className="w-full" />
      </div>
    </div>
  );
}

function VideoCard({ file }: { file: Attachment }) {
  const src = fileUrl(file.url);
  return (
    <div className="overflow-hidden rounded-2xl border border-white/10 bg-black/25">
      <video controls preload="metadata" src={src} className="max-h-[520px] w-full bg-black object-contain" />
      <AttachmentMeta file={file} />
    </div>
  );
}

function FileCard({ file }: { file: Attachment }) {
  const src = fileUrl(file.url);
  return (
    <a href={src} target="_blank" rel="noreferrer" className="group flex items-center gap-3 rounded-2xl border border-white/10 bg-black/25 p-3 transition hover:border-white/20 hover:bg-white/[.06]">
      <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-white/10 bg-white/[.04]">{iconFor(file)}</div>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium text-zinc-100">{file.name}</p>
        <p className="text-xs text-zinc-500">{formatBytes(file.size)}</p>
      </div>
      <Download size={16} className="text-zinc-500 transition group-hover:text-white" />
    </a>
  );
}

export function TicketAttachments({ attachments }: { attachments?: Attachment[] }) {
  if (!attachments?.length) return null;
  return (
    <div className="mt-3 space-y-3">
      {attachments.map((file) => {
        const kind = fileKind(file);
        if (kind === "image") return <ImagePreview key={file.id} file={file} />;
        if (kind === "audio") return <AudioCard key={file.id} file={file} />;
        if (kind === "video") return <VideoCard key={file.id} file={file} />;
        return <FileCard key={file.id} file={file} />;
      })}
    </div>
  );
}
