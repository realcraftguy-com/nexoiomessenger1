"use client";

import { ChangeEvent } from "react";
import { Paperclip } from "lucide-react";

export function FilePicker({ id, files, onChange }: { id: string; files: File[]; onChange: (files: File[]) => void }) {
  function pick(event: ChangeEvent<HTMLInputElement>) {
    onChange(Array.from(event.target.files || []));
  }
  return (
    <div className="space-y-2">
      <input id={id} type="file" multiple className="hidden" onChange={pick} />
      <label htmlFor={id} className="soft-button inline-flex cursor-pointer items-center gap-2">
        <Paperclip size={16} /> Dateien anhängen
      </label>
      {files.length > 0 && (
        <div className="rounded-2xl border border-white/10 bg-white/[.03] p-3 text-xs text-zinc-400">
          {files.map((file) => <p key={`${file.name}-${file.size}`} className="truncate">{file.name} · {(file.size / 1024 / 1024).toFixed(2)} MB</p>)}
        </div>
      )}
    </div>
  );
}
