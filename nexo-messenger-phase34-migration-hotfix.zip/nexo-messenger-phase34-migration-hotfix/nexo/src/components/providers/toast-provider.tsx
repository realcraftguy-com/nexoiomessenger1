"use client";

import { createContext, ReactNode, useCallback, useContext, useMemo, useState } from "react";
import { CheckCircle2, Info, Loader2, TriangleAlert, X, XCircle } from "lucide-react";
import clsx from "clsx";

type ToastType = "success" | "error" | "warning" | "info" | "loading";
type Toast = { id: string; title: string; description?: string; type: ToastType };
type ToastInput = Omit<Toast, "id"> & { id?: string; duration?: number };

type ToastContextValue = {
  toast: (input: ToastInput | string) => string;
  dismiss: (id: string) => void;
};

const ToastContext = createContext<ToastContextValue | null>(null);

function iconFor(type: ToastType) {
  if (type === "success") return <CheckCircle2 size={17} />;
  if (type === "error") return <XCircle size={17} />;
  if (type === "warning") return <TriangleAlert size={17} />;
  if (type === "loading") return <Loader2 size={17} className="animate-spin" />;
  return <Info size={17} />;
}

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<Toast[]>([]);

  const dismiss = useCallback((id: string) => setItems((current) => current.filter((item) => item.id !== id)), []);

  const toast = useCallback((input: ToastInput | string) => {
    const id = typeof input === "string" ? crypto.randomUUID() : input.id || crypto.randomUUID();
    const next: Toast = typeof input === "string" ? { id, title: input, type: "info" } : { id, title: input.title, description: input.description, type: input.type };
    setItems((current) => [next, ...current.filter((item) => item.id !== id)].slice(0, 5));
    const duration = typeof input === "string" ? 4200 : input.duration ?? (input.type === "loading" ? 0 : 4200);
    if (duration > 0) window.setTimeout(() => dismiss(id), duration);
    return id;
  }, [dismiss]);

  const value = useMemo(() => ({ toast, dismiss }), [toast, dismiss]);

  return (
    <ToastContext.Provider value={value}>
      {children}
      <div className="pointer-events-none fixed right-4 top-4 z-[200] flex w-[min(390px,calc(100vw-32px))] flex-col gap-3">
        {items.map((item) => (
          <div key={item.id} className={clsx("pointer-events-auto animate-fadeUp rounded-3xl border bg-black/90 p-4 shadow-2xl shadow-black/40 backdrop-blur-xl", item.type === "error" ? "border-red-400/25 text-red-50" : item.type === "success" ? "border-emerald-300/25 text-emerald-50" : item.type === "warning" ? "border-amber-300/25 text-amber-50" : "border-white/10 text-white")}> 
            <div className="flex items-start gap-3">
              <span className="mt-0.5 text-zinc-200">{iconFor(item.type)}</span>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold">{item.title}</p>
                {item.description && <p className="mt-1 text-xs leading-5 text-zinc-400">{item.description}</p>}
              </div>
              <button type="button" onClick={() => dismiss(item.id)} className="rounded-full p-1 text-zinc-500 transition hover:bg-white/10 hover:text-white"><X size={14} /></button>
            </div>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToastContext() {
  const value = useContext(ToastContext);
  if (!value) throw new Error("useToastContext must be used inside ToastProvider");
  return value;
}
