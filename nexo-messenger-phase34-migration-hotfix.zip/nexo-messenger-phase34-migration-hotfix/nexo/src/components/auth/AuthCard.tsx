"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { FormEvent, useEffect, useMemo, useState } from "react";
import { ArrowRight, Loader2 } from "lucide-react";

const loadingCopy = {
  login: ["Account wird geprüft", "Session wird vorbereitet", "Nexo wird geöffnet"],
  register: ["Account wird erstellt", "Profil wird vorbereitet", "Onboarding wird geladen"]
};

export function AuthCard({ mode }: { mode: "login" | "register" }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);
  const [error, setError] = useState("");
  const [twoFactorRequired, setTwoFactorRequired] = useState(false);
  const isRegister = mode === "register";
  const steps = useMemo(() => loadingCopy[mode], [mode]);

  useEffect(() => {
    if (typeof window === "undefined") return;
    const params = new URLSearchParams(window.location.search);
    if (params.get("banned") === "1") {
      const reason = params.get("reason") || "Kein Grund angegeben";
      setError(`Du wurdest gesperrt. Grund: ${reason}`);
    } else if (params.get("session") === "revoked") {
      const reason = params.get("reason") || "Deine Sitzung wurde beendet. Bitte melde dich neu an.";
      setError(reason);
    }
  }, []);

  useEffect(() => {
    if (!loading) {
      setLoadingStep(0);
      return;
    }
    const timer = window.setInterval(() => setLoadingStep((step) => (step + 1) % steps.length), 900);
    return () => window.clearInterval(timer);
  }, [loading, steps.length]);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setError("");
    const form = new FormData(event.currentTarget);
    const payload = Object.fromEntries(form.entries());

    const res = await fetch(`/api/auth/${mode}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload)
    });

    const data = await res.json().catch(() => ({}));
    if (res.status === 202 && data.requiresTwoFactor) {
      setLoading(false);
      setTwoFactorRequired(true);
      return setError(data.message || "Bitte gib deinen Login-Code ein.");
    }
    if (!res.ok) {
      setLoading(false);
      return setError(data.error || "Etwas ist fehlgeschlagen");
    }

    const next = typeof window !== "undefined" ? new URLSearchParams(window.location.search).get("next") : null;
    const target = data.user?.onboarded ? next || "/app/@me" : "/onboarding";
    router.push(target);
    router.refresh();
  }

  return (
    <main className="grid min-h-screen place-items-center bg-surface-950 px-4 text-white">
      <div className="absolute inset-0 bg-grid bg-[size:48px_48px] opacity-[.08]" />
      <div className="absolute top-0 h-[440px] w-[640px] rounded-full bg-white/10 blur-[150px]" />
      <form onSubmit={submit} className="panel relative w-full max-w-md overflow-hidden p-6">
        {loading && <div className="absolute inset-x-0 top-0 h-1 overflow-hidden bg-white/10"><div className="h-full w-1/2 animate-pulse rounded-full bg-white" /></div>}

        <Link href="/" className="mb-8 flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-2xl bg-white text-sm font-black text-black">NX</div>
          <div>
            <p className="font-semibold">Nexo</p>
            <p className="text-xs text-zinc-500">Modern Messenger</p>
          </div>
        </Link>

        <h1 className="text-3xl font-semibold tracking-[-.04em]">{isRegister ? "Account erstellen" : "Willkommen zurück"}</h1>
        <p className="mt-2 text-sm leading-6 text-zinc-500">{isRegister ? "Erstelle dein Profil und starte direkt mit Nexo." : "Logge dich ein und spring direkt in deine Chats."}</p>

        <div className="mt-8 space-y-3">
          {isRegister && (
            <>
              <input disabled={loading} className="field disabled:opacity-50" name="displayName" placeholder="Anzeigename" required minLength={2} />
              <input disabled={loading} className="field disabled:opacity-50" name="username" placeholder="Username" required minLength={3} />
            </>
          )}
          <input disabled={loading} className="field disabled:opacity-50" name="email" placeholder="E-Mail" type="email" required />
          <input disabled={loading} className="field disabled:opacity-50" name="password" placeholder="Passwort" type="password" required minLength={isRegister ? 8 : 1} />
          {twoFactorRequired && !isRegister && (
            <input disabled={loading} className="field disabled:opacity-50" name="twoFactorCode" placeholder="6-stelliger Login-Code" inputMode="numeric" pattern="[0-9]{6}" autoFocus required />
          )}
        </div>

        {loading && (
          <div className="mt-4 rounded-2xl border border-white/10 bg-white/[.04] px-4 py-3">
            <div className="flex items-center gap-3 text-sm text-zinc-300">
              <Loader2 size={16} className="animate-spin" />
              <span>{steps[loadingStep]}<span className="inline-block w-5 animate-pulse">...</span></span>
            </div>
          </div>
        )}

        {error && <p className="mt-4 rounded-2xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-200">{error}</p>}

        <button disabled={loading} className="primary-button mt-6 flex w-full items-center justify-center gap-2 py-3 disabled:cursor-not-allowed disabled:opacity-60">
          {loading ? <Loader2 size={16} className="animate-spin" /> : null}
          {loading ? steps[loadingStep] : twoFactorRequired ? "Login-Code prüfen" : isRegister ? "Registrieren" : "Einloggen"} <ArrowRight size={16} />
        </button>

        <p className="mt-5 text-center text-sm text-zinc-500">
          {isRegister ? "Schon einen Account?" : "Noch keinen Account?"} {" "}
          <Link className="text-white underline-offset-4 hover:underline" href={isRegister ? "/login" : "/register"}>{isRegister ? "Login" : "Registrieren"}</Link>
        </p>
      </form>
    </main>
  );
}
