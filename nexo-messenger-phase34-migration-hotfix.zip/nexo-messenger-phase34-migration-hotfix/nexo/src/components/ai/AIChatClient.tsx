"use client";

import { FormEvent, KeyboardEvent, useEffect, useMemo, useRef, useState } from "react";
import { Bot, Copy, Edit3, Loader2, MessageSquarePlus, Plus, RefreshCcw, Send, Sparkles, Square, Trash2 } from "lucide-react";
import { SimpleMarkdown } from "@/lib/markdown";
import { Modal } from "@/components/ui/Modal";
import clsx from "clsx";

type AIMessage = { id: string; role: "user" | "assistant"; content: string; createdAt?: string; streaming?: boolean };
type AIChat = { id: string; title: string; updatedAt: string; messages: AIMessage[] };

function TypingDots() {
  return (
    <span className="inline-flex items-center gap-1 pl-1 align-middle">
      <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-zinc-400 [animation-delay:-.2s]" />
      <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-zinc-400 [animation-delay:-.1s]" />
      <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-zinc-400" />
    </span>
  );
}

function formatDate(value?: string) {
  if (!value) return "";
  try {
    return new Intl.DateTimeFormat("de-DE", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }).format(new Date(value));
  } catch {
    return "";
  }
}

export function AIChatClient() {
  const [chats, setChats] = useState<AIChat[]>([]);
  const [chatId, setChatId] = useState<string | undefined>();
  const [messages, setMessages] = useState<AIMessage[]>([]);
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const [loadingChats, setLoadingChats] = useState(true);
  const [error, setError] = useState("");
  const [renameChat, setRenameChat] = useState<AIChat | null>(null);
  const [renameTitle, setRenameTitle] = useState("");
  const [deleteChat, setDeleteChat] = useState<AIChat | null>(null);
  const bottomRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLTextAreaElement | null>(null);
  const abortRef = useRef<AbortController | null>(null);

  const activeChat = useMemo(() => chats.find((chat) => chat.id === chatId), [chats, chatId]);

  function focusInput() {
    window.requestAnimationFrame(() => inputRef.current?.focus());
  }

  async function load(activeId?: string) {
    setLoadingChats(true);
    const res = await fetch("/api/ai", { cache: "no-store" });
    setLoadingChats(false);
    if (!res.ok) return;

    const data = await res.json();
    const list: AIChat[] = data.chats || [];
    setChats(list);

    const selected = list.find((chat) => chat.id === (activeId || chatId)) || list[0];
    if (selected) {
      setChatId(selected.id);
      setMessages(selected.messages || []);
    } else {
      setChatId(undefined);
      setMessages([]);
    }
  }

  useEffect(() => { load(); }, []);
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" }); }, [messages, loading]);
  useEffect(() => { focusInput(); }, [chatId]);

  async function newChat() {
    if (loading) return;
    setError("");
    const res = await fetch("/api/ai/chats", { method: "POST" });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return setError(data.error || "Chat konnte nicht erstellt werden.");

    setChats((items) => [data.chat, ...items.filter((chat) => chat.id !== data.chat.id)]);
    setChatId(data.chat.id);
    setMessages([]);
    focusInput();
  }

  function selectChat(chat: AIChat) {
    if (loading) return;
    setChatId(chat.id);
    setMessages(chat.messages || []);
    setError("");
    focusInput();
  }

  async function renameSelected(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!renameChat) return;
    const title = renameTitle.trim();
    if (!title) return;

    const res = await fetch(`/api/ai/chats/${renameChat.id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ title })
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return setError(data.error || "Name konnte nicht geändert werden.");

    setChats((items) => items.map((chat) => chat.id === data.chat.id ? { ...chat, title: data.chat.title } : chat));
    setRenameChat(null);
    focusInput();
  }

  async function deleteSelected() {
    if (!deleteChat) return;

    const res = await fetch(`/api/ai/chats/${deleteChat.id}`, { method: "DELETE" });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return setError(data.error || "Chat konnte nicht gelöscht werden.");

    setDeleteChat(null);
    const remaining = chats.filter((chat) => chat.id !== deleteChat.id);
    setChats(remaining);
    const next = remaining[0];
    setChatId(next?.id);
    setMessages(next?.messages || []);
    focusInput();
  }

  async function submit(event?: FormEvent) {
    event?.preventDefault();
    const content = text.trim();
    if (!content || loading) return;

    const userMessage: AIMessage = { id: crypto.randomUUID(), role: "user", content, createdAt: new Date().toISOString() };
    const assistantId = crypto.randomUUID();
    const assistantMessage: AIMessage = { id: assistantId, role: "assistant", content: "", createdAt: new Date().toISOString(), streaming: true };

    setText("");
    setLoading(true);
    setError("");
    setMessages((items) => [...items, userMessage, assistantMessage]);
    focusInput();

    const controller = new AbortController();
    abortRef.current = controller;
    const res = await fetch("/api/ai", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ chatId, content }),
      signal: controller.signal
    });

    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      setLoading(false);
      setMessages((items) => items.filter((msg) => msg.id !== assistantId));
      setError(data.error || "Nexo AI konnte gerade nicht antworten.");
      focusInput();
      return;
    }

    const nextChatId = res.headers.get("x-nexo-chat-id") || chatId;
    if (nextChatId) setChatId(nextChatId);

    const reader = res.body?.getReader();
    const decoder = new TextDecoder();
    let streamed = "";

    try {
      if (!reader) streamed = await res.text();
      else {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          const chunk = decoder.decode(value, { stream: true });
          streamed += chunk;
          setMessages((items) => items.map((msg) => msg.id === assistantId ? { ...msg, content: streamed, streaming: true } : msg));
        }
      }
    } catch {
      setError(controller.signal.aborted ? "Antwort gestoppt." : "Nexo AI wurde beim Antworten unterbrochen.");
    } finally {
      abortRef.current = null;
      setMessages((items) => items.map((msg) => msg.id === assistantId ? { ...msg, content: streamed || "Nexo AI konnte gerade nicht antworten.", streaming: false } : msg));
      setLoading(false);
      focusInput();
      window.setTimeout(() => load(nextChatId), 250);
    }
  }

  function stopGenerating() {
    abortRef.current?.abort();
    setLoading(false);
  }

  function regenerateLast() {
    const lastUser = [...messages].reverse().find((message) => message.role === "user");
    if (!lastUser || loading) return;
    setText(lastUser.content);
    window.setTimeout(() => inputRef.current?.form?.requestSubmit(), 50);
  }

  async function copyText(value: string) {
    await navigator.clipboard.writeText(value).catch(() => undefined);
  }

  function onComposerKeyDown(event: KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      submit();
    }
  }

  return (
    <div className="grid h-full min-h-0 grid-cols-[310px_minmax(0,1fr)] overflow-hidden bg-[#050505] max-lg:grid-cols-1">
      <aside className="hidden min-h-0 border-r border-white/10 bg-[#080808] lg:flex lg:flex-col">
        <div className="shrink-0 border-b border-white/10 p-4">
          <button onClick={newChat} className="primary-button flex w-full items-center justify-center gap-2">
            <MessageSquarePlus size={16} /> Neuer Chat
          </button>
        </div>

        <div className="nexo-scrollbar min-h-0 flex-1 space-y-2 overflow-y-auto p-3">
          {loadingChats && <div className="rounded-3xl border border-white/10 bg-white/[.035] p-4 text-sm text-zinc-500">Chats werden geladen...</div>}
          {!loadingChats && chats.length === 0 && (
            <div className="rounded-3xl border border-white/10 bg-white/[.035] p-4 text-sm leading-6 text-zinc-500">
              Noch keine AI-Chats. Erstelle einen neuen Chat oder schreibe direkt los.
            </div>
          )}
          {chats.map((chat) => (
            <div key={chat.id} className={clsx("group rounded-3xl border p-3 transition", chat.id === chatId ? "border-white/40 bg-white text-black" : "border-white/10 bg-white/[.035] text-zinc-300 hover:border-white/20 hover:bg-white/[.07]")}> 
              <button onClick={() => selectChat(chat)} className="block w-full text-left">
                <span className="block truncate text-sm font-semibold">{chat.title || "Unbenannter Chat"}</span>
                <span className={clsx("mt-1 block truncate text-xs", chat.id === chatId ? "text-black/55" : "text-zinc-600")}>{formatDate(chat.updatedAt) || "AI-Chat"}</span>
              </button>
              <div className="mt-3 flex gap-1 opacity-0 transition group-hover:opacity-100">
                <button onClick={() => { setRenameChat(chat); setRenameTitle(chat.title); }} className="rounded-xl p-2 hover:bg-black/10" title="Umbenennen"><Edit3 size={14} /></button>
                <button onClick={() => setDeleteChat(chat)} className="rounded-xl p-2 text-red-400 hover:bg-red-500/10" title="Löschen"><Trash2 size={14} /></button>
              </div>
            </div>
          ))}
        </div>
      </aside>

      <main className="flex min-h-0 min-w-0 flex-col overflow-hidden">
        <div className="flex shrink-0 items-center justify-between gap-3 border-b border-white/10 bg-[#070707]/95 px-5 py-4 backdrop-blur-xl">
          <div className="flex min-w-0 items-center gap-3">
            <div className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl border border-white/10 bg-white text-black"><Bot size={18} /></div>
            <div className="min-w-0">
              <h2 className="truncate text-sm font-semibold">{activeChat?.title || "Nexo AI"}</h2>
              <p className="truncate text-xs text-zinc-500">Neue Chats, Verlauf, Umbenennen und Löschen.</p>
            </div>
          </div>
          <button onClick={newChat} className="soft-button inline-flex items-center gap-2">
            <Plus size={16} /> <span className="hidden sm:inline">Neuer Chat</span>
          </button>
        </div>

        <div className="nexo-scrollbar min-h-0 flex-1 overflow-y-auto px-4 py-6 sm:px-8">
          <div className="mx-auto flex w-full max-w-4xl flex-col gap-5">
            {messages.length === 0 && (
              <div className="mx-auto mt-10 w-full max-w-2xl rounded-[2rem] border border-white/10 bg-white/[.035] p-8 text-center shadow-2xl shadow-black/25">
                <Sparkles className="mx-auto mb-4 text-white" />
                <h3 className="text-2xl font-semibold tracking-[-.04em]">Wobei soll Nexo AI helfen?</h3>
                <p className="mx-auto mt-3 max-w-md text-sm leading-6 text-zinc-500">Starte einen neuen Chat, gib ihm später einen Namen und arbeite sauber getrennt an Aufgaben, Code, Texten oder Lernstoff.</p>
                <div className="mt-6 grid gap-2 sm:grid-cols-4">
                  {["Coder: Fixe meinen Fehler", "Schule: Erklär es einfach", "Support: Formuliere Antwort", "Kreativ: Ideen sammeln"].map((prompt) => (
                    <button key={prompt} onClick={() => { setText(prompt); focusInput(); }} className="rounded-2xl border border-white/10 bg-black/30 px-4 py-3 text-sm text-zinc-300 transition hover:bg-white/[.06]">{prompt}</button>
                  ))}
                </div>
              </div>
            )}

            {messages.map((message) => (
              <div key={message.id} className={clsx("flex", message.role === "user" ? "justify-end" : "justify-start")}> 
                <div className={clsx("max-w-[min(760px,85%)] rounded-[1.7rem] px-5 py-4 text-sm leading-7 shadow-xl shadow-black/15", message.role === "user" ? "bg-white text-black" : "border border-white/10 bg-white/[.045] text-zinc-200")}> 
                  {message.content ? <SimpleMarkdown text={message.content} /> : <span className="text-zinc-500">Nexo AI schreibt<TypingDots /></span>}
                  {message.streaming && message.content && <span className="ml-1 inline-block h-4 w-2 animate-pulse rounded-sm bg-zinc-400 align-[-2px]" />}
                  {message.content && <button type="button" onClick={() => copyText(message.content)} className="mt-3 inline-flex items-center gap-1 rounded-full border border-white/10 px-2 py-1 text-[11px] opacity-60 transition hover:opacity-100"><Copy size={12} /> Kopieren</button>}
                </div>
              </div>
            ))}

            {loading && <p className="flex items-center gap-2 text-sm text-zinc-500"><Loader2 size={14} className="animate-spin" /> Nexo AI schreibt<TypingDots /></p>}
            <div ref={bottomRef} />
          </div>
        </div>

        <form onSubmit={submit} className="shrink-0 border-t border-white/10 bg-[#060606]/95 p-4 backdrop-blur-xl">
          <div className="mx-auto w-full max-w-4xl">
            <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
              {error ? <p className="rounded-2xl border border-red-500/20 bg-red-500/10 px-4 py-2 text-sm text-red-200">{error}</p> : <p className="text-xs text-zinc-600">Presets: Coder · Schule · Support · Kreativ</p>}
              <div className="flex gap-2">
                {loading && <button type="button" onClick={stopGenerating} className="soft-button inline-flex items-center gap-2 px-3 py-2 text-xs"><Square size={13} /> Stop</button>}
                <button type="button" onClick={regenerateLast} disabled={loading || !messages.some((message) => message.role === "user")} className="soft-button inline-flex items-center gap-2 px-3 py-2 text-xs disabled:opacity-50"><RefreshCcw size={13} /> Regenerate</button>
              </div>
            </div>
            <div className="flex items-end gap-3 rounded-[1.6rem] border border-white/10 bg-black/40 p-2 shadow-2xl shadow-black/20 focus-within:border-white/25">
              <textarea
                ref={inputRef}
                value={text}
                onChange={(event) => setText(event.target.value)}
                onKeyDown={onComposerKeyDown}
                placeholder="Nachricht an Nexo AI schreiben..."
                className="max-h-40 min-h-[48px] flex-1 resize-none bg-transparent px-3 py-3 text-sm leading-6 outline-none placeholder:text-zinc-600"
                rows={1}
              />
              <button disabled={loading || !text.trim()} className="primary-button mb-0.5 grid h-11 w-11 place-items-center rounded-2xl p-0 disabled:cursor-not-allowed disabled:opacity-50" title="Senden">
                {loading ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
              </button>
            </div>
            <p className="mt-2 px-2 text-[11px] text-zinc-600">Enter sendet, Shift + Enter macht eine neue Zeile.</p>
          </div>
        </form>
      </main>

      <Modal open={Boolean(renameChat)} title="AI-Chat umbenennen" onClose={() => setRenameChat(null)} size="sm">
        <form onSubmit={renameSelected} className="space-y-4">
          <input value={renameTitle} onChange={(event) => setRenameTitle(event.target.value)} className="field" autoFocus maxLength={80} />
          <div className="flex justify-end gap-2"><button type="button" onClick={() => setRenameChat(null)} className="soft-button">Abbrechen</button><button className="primary-button">Speichern</button></div>
        </form>
      </Modal>

      <Modal open={Boolean(deleteChat)} title="AI-Chat löschen?" description="Der Verlauf wird entfernt." onClose={() => setDeleteChat(null)} size="sm">
        <div className="flex justify-end gap-2"><button onClick={() => setDeleteChat(null)} className="soft-button">Abbrechen</button><button onClick={deleteSelected} className="primary-button bg-red-100 text-red-950 hover:bg-red-200">Löschen</button></div>
      </Modal>
    </div>
  );
}
