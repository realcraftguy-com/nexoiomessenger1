"use client";

import { FormEvent, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowRight, ImagePlus, Loader2, Sparkles } from "lucide-react";
import { Avatar } from "@/components/ui/Avatar";
import { CustomSelect } from "@/components/ui/CustomSelect";

const colors = ["#ffffff", "#e5e7eb", "#d4d4d8", "#a1a1aa", "#71717a", "#38bdf8", "#34d399", "#fbbf24"];
const loadingTexts = ["Profil wird geladen", "Avatar wird vorbereitet", "Nexo wird eingerichtet"];
const statusOptions = [
  { value: "ONLINE", label: "Online", description: "Du bist erreichbar" },
  { value: "BUSY", label: "Beschäftigt", description: "Du bist gerade beschäftigt" },
  { value: "DO_NOT_DISTURB", label: "Nicht stören", description: "Benachrichtigungen später" },
  { value: "OFFLINE", label: "Offline", description: "Du wirkst unsichtbar" }
];

export function OnboardingClient() {
  const router = useRouter();
  const [me, setMe] = useState<any>(null);
  const [avatarUrl, setAvatarUrl] = useState("");
  const [avatarColor, setAvatarColor] = useState("#ffffff");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);

  useEffect(() => {
    fetch("/api/auth/me").then(async (res) => {
      if (!res.ok) return router.push("/login");
      const user = (await res.json()).user;
      setMe(user);
      setAvatarUrl(user.avatarUrl || "");
      setAvatarColor(user.avatarColor || "#ffffff");
    });
  }, [router]);

  useEffect(() => {
    if (!saving) return;
    const timer = window.setInterval(() => setLoadingStep((step) => (step + 1) % loadingTexts.length), 850);
    return () => window.clearInterval(timer);
  }, [saving]);

  const previewUser = useMemo(() => ({
    displayName: me?.displayName || "Nexo",
    avatarUrl,
    avatarColor
  }), [me, avatarUrl, avatarColor]);

  async function onAvatarChange(file?: File) {
    if (!file) return;
    if (!file.type.startsWith("image/")) return setError("Bitte wähle ein Bild aus.");
    if (file.size > 1_250_000) return setError("Avatar ist zu groß. Nimm ein kleineres Bild.");

    const reader = new FileReader();
    reader.onload = () => {
      setError("");
      setAvatarUrl(String(reader.result || ""));
    };
    reader.readAsDataURL(file);
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!me || saving) return;
    setSaving(true);
    setError("");

    const form = new FormData(event.currentTarget);
    const payload = {
      displayName: String(form.get("displayName") || me.displayName),
      username: String(form.get("username") || me.username),
      avatarUrl,
      avatarColor,
      status: String(form.get("status") || "ONLINE"),
      onboarded: true
    };

    const res = await fetch("/api/settings/profile", {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload)
    });

    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      setSaving(false);
      return setError(data.error || "Profil konnte nicht gespeichert werden");
    }

    setMe(data.user);
    router.push("/app/@me");
    router.refresh();
  }

  if (!me) {
    return (
      <main className="grid min-h-screen place-items-center bg-surface-950 text-white">
        <div className="panel flex items-center gap-3 px-5 py-4 text-sm text-zinc-300">
          <Loader2 size={16} className="animate-spin" /> Onboarding wird geladen...
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen overflow-hidden bg-surface-950 px-4 py-8 text-white">
      <div className="absolute inset-0 bg-grid bg-[size:48px_48px] opacity-[.08]" />
      <div className="absolute left-1/2 top-0 h-[440px] w-[640px] -translate-x-1/2 rounded-full bg-white/10 blur-[150px]" />

      <form onSubmit={submit} className="panel relative mx-auto grid max-w-5xl gap-6 overflow-hidden p-5 md:grid-cols-[.9fr_1.1fr]">
        {saving && <div className="absolute inset-x-0 top-0 h-1 bg-white/10"><div className="h-full w-1/2 animate-pulse bg-white" /></div>}

        <section className="rounded-[1.35rem] border border-white/10 bg-white/[.035] p-6">
          <div className="mb-8 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[.04] px-3 py-1 text-xs text-zinc-400">
            <Sparkles size={14} /> Profil Setup
          </div>
          <h1 className="text-4xl font-semibold tracking-[-.05em]">Mach Nexo zu deinem Space.</h1>
          <p className="mt-3 text-sm leading-7 text-zinc-500">Wähle Profilbild, Farbe, Namen und Status. Danach landest du direkt im Messenger.</p>

          <div className="mt-10 rounded-3xl border border-white/10 bg-black/25 p-5">
            <p className="mb-4 text-xs uppercase tracking-[.18em] text-zinc-500">Vorschau</p>
            <div className="flex items-center gap-4">
              <Avatar user={previewUser} size="lg" />
              <div>
                <p className="font-semibold">{me.displayName}</p>
                <p className="text-sm text-zinc-500">@{me.username}</p>
              </div>
            </div>
          </div>
        </section>

        <section className="p-2 md:p-4">
          <div className="mb-6 flex flex-col items-center rounded-3xl border border-white/10 bg-black/25 p-6 text-center">
            <Avatar user={previewUser} size="lg" />
            <label className="soft-button mt-4 inline-flex cursor-pointer items-center gap-2">
              <ImagePlus size={16} /> Profilbild hochladen
              <input className="hidden" type="file" accept="image/*" onChange={(event) => onAvatarChange(event.target.files?.[0])} />
            </label>
            <button type="button" onClick={() => setAvatarUrl("")} className="mt-2 text-xs text-zinc-500 hover:text-white">Bild entfernen</button>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <label className="space-y-2"><span className="label">Anzeigename</span><input className="field" name="displayName" defaultValue={me.displayName} required minLength={2} /></label>
            <label className="space-y-2"><span className="label">Username</span><input className="field" name="username" defaultValue={me.username} required minLength={3} /></label>
            <CustomSelect name="status" label="Status" defaultValue={me.status || "ONLINE"} options={statusOptions} />
            <div className="space-y-2"><span className="label">Avatar-Farbe</span><div className="grid grid-cols-8 gap-2">{colors.map((color) => <button key={color} type="button" onClick={() => setAvatarColor(color)} className="h-11 rounded-2xl border transition" style={{ backgroundColor: color, borderColor: avatarColor === color ? "white" : "rgba(255,255,255,.1)" }} />)}</div></div>
          </div>

          {saving && <p className="mt-4 flex items-center gap-2 rounded-2xl border border-white/10 bg-white/[.04] px-4 py-3 text-sm text-zinc-300"><Loader2 size={16} className="animate-spin" /> {loadingTexts[loadingStep]}...</p>}
          {error && <p className="mt-4 rounded-2xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-200">{error}</p>}

          <button disabled={saving} className="primary-button mt-6 inline-flex w-full items-center justify-center gap-2 py-3 disabled:opacity-60">
            {saving ? <Loader2 size={16} className="animate-spin" /> : null}
            Nexo öffnen <ArrowRight size={16} />
          </button>
        </section>
      </form>
    </main>
  );
}
