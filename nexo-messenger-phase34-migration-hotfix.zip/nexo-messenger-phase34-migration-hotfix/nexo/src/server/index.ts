import { createServer } from "node:http";
import next from "next";
import { Server } from "socket.io";
import bcrypt from "bcryptjs";
import prisma from "../lib/prisma";
import { verifySocketCookie } from "../lib/socket-auth";
import { messageSchema, ticketCloseSchema, ticketMessageSchema } from "../lib/validators";
import { canAccessChannel as canViewChannel, requireServerPermission } from "../lib/permissions";
import { attachMessageFilesByIds, attachmentIdsFromPayload, normalizeMessageForClient } from "../lib/message-uploads";
import { rateLimits } from "../lib/rate-limit";
import { createMentionNotifications } from "../lib/notifications";
import { registerLiveServer, emitAdminRefresh, emitChannelEvent, emitChannelTyping } from "../lib/live";
import { areUsersBlocked, dmThreadOtherUserId } from "../lib/social-safety";

const dev = process.env.NODE_ENV !== "production";
const hostname = "0.0.0.0";
const port = Number(process.env.PORT || 3000);

const app = next({ dev, hostname, port });
const handler = app.getRequestHandler();

function publicUser(user: { id: string; username: string; displayName: string; avatarUrl?: string | null; avatarColor: string }) {
  return { id: user.id, username: user.username, displayName: user.displayName, avatarUrl: user.avatarUrl, avatarColor: user.avatarColor };
}

async function canAccessChannel(channelId: string, userId: string, isAdmin = false, required: Parameters<typeof canViewChannel>[3] = "VIEW_CHANNEL") {
  const channel = await canViewChannel(channelId, userId, isAdmin, required);
  return channel?.type === "TEXT" ? channel : null;
}

async function canAccessThread(threadId: string, userId: string) {
  return prisma.directMessageThreadMember.findFirst({ where: { threadId, userId, thread: { status: "ACCEPTED" } } });
}

const dmUserSelect = { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true, status: true } as const;
const dmThreadInclude = {
  members: { include: { user: { select: dmUserSelect } } },
  requestedBy: { select: dmUserSelect },
  messages: { orderBy: { createdAt: "desc" as const }, take: 1 }
};

function dmThreadTargetIds(thread: { members: { userId: string }[] }) {
  return thread.members.map((member: { userId: string }) => member.userId);
}

const ticketUserSelect = { id: true, username: true, displayName: true, avatarColor: true } as const;
const ticketDetailInclude = {
  user: { select: ticketUserSelect },
  messages: {
    orderBy: { createdAt: "asc" as const },
    include: {
      author: { select: ticketUserSelect },
      attachments: { orderBy: { createdAt: "asc" as const } }
    }
  },
  attachments: { orderBy: { createdAt: "asc" as const } }
};

async function loadTicketDetail(ticketId: string) {
  return prisma.ticket.findUnique({ where: { id: ticketId }, include: ticketDetailInclude });
}

function ticketRooms(ticketId: string) {
  return [`ticket:${ticketId}`, "admins"];
}

type StoredAttachment = { id?: string; name?: string; url?: string; mimeType?: string; size?: number };

function toggleReactionMap(raw: string | null | undefined, emoji: string, userId: string) {
  const cleanEmoji = String(emoji || "").trim().slice(0, 16);
  if (!cleanEmoji) return null;
  let reactions: Record<string, string[]> = {};
  try {
    const parsed = raw ? JSON.parse(raw) : {};
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) reactions = parsed;
  } catch {
    reactions = {};
  }
  const current = Array.isArray(reactions[cleanEmoji]) ? reactions[cleanEmoji] : [];
  reactions[cleanEmoji] = current.includes(userId) ? current.filter((id) => id !== userId) : [...current, userId];
  if (reactions[cleanEmoji].length === 0) delete reactions[cleanEmoji];
  return JSON.stringify(reactions);
}

const activeUserSockets = new Map<string, number>();

function addOnlineSocket(userId: string) {
  activeUserSockets.set(userId, (activeUserSockets.get(userId) || 0) + 1);
}

function removeOnlineSocket(userId: string) {
  const next = Math.max((activeUserSockets.get(userId) || 0) - 1, 0);
  if (next === 0) activeUserSockets.delete(userId);
  else activeUserSockets.set(userId, next);
  return next;
}

async function serverMemberIds(serverId: string) {
  const members = await prisma.serverMember.findMany({ where: { serverId }, select: { userId: true } });
  return members.map((member: { userId: string }) => member.userId);
}


app.prepare().then(() => {
  const httpServer = createServer((req, res) => handler(req, res));
  const io = new Server(httpServer, {
    cors: {
      origin: process.env.ALLOWED_ORIGINS?.split(",").map((origin) => origin.trim()).filter(Boolean) || ["http://localhost:3000"],
      credentials: true
    }
  });

  registerLiveServer(io);

  async function emitDmEvent(threadId: string, event: string, payload: unknown, excludeUserId?: string) {
    const members = await prisma.directMessageThreadMember.findMany({ where: { threadId }, select: { userId: true } });
    for (const member of members) {
      if (member.userId !== excludeUserId) io.to(`user:${member.userId}`).emit(event, payload);
    }
  }

  io.use(async (socket, nextMiddleware) => {
    const session = await verifySocketCookie(socket.handshake.headers.cookie);
    if (!session) return nextMiddleware(new Error("unauthorized"));
    const user = await prisma.user.findUnique({ where: { id: session.userId }, select: { id: true, email: true, username: true, displayName: true, avatarUrl: true, avatarColor: true, isBanned: true, banReason: true, sessionVersion: true } });
    if (!user || user.isBanned) return nextMiddleware(new Error("forbidden"));
    if (Number(user.sessionVersion ?? 0) !== Number(session.sessionVersion ?? 0)) return nextMiddleware(new Error("session_revoked"));
    socket.data.user = { ...user, isAdmin: session.isAdmin };
    return nextMiddleware();
  });

  io.on("connection", async (socket) => {
    const user = socket.data.user as { id: string; email: string; username: string; displayName: string; avatarUrl?: string | null; avatarColor: string; isAdmin: boolean; sessionVersion: number };
    socket.join(`user:${user.id}`);
    if (user.isAdmin) socket.join("admins");
    const membershipsAtConnect = await prisma.serverMember.findMany({ where: { userId: user.id }, select: { serverId: true } }).catch(() => []);
    for (const membership of membershipsAtConnect) socket.join(`server:${membership.serverId}`);
    addOnlineSocket(user.id);
    await prisma.user.update({ where: { id: user.id }, data: { status: "ONLINE", lastSeenAt: new Date() } }).catch(() => undefined);

    socket.use(async (_packet, nextPacket) => {
      try {
        const state = await prisma.user.findUnique({ where: { id: user.id }, select: { isBanned: true, banReason: true, sessionVersion: true } });
        if (state?.isBanned) {
          socket.emit("account:banned", { reason: state.banReason || "Kein Grund angegeben" });
          setTimeout(() => socket.disconnect(true), 300);
          return nextPacket(new Error("banned"));
        }
        if (state && Number(state.sessionVersion ?? 0) !== Number(user.sessionVersion ?? 0)) {
          socket.emit("account:session_revoked", { reason: "Dein Passwort wurde geändert. Bitte melde dich neu an." });
          setTimeout(() => socket.disconnect(true), 300);
          return nextPacket(new Error("session_revoked"));
        }
      } catch {
        return nextPacket(new Error("forbidden"));
      }
      return nextPacket();
    });

    socket.on("admin:user:ban", async (payload: { userId: string; reason?: string }, ack?: (result: unknown) => void) => {
      try {
        if (!user.isAdmin) return ack?.({ error: "Nur Admin" });
        const targetId = payload?.userId;
        const reason = String(payload?.reason || "").trim().slice(0, 300) || "Kein Grund angegeben";
        if (!targetId) return ack?.({ error: "User nicht gefunden" });
        if (targetId === user.id) return ack?.({ error: "Du kannst dich nicht selbst sperren." });

        const target = await prisma.user.update({
          where: { id: targetId },
          data: { isBanned: true, banReason: reason, bannedAt: new Date(), status: "OFFLINE" },
          select: { id: true, email: true, username: true, displayName: true, isBanned: true, banReason: true, bannedAt: true, status: true, createdAt: true }
        });

        await prisma.auditLog.create({
          data: { action: "USER_BANNED", actorId: user.id, targetId: target.id, meta: JSON.stringify({ reason }) }
        });

        io.to(`user:${target.id}`).emit("account:banned", { reason });
        io.to("admins").emit("admin:user:updated", { user: target });
        emitAdminRefresh("user_banned", { userId: target.id });
        setTimeout(() => io.in(`user:${target.id}`).disconnectSockets(true), 800);
        ack?.({ ok: true, user: target });
      } catch {
        ack?.({ error: "User konnte nicht gesperrt werden." });
      }
    });

    socket.on("admin:user:unban", async (payload: { userId: string }, ack?: (result: unknown) => void) => {
      try {
        if (!user.isAdmin) return ack?.({ error: "Nur Admin" });
        const targetId = payload?.userId;
        if (!targetId) return ack?.({ error: "User nicht gefunden" });

        const target = await prisma.user.update({
          where: { id: targetId },
          data: { isBanned: false, banReason: null, bannedAt: null },
          select: { id: true, email: true, username: true, displayName: true, isBanned: true, banReason: true, bannedAt: true, status: true, createdAt: true }
        });

        await prisma.auditLog.create({
          data: { action: "USER_UNBANNED", actorId: user.id, targetId: target.id, meta: JSON.stringify({}) }
        });

        io.to("admins").emit("admin:user:updated", { user: target });
        emitAdminRefresh("user_updated", { userId: target.id });
        ack?.({ ok: true, user: target });
      } catch {
        ack?.({ error: "User konnte nicht entsperrt werden." });
      }
    });

    socket.on("admin:user:password-reset", async (payload: { userId: string; newPassword: string }, ack?: (result: unknown) => void) => {
      try {
        if (!user.isAdmin) return ack?.({ error: "Nur Admin" });
        const targetId = payload?.userId;
        const newPassword = String(payload?.newPassword || "");
        if (!targetId) return ack?.({ error: "User nicht gefunden" });
        if (newPassword.length < 8 || newPassword.length > 120) return ack?.({ error: "Das neue Passwort braucht mindestens 8 Zeichen." });

        const passwordHash = await bcrypt.hash(newPassword, 12);
        const target = await prisma.user.update({
          where: { id: targetId },
          data: { passwordHash, sessionVersion: { increment: 1 }, status: "OFFLINE" },
          select: { id: true, email: true, username: true, displayName: true, isBanned: true, banReason: true, bannedAt: true, status: true, createdAt: true, sessionVersion: true }
        });

        await prisma.auditLog.create({
          data: { action: "PASSWORD_RESET", actorId: user.id, targetId: target.id, meta: JSON.stringify({ revokedSessions: true }) }
        });

        io.to(`user:${target.id}`).emit("account:session_revoked", { reason: "Dein Passwort wurde von einem Admin zurückgesetzt. Bitte melde dich neu an." });
        io.to("admins").emit("admin:user:updated", { user: target });
        emitAdminRefresh("password_reset", { userId: target.id });
        setTimeout(() => io.in(`user:${target.id}`).disconnectSockets(true), 800);
        ack?.({ ok: true, user: target });
      } catch {
        ack?.({ error: "Passwort konnte nicht zurückgesetzt werden." });
      }
    });


    socket.on("server:delete", async (payload: { serverId: string }, ack?: (result: unknown) => void) => {
      try {
        const serverId = payload?.serverId;
        if (!serverId) return ack?.({ error: "Server nicht gefunden" });
        const server = await prisma.server.findUnique({ where: { id: serverId }, select: { id: true, name: true, ownerId: true } });
        if (!server) return ack?.({ error: "Server nicht gefunden" });
        const member = await prisma.serverMember.findUnique({ where: { serverId_userId: { serverId, userId: user.id } } });
        if (server.ownerId !== user.id && !member?.isOwner && !user.isAdmin) return ack?.({ error: "Nur Owner darf löschen" });
        const targets = await serverMemberIds(server.id);
        await prisma.server.delete({ where: { id: server.id } });
        await prisma.auditLog.create({ data: { action: "SERVER_DELETED", actorId: user.id, targetId: server.id, meta: JSON.stringify({ name: server.name }) } }).catch(() => undefined);
        for (const id of targets) io.to(`user:${id}`).emit("server:deleted", { serverId: server.id, name: server.name });
        io.to("admins").emit("admin:server:deleted", { serverId: server.id, name: server.name });
        emitAdminRefresh("server_deleted", { serverId: server.id });
        ack?.({ ok: true });
      } catch {
        ack?.({ error: "Server konnte nicht gelöscht werden." });
      }
    });

    socket.on("channel:join", async ({ channelId }: { channelId: string }) => {
      if (await canAccessChannel(channelId, user.id, user.isAdmin)) socket.join(`channel:${channelId}`);
    });

    socket.on("channel:typing", async ({ channelId, typing }: { channelId: string; typing: boolean }) => {
      if (!(await canAccessChannel(channelId, user.id, user.isAdmin, "VIEW_CHANNEL"))) return;
      if (typing && !(await canAccessChannel(channelId, user.id, user.isAdmin, "SEND_MESSAGES"))) return;
      await emitChannelTyping(channelId, { channelId, user: publicUser(user), typing }, user.id);
    });

    socket.on("channel:message", async (payload: { channelId: string; content?: string; replyToId?: string | null; attachments?: StoredAttachment[]; attachmentIds?: string[]; clientMessageId?: string }, ack?: (result: unknown) => void) => {
      try {
        const channel = await canAccessChannel(payload.channelId, user.id, user.isAdmin, "SEND_MESSAGES");
        if (!channel) return ack?.({ error: "Keine Schreibberechtigung" });
        socket.join(`channel:${payload.channelId}`);
        const canBypassSlowmode = Boolean(await canAccessChannel(payload.channelId, user.id, user.isAdmin, "MANAGE_MESSAGES"));
        if (!canBypassSlowmode && channel.slowmodeSeconds > 0) {
          const recent = await prisma.message.findFirst({ where: { channelId: payload.channelId, authorId: user.id, createdAt: { gt: new Date(Date.now() - channel.slowmodeSeconds * 1000) } }, select: { id: true } });
          if (recent) return ack?.({ error: `Slowmode aktiv. Warte ${channel.slowmodeSeconds} Sekunden.` });
        }
        const limited = await rateLimits.message(user.id, payload.channelId);
        if (!limited.ok) return ack?.({ error: "Du sendest gerade zu schnell." });
        const body = messageSchema.parse({ content: payload.content || "", replyToId: payload.replyToId, attachments: payload.attachments, attachmentIds: payload.attachmentIds, clientMessageId: payload.clientMessageId });
        const attachmentIds = attachmentIdsFromPayload(body);
        if (attachmentIds.length && !(await canAccessChannel(payload.channelId, user.id, user.isAdmin, "UPLOAD_FILES"))) return ack?.({ error: "Keine Upload-Berechtigung" });
        if (body.clientMessageId) {
          const existing = await prisma.message.findFirst({ where: { channelId: payload.channelId, authorId: user.id, clientMessageId: body.clientMessageId }, include: { author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } }, fileAttachments: { orderBy: { createdAt: "asc" } }, replyTo: { select: { id: true, content: true, deletedAt: true, author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } } } } } });
          if (existing) return ack?.({ ok: true, message: normalizeMessageForClient(existing) });
        }
        const message = await prisma.message.create({
          data: {
            channelId: payload.channelId,
            authorId: user.id,
            content: body.content.trim(),
            replyToId: body.replyToId || null,
            clientMessageId: body.clientMessageId || null,
            attachments: "[]"
          },
          include: { author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } }, fileAttachments: true }
        });
        const files = await attachMessageFilesByIds({ uploaderId: user.id, attachmentIds, messageId: message.id });
        await createMentionNotifications({ content: body.content, messageId: message.id, excludeUserId: user.id }).catch(() => undefined);
        const fullMessage = await prisma.message.findUnique({ where: { id: message.id }, include: { author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } }, fileAttachments: { orderBy: { createdAt: "asc" } }, replyTo: { select: { id: true, content: true, deletedAt: true, author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } } } } } });
        if (files.length) {
          await prisma.auditLog.create({ data: { action: "MESSAGE_ATTACHMENT_UPLOADED", actorId: user.id, serverId: channel.serverId, targetId: message.id, meta: JSON.stringify({ count: files.length }) } }).catch(() => undefined);
          emitAdminRefresh("message_attachment_uploaded", { serverId: channel.serverId });
        }
        await emitChannelEvent(payload.channelId, "channel:message", normalizeMessageForClient(fullMessage || message));
        ack?.({ ok: true, message: normalizeMessageForClient(fullMessage || message) });
      } catch (error) {
        ack?.({ error: "Nachricht konnte nicht gesendet werden" });
      }
    });

    socket.on("channel:message:delete", async (payload: { channelId: string; messageId: string }, ack?: (result: unknown) => void) => {
      try {
        const channel = await canAccessChannel(payload.channelId, user.id, user.isAdmin);
        if (!channel) return ack?.({ error: "Kein Zugriff" });
        const message = await prisma.message.findUnique({ where: { id: payload.messageId }, include: { channel: true } });
        if (!message || message.channelId !== payload.channelId) return ack?.({ error: "Nachricht nicht gefunden" });
        if (message.authorId !== user.id && !(await canAccessChannel(payload.channelId, user.id, user.isAdmin, "MANAGE_MESSAGES"))) return ack?.({ error: "Keine Berechtigung" });
        await prisma.message.update({ where: { id: message.id }, data: { deletedAt: new Date(), content: "", attachments: "[]" } });
        await prisma.auditLog.create({ data: { action: "MESSAGE_DELETED", actorId: user.id, serverId: channel.serverId, targetId: message.id } }).catch(() => undefined);
        await emitChannelEvent(payload.channelId, "channel:message:deleted", { messageId: message.id, channelId: payload.channelId });
        emitAdminRefresh("message_deleted", { serverId: channel.serverId, messageId: message.id });
        ack?.({ ok: true });
      } catch {
        ack?.({ error: "Nachricht konnte nicht gelöscht werden." });
      }
    });


    socket.on("channel:message:react", async (payload: { channelId: string; messageId: string; emoji: string }, ack?: (result: unknown) => void) => {
      try {
        const channel = await canAccessChannel(payload.channelId, user.id, user.isAdmin);
        if (!channel) return ack?.({ error: "Kein Zugriff" });
        const message = await prisma.message.findUnique({ where: { id: payload.messageId }, select: { id: true, channelId: true, reactions: true } });
        if (!message || message.channelId !== payload.channelId) return ack?.({ error: "Nachricht nicht gefunden" });
        const reactions = toggleReactionMap(message.reactions, payload.emoji, user.id);
        if (!reactions) return ack?.({ error: "Emoji ungültig" });
        const updated = await prisma.message.update({ where: { id: message.id }, data: { reactions }, include: { author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } } } });
        await prisma.auditLog.create({ data: { action: "MESSAGE_REACTED", actorId: user.id, serverId: channel.serverId, targetId: message.id, meta: JSON.stringify({ emoji: payload.emoji }) } }).catch(() => undefined);
        await emitChannelEvent(payload.channelId, "channel:message:reaction", { channelId: payload.channelId, message: updated });
        ack?.({ ok: true, message: updated });
      } catch {
        ack?.({ error: "Reaktion konnte nicht gespeichert werden." });
      }
    });


    socket.on("dm:request:create", async (payload: { userId: string }, ack?: (result: unknown) => void) => {
      try {
        const targetId = payload?.userId;
        if (!targetId || targetId === user.id) return ack?.({ error: "Du kannst dir nicht selbst schreiben." });

        const target = await prisma.user.findUnique({ where: { id: targetId }, select: { id: true, isBanned: true, allowDmRequests: true } });
        if (!target || target.isBanned) return ack?.({ error: "User nicht gefunden" });
        if (await areUsersBlocked(user.id, targetId)) return ack?.({ error: "DM ist blockiert." });
        if (target.allowDmRequests === false) return ack?.({ error: "Dieser User nimmt aktuell keine Nachrichtenanfragen an." });

        const existing = await prisma.directMessageThread.findFirst({
          where: {
            AND: [
              { members: { some: { userId: user.id } } },
              { members: { some: { userId: targetId } } }
            ]
          },
          include: dmThreadInclude
        });

        if (existing && existing.members.length === 2) {
          if (existing.status === "ACCEPTED") {
            socket.join(`dm:${existing.id}`);
            return ack?.({ ok: true, thread: existing, state: "accepted" });
          }
          const outgoing = existing.requestedById === user.id;
          return ack?.({ ok: true, thread: existing, state: outgoing ? "pending_outgoing" : "pending_incoming" });
        }

        const thread = await prisma.directMessageThread.create({
          data: {
            status: "PENDING",
            requestedById: user.id,
            members: { create: [{ userId: user.id }, { userId: targetId }] }
          },
          include: dmThreadInclude
        });

        io.to(`user:${targetId}`).emit("dm:request:created", { thread, direction: "incoming" });
        io.to(`user:${user.id}`).emit("dm:request:created", { thread, direction: "outgoing" });
        ack?.({ ok: true, thread, state: "pending_outgoing" });
      } catch {
        ack?.({ error: "Anfrage konnte nicht gesendet werden." });
      }
    });

    socket.on("dm:request:respond", async (payload: { threadId: string; action: "accept" | "decline" | "cancel" }, ack?: (result: unknown) => void) => {
      try {
        const threadId = payload?.threadId;
        const action = payload?.action;
        if (!threadId || !["accept", "decline", "cancel"].includes(action)) return ack?.({ error: "Aktion nicht möglich." });

        const thread = await prisma.directMessageThread.findUnique({
          where: { id: threadId },
          include: { members: true }
        });

        if (!thread || !thread.members.some((member: { userId: string }) => member.userId === user.id)) return ack?.({ error: "Anfrage nicht gefunden" });
        if (thread.status !== "PENDING") return ack?.({ error: "Diese Anfrage ist nicht mehr offen." });

        const isRequester = thread.requestedById === user.id;
        const targetIds = dmThreadTargetIds(thread);

        if (action === "accept") {
          if (isRequester) return ack?.({ error: "Die andere Person muss diese Anfrage annehmen." });
          const updated = await prisma.directMessageThread.update({
            where: { id: thread.id },
            data: { status: "ACCEPTED", updatedAt: new Date() },
            include: dmThreadInclude
          });

          for (const id of targetIds) {
            io.to(`user:${id}`).emit("dm:request:accepted", { thread: updated });
          }
          socket.join(`dm:${updated.id}`);
          ack?.({ ok: true, thread: updated });
          return;
        }

        if (action === "cancel" && !isRequester) return ack?.({ error: "Nur der Absender kann diese Anfrage zurückziehen." });
        if (action === "decline" && isRequester) return ack?.({ error: "Du kannst deine eigene Anfrage nur zurückziehen." });

        await prisma.directMessageThread.delete({ where: { id: thread.id } });
        for (const id of targetIds) {
          io.to(`user:${id}`).emit("dm:request:removed", { threadId: thread.id, action });
        }
        ack?.({ ok: true });
      } catch {
        ack?.({ error: "Aktion konnte nicht ausgeführt werden." });
      }
    });

    socket.on("dm:join", async ({ threadId }: { threadId: string }) => {
      if (await canAccessThread(threadId, user.id)) socket.join(`dm:${threadId}`);
    });

    socket.on("dm:typing", async ({ threadId, typing }: { threadId: string; typing: boolean }) => {
      if (!(await canAccessThread(threadId, user.id))) return;
      await emitDmEvent(threadId, "dm:typing", { threadId, user: publicUser(user), typing }, user.id);
    });

    socket.on("dm:message", async (payload: { threadId: string; content?: string; replyToId?: string | null; attachments?: StoredAttachment[]; attachmentIds?: string[]; clientMessageId?: string }, ack?: (result: unknown) => void) => {
      try {
        if (!(await canAccessThread(payload.threadId, user.id))) return ack?.({ error: "Die andere Person muss den Chat erst annehmen." });
        const otherUserId = await dmThreadOtherUserId(payload.threadId, user.id);
        if (otherUserId && await areUsersBlocked(user.id, otherUserId)) return ack?.({ error: "DM ist blockiert." });
        socket.join(`dm:${payload.threadId}`);
        const limited = await rateLimits.message(user.id, payload.threadId);
        if (!limited.ok) return ack?.({ error: "Du sendest gerade zu schnell." });
        const body = messageSchema.parse({ content: payload.content || "", replyToId: payload.replyToId, attachments: payload.attachments, attachmentIds: payload.attachmentIds, clientMessageId: payload.clientMessageId });
        const attachmentIds = attachmentIdsFromPayload(body);
        if (body.clientMessageId) {
          const existing = await prisma.directMessage.findFirst({ where: { threadId: payload.threadId, authorId: user.id, clientMessageId: body.clientMessageId }, include: { author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } }, fileAttachments: { orderBy: { createdAt: "asc" } }, replyTo: { select: { id: true, content: true, deletedAt: true, author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } } } } } });
          if (existing) return ack?.({ ok: true, message: normalizeMessageForClient(existing) });
        }
        const message = await prisma.directMessage.create({
          data: {
            threadId: payload.threadId,
            authorId: user.id,
            content: body.content.trim(),
            replyToId: body.replyToId || null,
            clientMessageId: body.clientMessageId || null,
            attachments: "[]"
          },
          include: { author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } }, fileAttachments: true }
        });
        await attachMessageFilesByIds({ uploaderId: user.id, attachmentIds, dmMessageId: message.id });
        await createMentionNotifications({ content: body.content, dmMessageId: message.id, excludeUserId: user.id }).catch(() => undefined);
        const fullMessage = await prisma.directMessage.findUnique({ where: { id: message.id }, include: { author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } }, fileAttachments: { orderBy: { createdAt: "asc" } }, replyTo: { select: { id: true, content: true, deletedAt: true, author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } } } } } });
        await prisma.directMessageThread.update({ where: { id: payload.threadId }, data: { updatedAt: new Date() } });
        await prisma.directMessageThreadMember.updateMany({ where: { threadId: payload.threadId, userId: { not: user.id } }, data: { unread: { increment: 1 } } });
        await emitDmEvent(payload.threadId, "dm:message", normalizeMessageForClient(fullMessage || message));
        ack?.({ ok: true, message: normalizeMessageForClient(fullMessage || message) });
      } catch {
        ack?.({ error: "DM konnte nicht gesendet werden" });
      }
    });

    socket.on("dm:message:delete", async (payload: { threadId: string; messageId: string }, ack?: (result: unknown) => void) => {
      try {
        if (!(await canAccessThread(payload.threadId, user.id))) return ack?.({ error: "Kein Zugriff" });
        const message = await prisma.directMessage.findUnique({ where: { id: payload.messageId }, select: { id: true, threadId: true, authorId: true } });
        if (!message || message.threadId !== payload.threadId) return ack?.({ error: "Nachricht nicht gefunden" });
        if (message.authorId !== user.id && !user.isAdmin) return ack?.({ error: "Keine Berechtigung" });
        await prisma.directMessage.update({ where: { id: message.id }, data: { deletedAt: new Date(), content: "", attachments: "[]" } });
        await emitDmEvent(payload.threadId, "dm:message:deleted", { messageId: message.id, threadId: payload.threadId });
        ack?.({ ok: true });
      } catch {
        ack?.({ error: "Nachricht konnte nicht gelöscht werden." });
      }
    });


    socket.on("dm:message:react", async (payload: { threadId: string; messageId: string; emoji: string }, ack?: (result: unknown) => void) => {
      try {
        if (!(await canAccessThread(payload.threadId, user.id))) return ack?.({ error: "Kein Zugriff" });
        const message = await prisma.directMessage.findUnique({ where: { id: payload.messageId }, select: { id: true, threadId: true, reactions: true } });
        if (!message || message.threadId !== payload.threadId) return ack?.({ error: "Nachricht nicht gefunden" });
        const reactions = toggleReactionMap(message.reactions, payload.emoji, user.id);
        if (!reactions) return ack?.({ error: "Emoji ungültig" });
        const updated = await prisma.directMessage.update({ where: { id: message.id }, data: { reactions }, include: { author: { select: { id: true, username: true, displayName: true, avatarUrl: true, avatarColor: true } } } });
        await emitDmEvent(payload.threadId, "dm:message:reaction", { threadId: payload.threadId, message: updated });
        ack?.({ ok: true, message: updated });
      } catch {
        ack?.({ error: "Reaktion konnte nicht gespeichert werden." });
      }
    });


    socket.on("ticket:join", async ({ ticketId }: { ticketId: string }) => {
      const ticket = await prisma.ticket.findUnique({ where: { id: ticketId } });
      if (ticket && (ticket.userId === user.id || user.isAdmin)) socket.join(`ticket:${ticketId}`);
    });

    socket.on("ticket:sync", async (payload: { ticketId: string }, ack?: (result: unknown) => void) => {
      try {
        const ticketId = payload?.ticketId;
        if (!ticketId) return ack?.({ error: "Ticket nicht gefunden." });
        const ticket = await prisma.ticket.findUnique({ where: { id: ticketId }, select: { id: true, userId: true } });
        if (!ticket || (ticket.userId !== user.id && !user.isAdmin)) return ack?.({ error: "Kein Zugriff" });

        socket.join(`ticket:${ticket.id}`);
        const fullTicket = await loadTicketDetail(ticket.id);
        if (!fullTicket) return ack?.({ error: "Ticket nicht gefunden." });

        io.to(ticketRooms(ticket.id)).emit("ticket:updated", { ticketId: ticket.id, ticket: fullTicket });
        ack?.({ ok: true, ticket: fullTicket });
      } catch {
        ack?.({ error: "Ticket konnte nicht aktualisiert werden." });
      }
    });

    socket.on("ticket:message", async (payload: { ticketId: string; content: string }, ack?: (result: unknown) => void) => {
      try {
        const ticket = await prisma.ticket.findUnique({ where: { id: payload.ticketId } });
        if (!ticket || (ticket.userId !== user.id && !user.isAdmin) || ticket.status === "CLOSED") return ack?.({ error: "Kein Zugriff" });
        const body = ticketMessageSchema.parse({ content: payload.content });
        const message = await prisma.ticketMessage.create({
          data: { ticketId: ticket.id, authorId: user.id, content: body.content, isStaff: user.isAdmin },
          include: { author: { select: { id: true, username: true, displayName: true, avatarColor: true } }, attachments: { orderBy: { createdAt: "asc" } } }
        });
        await prisma.ticket.update({ where: { id: ticket.id }, data: { status: user.isAdmin ? "ANSWERED" : "OPEN", updatedAt: new Date() } });
        io.to(ticketRooms(ticket.id)).emit("ticket:message", { ticketId: ticket.id, message });
        const fullTicket = await loadTicketDetail(ticket.id);
        if (fullTicket) io.to(ticketRooms(ticket.id)).emit("ticket:updated", { ticketId: ticket.id, ticket: fullTicket });
        emitAdminRefresh("ticket_message", { ticketId: ticket.id });
        ack?.({ ok: true, message, ticket: fullTicket });
      } catch {
        ack?.({ error: "Ticket-Antwort konnte nicht gesendet werden" });
      }
    });

    socket.on("ticket:close", async (payload: { ticketId: string; reason: string }, ack?: (result: unknown) => void) => {
      try {
        const ticket = await prisma.ticket.findUnique({ where: { id: payload.ticketId } });
        if (!ticket || (ticket.userId !== user.id && !user.isAdmin)) return ack?.({ error: "Kein Zugriff" });
        if (ticket.status === "CLOSED") return ack?.({ error: "Ticket ist bereits geschlossen." });
        const body = ticketCloseSchema.parse({ reason: payload.reason });
        const updated = await prisma.ticket.update({
          where: { id: ticket.id },
          data: { status: "CLOSED", closedAt: new Date(), closedById: user.id, closeReason: body.reason },
          include: {
            user: { select: { id: true, username: true, displayName: true, email: true, avatarColor: true } },
            messages: {
              orderBy: { createdAt: "asc" },
              include: { author: { select: { id: true, username: true, displayName: true, avatarColor: true } }, attachments: { orderBy: { createdAt: "asc" } } }
            },
            attachments: { orderBy: { createdAt: "asc" } }
          }
        });
        await prisma.auditLog.create({ data: { action: "TICKET_CLOSED", actorId: user.id, targetId: ticket.id, meta: JSON.stringify({ reason: body.reason, title: ticket.title }) } }).catch(() => undefined);
        io.to(ticketRooms(ticket.id)).emit("ticket:closed", { ticketId: ticket.id, ticket: updated, reason: body.reason });
        io.to(ticketRooms(ticket.id)).emit("ticket:updated", { ticketId: ticket.id, ticket: updated });
        emitAdminRefresh("ticket_closed", { ticketId: ticket.id });
        ack?.({ ok: true, ticket: updated });
      } catch {
        ack?.({ error: "Ticket konnte nicht geschlossen werden." });
      }
    });

    socket.on("disconnect", async () => {
      const remaining = removeOnlineSocket(user.id);
      if (remaining === 0) {
        setTimeout(async () => {
          if (!activeUserSockets.has(user.id)) {
            await prisma.user.update({ where: { id: user.id }, data: { status: "OFFLINE", lastSeenAt: new Date() } }).catch(() => undefined);
          }
        }, 2500);
      }
    });
  });

  httpServer.listen(port, hostname, () => {
    console.log(`Nexo läuft auf http://localhost:${port}`);
  });
});
