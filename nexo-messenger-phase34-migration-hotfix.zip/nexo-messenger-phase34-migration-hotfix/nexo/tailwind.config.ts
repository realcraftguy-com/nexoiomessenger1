import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        surface: {
          950: "#050506",
          900: "#0a0a0c",
          850: "#101013",
          800: "#151519",
          700: "#202027",
          600: "#2c2c35"
        }
      },
      boxShadow: {
        soft: "0 24px 80px rgba(0,0,0,.42)",
        line: "inset 0 0 0 1px rgba(255,255,255,.08)"
      },
      backgroundImage: {
        grid: "linear-gradient(to right, rgba(255,255,255,.06) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,.06) 1px, transparent 1px)"
      },
      animation: {
        float: "float 7s ease-in-out infinite",
        fadeUp: "fadeUp .45s ease-out both"
      },
      keyframes: {
        float: {
          "0%, 100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-12px)" }
        },
        fadeUp: {
          "0%": { opacity: "0", transform: "translateY(12px)" },
          "100%": { opacity: "1", transform: "translateY(0)" }
        }
      }
    }
  },
  plugins: []
};

export default config;
