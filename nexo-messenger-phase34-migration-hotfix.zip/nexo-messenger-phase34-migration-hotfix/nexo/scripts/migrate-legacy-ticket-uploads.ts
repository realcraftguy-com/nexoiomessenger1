import { mkdir, copyFile, access } from "node:fs/promises";
import path from "node:path";
import prisma from "../src/lib/prisma";
import { storagePath } from "../src/lib/upload-security";

async function exists(file: string) {
  try { await access(file); return true; } catch { return false; }
}

async function main() {
  const legacyRoot = path.resolve(process.cwd(), "public", "uploads", "tickets");
  const legacy = await prisma.ticketAttachment.findMany({ where: { storagePath: "" } });
  let migrated = 0;
  for (const attachment of legacy) {
    const fileName = attachment.url.split("/").pop() || attachment.name || attachment.id;
    const legacyPath = path.join(legacyRoot, attachment.ticketId, fileName);
    if (!(await exists(legacyPath))) continue;
    const relative = path.posix.join("tickets", attachment.ticketId, `${attachment.id}-${fileName.replace(/[^a-zA-Z0-9_.-]/g, "_")}`);
    const target = storagePath(relative);
    await mkdir(path.dirname(target), { recursive: true });
    await copyFile(legacyPath, target);
    await prisma.ticketAttachment.update({ where: { id: attachment.id }, data: { storagePath: relative, originalName: attachment.originalName || attachment.name || fileName } });
    migrated++;
  }
  console.log(`Legacy Ticket Uploads migriert: ${migrated}`);
}

main().finally(() => prisma.$disconnect());
