import { cleanupOrphanMessageUploads } from "../src/lib/cleanup/orphan-uploads";
import prisma from "../src/lib/prisma";

const hours = Number(process.argv[2] || 1);
const maxAgeMs = Math.max(1, hours) * 60 * 60 * 1000;
const result = await cleanupOrphanMessageUploads(maxAgeMs);
console.log(`[Nexo cleanup] Orphan uploads gelöscht: DB=${result.deletedRows}, Dateien=${result.deletedFiles}`);
await prisma.$disconnect();
