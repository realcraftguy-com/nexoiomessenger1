# Nexo Messenger — Phase 34


## Phase 34 Migration-Hotfix

Phase 34 enthält jetzt eine initiale Prisma-Baseline-Migration (`20260627000000_initial_schema`). Dadurch kann eine komplett frische Docker/PostgreSQL-Datenbank zuerst das Grundschema erstellen und danach die Phase-29-bis-Phase-33-Migrationen anwenden.

Wenn du vorher bereits den Fehler `P3009` bei `20260627150000_phase29_security` hattest, lösche die kaputte Dev-Datenbank einmal neu:

```bash
docker compose down -v
docker compose up --build
```

Nur für echte Produktivdatenbanken gilt: Volume nicht löschen, sondern die fehlgeschlagene Migration zuerst manuell prüfen und mit `prisma migrate resolve` sauber auflösen.


Phase 34 macht Nexo sichtbar runder: Der Chat fühlt sich mehr wie eine fertige Messenger-App an, Reactions zeigen jetzt Userdetails, Codeblöcke lassen sich kopieren, Nachrichten können direkt gemeldet werden und die Schnellnavigation über `Ctrl + K` ist vorhanden. Danach wurden Invite-Privacy, User-Suche, Report-Actions und weitere TypeScript-/Security-Stellen gehärtet.

## Start

```bash
npm install
npx prisma generate
npm run typecheck
npm run build
npm run dev
```

Docker:

```bash
docker compose up --build
```

## Wichtige Checks

```bash
npm run typecheck
npm run build
```

Hinweis: In Offline-/Sandbox-Umgebungen kann `npx prisma generate` am Prisma-Engine-Download scheitern. In einer normalen Online-Dev-Umgebung muss zuerst Prisma generiert werden, danach laufen Typecheck und Build.

## Phase 34 Changelog

### UI/UX und Chat Polish

- Message-Hover-Toolbar ruhiger und klarer gestaltet.
- Reply, Reaction, Pin, Edit, Delete und Report sind optisch konsistenter.
- Leerer Channel hat einen hochwertigeren Empty State.
- Fehler beim Senden werden als Inline-Fehler mit Retry-Fokus angezeigt.
- Pin-Button im Header ist mobil kompakter.
- Pin-Panel wurde optisch verbessert und nutzt weiterhin den zuverlässigen Jump zur Nachricht.
- Search-Ergebnisse markieren den Suchbegriff.
- Search-Jump lädt ältere Nachrichten rund um das Ergebnis weiter über `around=<messageId>`.
- Date Divider, Gruppierung, Attachments und lange Nachrichten bleiben sauber dunkel/modern.

### Reactions Popover

- Reaction-Badges zeigen beim Hover/Fokus ein Popover.
- Popover lädt sichtbare User über `/api/messages/[messageId]/reactions`.
- Anzeige enthält Avatar, Display Name und Username.
- Eigene Reaction bleibt optisch markiert.
- Erneutes Klicken toggelt die eigene Reaction wie bisher.

### Codeblock Copy Button

- Markdown-Codeblöcke mit ``` werden als sichere Codeblöcke gerendert.
- Copy-Button sitzt oben rechts im Codeblock.
- Nach dem Kopieren erscheint direkt im Button der Status `Kopiert`.
- Es wird kein HTML unsicher gerendert.

### Message Reports

- Nachrichten haben direkt in der Toolbar einen Melden-Button.
- Report-Dialog mit Grundauswahl und optionaler Beschreibung.
- Reports landen im bestehenden Admin-Panel.
- Eigene Nachrichten werden nicht unnötig mit Report-Button angezeigt.

### Command Palette

- `Ctrl + K` öffnet eine dunkle Schnellnavigation.
- Navigation zu Freunden, DMs, Settings, Support, AI, Admin und sichtbaren Servern/Channels.
- Tastatursteuerung: Pfeil hoch/runter, Enter, Escape.
- Mobile und Desktop nutzbar als leichtes modernes Modal.

### Friends und DMs

- Friends UI sortiert Freunde nach Online/Offline.
- Filter „Nur online“ ergänzt.
- Freund entfernen nutzt Confirm Dialog.
- DM-Liste wurde typisiert und Badges/letzte Nachrichten bleiben stabiler.
- Öffnen von DMs und Live-Refresh bleiben erhalten.

### Admin Panel und Reports

- Reports behalten echte Notes.
- Admin kann aus Report-Details heraus gemeldete Nachricht moderieren/löschen.
- Zieluser kann aus Report-Details heraus gesperrt werden.
- Statusänderung, Nachrichtmoderation und Notes schreiben Audit-Log.
- Health-Version zeigt `phase-34`.

### Invite Security und Privacy

- `GET /api/servers/[serverId]/invites` gibt nicht mehr allen normalen Server-Membern alle Invite-Codes.
- Zugriff auf die komplette Invite-Liste nur mit `CREATE_INVITES`, `MANAGE_SERVER`, Owner/Admin.
- Normale Member sehen höchstens eigene Invites.
- Invite Preview leakt private Zielchannel nicht mehr an unberechtigte User.
- Nach Invite-Join wird nur zu einem Channel navigiert, den der User wirklich sehen darf.

### User Search Privacy

- Öffentliche User-Suche sucht nur noch über `username` und `displayName`.
- E-Mail-Suche bleibt Admin-Overview vorbehalten.
- Normale User können nicht mehr über die Suche prüfen, ob eine E-Mail existiert.

### TypeScript Cleanup

- Weitere `any`-Stellen in DirectMessages reduziert.
- Reaction-API, Command Palette und Search/Report-Erweiterungen sauber typisiert.
- Keine neuen `ts-ignore`-Hacks.

### Avatar Storage

- Sicherer Avatar-Upload aus Phase 33 bleibt aktiv.
- Bestehender Avatar-Orphan-Cleanup bleibt vorbereitet über Upload-/Cleanup-Logik.
- Neue Avatare laufen weiter über lokale sichere `/api/files/avatars/...`-Pfade.

### PWA/Mobile

- Manifest bleibt auf App-Name `Nexo`, dunkle Theme Color und installierbare Icons gesetzt.
- Chat-, Pin-, Search- und Command-UI sind auf kleinen Screens kompakter.
- Modals und Touch Targets wurden weiter ruhiger gestaltet.

## Test-Checkliste Phase 34

1. `npm run typecheck` ausführen.
2. `npm run build` ausführen.
3. Chat öffnen und Hover-Toolbar prüfen.
4. Nachricht mit Codeblock senden und Copy Button testen.
5. Reaction hinzufügen, Hover/Fokus auf Reaction öffnen und Userliste prüfen.
6. Eigene Reaction erneut klicken und Entfernung prüfen.
7. Fremde Nachricht melden und Report im Admin Panel sehen.
8. Pin Panel öffnen, Pin anklicken und Jump zur Nachricht testen.
9. Suche nach alter Nachricht ausführen und Jump/Highlight prüfen.
10. `Ctrl + K` öffnen, mit Pfeiltasten navigieren, Enter testen.
11. Friends UI: nur Online filtern, Anfrage-Badge, Freund entfernen mit Confirm.
12. DM öffnen, ungelesene Badge und letzte Nachricht prüfen.
13. Admin Report Detail öffnen, Note speichern, Status ändern.
14. Admin Report Action: gemeldete Nachricht moderieren/löschen.
15. Invite-Liste als normaler Member testen: keine fremden Codes sichtbar.
16. Invite-Liste als berechtigter User testen: Codes kopier-/verwaltbar.
17. Invite auf privaten Channel previewen: Channelname darf nicht leaken.
18. Öffentliche User-Suche mit E-Mail testen: keine Treffer nur wegen E-Mail.
19. Mobile: Channel/DM/Search/Pin/Command UI prüfen.
20. `/api/health` prüfen: Version `phase-34`.

## Bekannte TODOs

- Reactions speichern aktuell weiterhin User-IDs im Message-Reaction-JSON; für große Server wäre langfristig eine eigene Reaction-Tabelle besser.
- Link Previews sind bewusst nur vorbereitet, nicht automatisch aktiv, damit keine externen Tracking-Requests entstehen.
- Vollautomatischer Avatar-Orphan-Cron kann später serverseitig geplant werden.
- Report-Moderation löscht aktuell den Message-Inhalt weich; ein separates Moderationsprotokoll pro Message wäre eine spätere Erweiterung.

## Archiv-Hinweis

Das Phase-34-Zip enthält absichtlich `.env`, wie gewünscht. `node_modules`, `.next`, Storage-Dateien und `*.tsbuildinfo` gehören nicht ins Archiv.
